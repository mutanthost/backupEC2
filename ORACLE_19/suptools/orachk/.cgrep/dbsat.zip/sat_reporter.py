#!/usr/bin/env python

#
# Security Assessment Analysis
#
# Copyright (c) 2015, 2018, Oracle and/or its affiliates. All rights reserved.
#

import sys
import getopt
import datetime
import shlex
import string
import hashlib
import re
import traceback
import xml.etree.ElementTree as ET
import sat_analysis as sat

# Analyzer verion
VERSION = '2.0.2 (May 2018)'

###
### Report Header
###

# Database identification
def db_identification(program):
    global collection_date

    # data collection date
    data = sat.get_data('date_and_release', 1)
    if data is None:
        sat.diag('Collection date not found')
        date_str = ''
    else:
        date_idx = sat.get_index('date_and_release', 'collection_date')
        collection_date = read_date(data[0][date_idx])
        date_str = format_date(collection_date)

    # date of analysis
    today_str = format_date(datetime.datetime.now())

    # version
    hash = hashlib.sha256()
    for line in open(program):
        hash.update(line.encode('utf-8', 'replace'))
    version = '%s - %s' % (VERSION, hash.hexdigest()[-4:])

    rows = (('Date of Data Collection', 'Date of Report', 'Reporter Version'),
        (date_str, today_str, version))

    sat.table('Assessment Date & Time', rows, header=True)

    # database information
    data = sat.get_data('db_identity', 1)
    if data is None:
        sat.diag('Database identity data not found')
    else:
        name = sat.get_index('db_identity', 'name')
        platform = sat.get_index('db_identity', 'platform')
        dg_role = sat.get_index('db_identity', 'dg_role')
        logmode =  sat.get_index('db_identity', 'log_mode')
        created = sat.get_index('db_identity', 'created')
        created_str = format_date(read_date(data[0][created]))
        header = ['Name', 'Platform', 'Database Role', 'Log Mode', 'Created'] 
        values = [data[0][name], data[0][platform],
                  data[0][dg_role], data[0][logmode], created_str]

        pdb_data = sat.get_data('db_pdbs', 1)
        if pdb_data:
            pdb_name = sat.get_index('db_pdbs', 'name')
            con_id = sat.get_index('db_pdbs', 'con_id')
            if len(pdb_data) > 1:
                con_type = 'Root'
            else:
                con_type = 'PDB'
            container = '%s (%s:%d)' % (pdb_data[0][pdb_name], con_type,
                pdb_data[0][con_id])
            header.insert(1, 'Container (Type:ID)')
            values.insert(1, container)

        sat.table('Database Identity', (header, values), header=True)

###
### Basic Information
###

# Database Version
# Security Features
def sec_feature_usage():
    global target_db_version

    # target database release
    data = sat.get_data('date_and_release', 1)
    if data is None:
        sat.diag('Database release not found')
    else:
        dbv_idx = sat.get_index('date_and_release', 'release')
        target_db_version = data[0][dbv_idx]

    # security feature usage
    sec_options = set()

    rows = [['AUTHORIZATION CONTROL', '']]

    if db_options_dict.get('Oracle Database Vault', False):
        rows += [['Database Vault', 'Yes']]
        sec_options.add('Database Vault')
    else:
        rows += [['Database Vault', 'No']]

    data = sat.get_data('privilege_capture', 1)
    if data is not None:
        if len(data) == 0:
            rows += [['Privilege Analysis', 'No']]
        else:
            rows += [['Privilege Analysis', 'Yes']]
            sec_options.add('Database Vault')

    rows += [['', '']]
    rows += [['DATA ENCRYPTION', '']]

    data = sat.get_data('encrypted_column', 1)
    if data is None or len(data) == 0:
        rows += [['Column Encryption', 'No']]
    else:
        rows += [['Column Encryption', 'Yes']]
        sec_options.add('Advanced Security')

    data = sat.get_data('encrypted_tablespace', 2)
    if data is not None:
        algo = sat.get_index('encrypted_tablespace', 'algo')

        if len([1 for x in data if len(x[algo]) > 0]) > 0:
            rows += [['Tablespace Encryption', 'Yes']]
            sec_options.add('Advanced Security')
        else:
            rows += [['Tablespace Encryption', 'No']]

    network_enc = False
    # first check native encryption.
    dict = parse_configfile('sqlnet.ora')
    if dict is not None:
        server_enc = dict.get('SQLNET.ENCRYPTION_SERVER', 'ACCEPTED')

        if server_enc.upper() in ('REQUIRED', 'REQUESTED'):
            network_enc = True

    # if native encryption is not used, check SSL.
    if not network_enc:
        dict = parse_configfile('listener.ora')

        if dict is not None:
            lsnr_protocols = get_listener_protocols(dict)

            for x in lsnr_protocols:
                protocol = x[1]

                if protocol['TCPS'] > 0:
                    network_enc = True
                    break

    if network_enc:
        rows += [['Network Encryption', 'Yes']]
    else:
        rows += [['Network Encryption', 'No']]

    rows += [['', '']]
    rows += [['FINE-GRAINED ACCESS CONTROL', '']]

    data = sat.get_data('redaction_policy', 1)
    if data is not None:
        if len(data) == 0:
            rows += [['Data Redaction', 'No']]
        else:
            rows += [['Data Redaction', 'Yes']]
            sec_options.add('Advanced Security')

    data = sat.get_data('vpd_policy', 1)
    if data is None or len(data) == 0:
        rows += [['Virtual Private Database', 'No']]
    else:
        rows += [['Virtual Private Database', 'Yes']]

    data = sat.get_data('ras_policy', 1)
    if data is not None:
        if len(data) == 0:
            rows += [['Real Application Security', 'No']]
        else:
            rows += [['Real Application Security', 'Yes']]

    if db_options_dict.get('Oracle Label Security', False):
        rows += [['Label Security', 'Yes']]
        sec_options.add('Label Security')
    else:
        rows += [['Label Security', 'No']]

    scol = sat.get_data('tsdp_sensitive_column', 1)
    pcol = sat.get_data('tsdp_protected_column', 1)
    tsdp_pol = sat.get_data('tsdp_policy', 1)
    if scol is not None or pcol is not None or tsdp_pol is not None:
        if tsdp_pol is not None:
            policy = sat.get_index('tsdp_policy', 'policy_name')
            # REDACT_AUDIT is an Oracle default policy.
            plist = [x[policy] for x in tsdp_pol if x[policy] != 'REDACT_AUDIT']
        else:
            plist = []

        if ((scol is not None and len(scol) > 0) or
            (pcol is not None and len(pcol) > 0) or
            len(plist) > 0):
            rows += [['Transparent Sensitive Data Protection', 'Yes']]
        else:
            rows += [['Transparent Sensitive Data Protection', 'No']]

    rows += [['', '']]
    rows += [['AUDITING', '']]

    # if Unified Audit is enabled, then it means traditional
    # audit is disabled.
    if db_options_dict.get('Unified Auditing', False):
        traditional_audit = 'No'
    else:
        sdata = sat.get_data('statement_audit', 1)
        odata = sat.get_data('object_audit', 1)
        pdata = sat.get_data('privilege_audit', 1)
        if ((sdata is not None and len(sdata) != 0) or \
                (odata is not None and len(odata) != 0) or \
                (pdata is not None and len(pdata) != 0)):
            traditional_audit = 'Yes'
        else:
            traditional_audit = 'No'
    rows += [['Traditional Audit', traditional_audit]]

    data = sat.get_data('fine_grained_audit', 1)
    if  data is None or len(data) == 0:
        rows += [['Fine Grained Audit', 'No']]
    else:
        rows += [['Fine Grained Audit', 'Yes']]

    data = sat.get_data('unified_audit_policy', 1)
    if data is not None:
        # Even if Unified Audit cannot be disabled, it is possible that
        # it is not used at all. Check to see if there is any Unified Audit
        # policy being enabled.
        state = sat.get_index('unified_audit_policy', 'state')
        enabled_policies = [x for x in data if x[state] == 'Enabled']
        if len(enabled_policies) > 0:
            rows += [['Unified Audit', 'Yes']]
        else:
            rows += [['Unified Audit', 'No']]

    data = sat.get_data('user_account', 12)
    authen_type = sat.get_index('user_account', 'authentication_type')
    if data is not None and authen_type is not None:
        rows += [['', '']]
        rows += [['USER AUTHENTICATION', '']]

        if len([x for x in data if x[authen_type] == 'EXTERNAL']) > 0:
            rows += [['External Authentication', 'Yes']]
        else:
            rows += [['External Authentication', 'No']]

        if len([x for x in data if x[authen_type] == 'GLOBAL']) > 0:
            rows += [['Global Authentication', 'Yes']]
        else:
            rows += [['Global Authentication', 'No']]

    # database version
    data = sat.get_data('db_version', 1)
    if data is None:
        sat.diag('Database version data not found')
    else:
        vrows = [data[0],]
        vrows.append(['Security options used: ' + 
            join_list(sorted(sec_options)),])
        sat.table('Database Version', vrows, header=False)

    sat.table('Security Features', [['Feature', 'Currently Used']] + rows,
        header=True, alignment=['left', 'center'])

# INFO.PATCH - Patch Check
def patch_checks():
    opatch_data = sat.get_data('opatch_inventory', 1)
    history_data = sat.get_data('registry_history', 12)
    spatch12_data = sat.get_data('registry_sqlpatch', 2)
    spatch18_data = sat.get_data('registry_sqlpatch18', 1)

    inventory_list = []
    history_list = []
    bundle_date = None
    interim_date = None

    # Binary patch inventory from Opatch lsinventory
    if opatch_data:
        for idx, x in enumerate(opatch_data):
            if 'Created on' in x[0]:
                str = x[0]
                date_str = str[str.index('Created on')+11:str.index(',')]
                created_date = read_date(date_str, '%d %b %Y') 
                desc = opatch_data[idx-1][0].upper()
                if 'DATABASE PATCH SET UPDATE' in desc or \
                  'DATABASE BUNDLE PATCH' in desc or \
                  'DATABASE RELEASE UPDATE' in desc:
                    patch_id = opatch_data[idx-2][0].split()[-1]
                    patch_str = 'Patch ID (Comprehensive): %s (created %s)' % \
                                (patch_id, format_date(created_date, '%B %Y'))
                    inventory_list.append(patch_str)
                    bundle_date = max_date(bundle_date, created_date)
                elif 'Unique Patch ID' in opatch_data[idx-1][0]:
                    patch_id = opatch_data[idx-1][0].split()[-1]
                    patch_str = 'Patch ID: %s (created %s)' % \
                                (patch_id, format_date(created_date, '%B %Y'))
                    inventory_list.append(patch_str)
                    interim_date = max_date(interim_date, created_date)

    # Oracle 18: dba_registry_sqlpatch with timestamps
    if spatch18_data:
        action_time = sat.get_index('registry_sqlpatch18', 'action_time')
        action = sat.get_index('registry_sqlpatch18', 'action')
        version = sat.get_index('registry_sqlpatch18', 'target_version')
        patch_type = sat.get_index('registry_sqlpatch18', 'patch_type')
        reldate = sat.get_index('registry_sqlpatch18', 'target_build_timestamp')
        description = sat.get_index('registry_sqlpatch18', 'description')

        for x in spatch18_data:
            if x[action] == 'APPLY' or x[action] == 'ROLLBACK':
                action_date = read_date(x[action_time])
                patch_action = 'Action time: %s\n' % format_date(action_date)
                patch_action += 'Action: %s\n' % x[action]
                patch_action += 'Version: %s\n' % x[version]
                patch_action += 'Description: %s\n' % x[description]
                history_list.append(patch_action)
                if patch_type == 'INTERIM':
                    interim_date = max_date(interim_date, x[reldate])
                else:
                    bundle_date = max_date(bundle_date, x[reldate])

    # Oracle 12: dba_registry_sqlpatch with numeric date codes
    elif spatch12_data:
        action_time = sat.get_index('registry_sqlpatch', 'action_time')
        action = sat.get_index('registry_sqlpatch', 'action')
        version = sat.get_index('registry_sqlpatch', 'version')
        bundle_series = sat.get_index('registry_sqlpatch', 'bundle_series')
        bundle_id = sat.get_index('registry_sqlpatch', 'bundle_id')
        description = sat.get_index('registry_sqlpatch', 'description')

        for x in spatch12_data:
            if x[action] == 'APPLY' or x[action] == 'ROLLBACK':
                action_date = read_date(x[action_time])
                patch_action = 'Action time: %s\n' % format_date(action_date)
                patch_action += 'Action: %s\n' % x[action]
                patch_action += 'Version: %s\n' % x[version]
                patch_action += 'Bundle series: %s\n' % x[bundle_series]
                patch_action += 'Description: %s\n' % x[description]
                history_list.append(patch_action)
                if x[bundle_series]:
                    patch_date = read_date('%06d' % x[bundle_id], '%y%m%d')
                    bundle_date = max_date(bundle_date, patch_date)

    # Oracle 11: registry$history with numeric date codes
    elif history_data:
        action_time = sat.get_index('registry_history', 'action_time')
        action = sat.get_index('registry_history', 'action')
        namespace = sat.get_index('registry_history', 'namespace')
        version = sat.get_index('registry_history', 'version')
        bundle_series = sat.get_index('registry_history', 'bundle_series')
        id = sat.get_index('registry_history', 'id')
        comments = sat.get_index('registry_history', 'comments')

        for x in history_data:
            if x[action] == 'APPLY' or x[action] == 'ROLLBACK':
                action_date = read_date(x[action_time])
                patch_action = 'Action time: %s\n' % format_date(action_date)
                patch_action += 'Action: %s\n' % x[action]
                patch_action += 'Namespace: %s\n' % x[namespace]
                patch_action += 'Version: %s\n' % x[version]
                patch_action += 'Bundle series: %s\n' % x[bundle_series]
                patch_action += 'Comments: %s\n' % x[comments]
                history_list.append(patch_action)
                patch_date = read_date('%06d' % x[id], '%y%m%d')
                if x[bundle_series]:
                    bundle_date = max_date(bundle_date, patch_date)
                else:
                    interim_date = max_date(interim_date, patch_date)

    details = ''
    bundle_delta = days_since(bundle_date)
    if bundle_delta is not None:
        details += 'Latest comprehensive patch: %s (%d days ago)\n' % \
            (format_date(bundle_date, '%b %d %Y'), bundle_delta)
    interim_delta = days_since(interim_date)
    if interim_delta is not None:
        details += 'Latest interim patch: %s (%d days ago)\n' % \
            (format_date(interim_date, '%b %d %Y'), interim_delta)
    if details:
        details += '\n'
    details += 'Binary Patch Inventory: \n'
    details += join_list(inventory_list, '\n') + '\n\n'
    details += 'SQL Patch History: \n'
    details += join_list(history_list, '\n')

    if bundle_delta is not None and bundle_delta < 120:
        severity = sat.SEV_OK
        summary = 'Latest comprehensive patch has been applied.'
    elif interim_delta is not None and interim_delta < 90:
        severity = sat.SEV_UNKNOWN
        summary = 'Some patches applied within the last quarter.'
    else:
        severity = sat.SEV_HIGH
        summary = 'Latest comprehensive patch not found.'

    remarks = 'It is vital to keep the database software up-to-date ' + \
        'with security fixes as they are released. ' + \
        'Oracle issues comprehensive patches in the form of Release ' + \
        'Updates, Patch Set Updates, and Bundle Patches on a regular ' + \
        'quarterly schedule. These updates should be applied as soon as ' + \
        'they are available.'
    refs = {'CIS': 'Recommendation 1.1'}

    sat.finding('Patch Check', 'INFO.PATCH', summary,
        severity, details, remarks, refs)
     
###
### User Accounts
###

def user_section():
    user_account()
    system_default_tablespace()
    sample_schema()
    inactive_user()
    case_sensitive_password()
    expired_user()
    user_with_default_password()
    sqlnet_allowed_logon_version()
    user_password_version()
    user_params()

    profile_dict = get_profile_data()
    user_profiles(profile_dict)
    user_password(profile_dict, acct_profiles)
    user_login(profile_dict, acct_profiles)
    password_verify_function(profile_dict, acct_profiles)

# User Accounts
def user_account():
    data = sat.get_data('user_account', 1)
    if data is None:
        sat.diag('Skipped User Accounts')
        return
    user_name = sat.get_index('user_account', 'username')
    user_profile = sat.get_index('user_account', 'profile')
    status = sat.get_index('user_account', 'status')
    d_tab_space = sat.get_index('user_account', 'default_tablespace')
    t_tab_space = sat.get_index('user_account', 'temporary_tablespace')
    auth_type = sat.get_index('user_account', 'authentication_type')
    external_name = sat.get_index('user_account', 'external_name') 

    if not check_oracle_accts:
        sat.info('Note: Predefined Oracle accounts which are locked are '
             'not included in this report. To include all user accounts, '
             'run the report with the -a option.')

    rows = []
    for x in data:
        if x[user_name] not in acct_profiles:
            continue
        if x[user_name] in oracle_users:
            oracle = 'Yes'
        else:
            oracle = 'No'
        if auth_type:
            if external_name and len(x[external_name]) > 0:
              row = [x[user_name], x[status], x[user_profile],
                     x[d_tab_space], oracle, 
                     x[auth_type] + ': ' + x[external_name]]
            else:
              row = [x[user_name], x[status], x[user_profile],
                     x[d_tab_space], oracle, x[auth_type]]
        else:
            row = [x[user_name], x[status], x[user_profile],
                   x[d_tab_space], oracle]
        rows.append(row)

    if auth_type:
        columns = [['User Name', 'Status', 'Profile', 'Tablespace',
                    'Oracle Defined', 'Auth Type']]
        alignment = ['left', 'left', 'left', 'left', 'center', 'left']
    else:
        columns = [['User Name', 'Status', 'Profile', 'Tablespace',
                    'Oracle Defined']]
        alignment = ['left', 'left', 'left', 'left', 'center']

    sat.table('User Accounts', columns+rows, header=True, alignment=alignment)

# USER.TBLSPACE - User Accounts in SYSTEM or SYSAUX Tablespace
def system_default_tablespace():
    data = sat.get_data('user_account', 1)
    if data is None:
        sat.diag('Skipped Default Tablespaces')
        return

    username = sat.get_index('user_account', 'username')
    d_tab_space = sat.get_index('user_account', 'default_tablespace')
    t_tab_space = sat.get_index('user_account', 'temporary_tablespace')

    system_users = []
    sysaux_users = []
    for x in data:
        if x[username] in oracle_users:
            continue
        if x[d_tab_space] == 'SYSTEM' or x[t_tab_space] == 'SYSTEM':
            system_users.append(x[username])
        elif x[d_tab_space] == 'SYSAUX' or x[t_tab_space] == 'SYSAUX':
            sysaux_users.append(x[username])

    total_num = len(system_users) + len(sysaux_users)

    if total_num > 0:
        severity = sat.SEV_MEDIUM
        summary = 'Found ' + sing_plural(total_num, 'user', 'users') + \
                  ' using SYSTEM or SYSAUX tablespace.'
        details = 'Tablespace SYSTEM: ' + join_list(system_users) + '\n'
        details += 'Tablespace SYSAUX: ' + join_list(sysaux_users) + '\n'
    else:
        severity = sat.SEV_OK
        summary = 'No user uses SYSTEM or SYSAUX tablespace.'
        details = None

    remarks = 'The SYSTEM and SYSAUX tablespaces are reserved for ' + \
        'Oracle-supplied user accounts. To avoid a possible ' + \
        'denial of service caused by exhausting these resources, ' + \
        'regular user accounts should not use these tablespaces. ' + \
        'Prior to Oracle Database 12.2, the SYSTEM tablespace cannot ' + \
        'be encrypted, and this is another reason to avoid ' + \
        'user schemas in this tablespace.'

    sat.finding('User Accounts in SYSTEM or SYSAUX Tablespace',
        'USER.TBLSPACE', summary,
        severity=severity, details=details, remarks=remarks)

# USER.SAMPLE - Sample Schemas
def sample_schema():
    data = sat.get_data('user_account', 1)
    if data is None:
        sat.diag('Skipped Sample Schemas')
        return
    name = sat.get_index('user_account', 'username')

    sample_schema_list = ['SCOTT','HR', 'OE', 'SH', 'PM', 'IX', \
                  'ADAMS', 'BLAKE', 'CLARK', 'BI']

    user_list = [x[name] for x in data if x[name] in sample_schema_list]

    if len(user_list) > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    if len(user_list) > 0:
        summary = 'Found ' + sing_plural(len(user_list), 
                                         'sample schema.', 'sample schemas.')
        details = 'Sample schemas: ' + join_list(user_list) + '\n';
    else:
        summary = 'No sample schemas found.'
        details = None

    remarks = 'Sample schemas are well-known accounts provided by ' + \
        'Oracle to serve as simple examples for developers. They ' + \
        'generally serve no purpose in a production database and ' + \
        'should be removed because they unnecessarily increase ' + \
        'the attack surface of the database.'
    refs = {'CIS': 'Recommendation 1.3'}

    sat.finding('Sample Schemas', 'USER.SAMPLE', summary,
        severity, details, remarks, refs)

# USER.INACTIVE - Inactive Users
def inactive_user():
    # last_login is available only from v21.
    data = sat.get_data('user_account', 21)
    if data is None or collection_date is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped Inactive Users')
        return

    user_name = sat.get_index('user_account', 'username')
    status = sat.get_index('user_account', 'status')
    created = sat.get_index('user_account', 'created')
    last_login = sat.get_index('user_account', 'last_login')

    user_list = []
    for x in data:
        if x[user_name] not in acct_profiles:
            continue
        # Skip locked accounts
        if x[status] not in ('OPEN', 'EXPIRED', 'EXPIRED(GRACE)'):
            continue
        # Skip new accounts
        create_date = datetime.datetime.strptime(x[created],
                            '%d-%m-%Y %H:%M')
        delta = collection_date - create_date
        if delta.days < 30:
            continue
        # NULL means the user has never logged in
        if len(x[last_login]) == 0:
            user_list.append(x[user_name])
        else:
            last_login_date = datetime.datetime.strptime(
                                            x[last_login], '%d-%m-%Y %H:%M')
            delta = collection_date - last_login_date
            if delta.days >= 30:
                user_list.append(x[user_name])

    if len(user_list) > 0:
        severity = sat.SEV_LOW
        summary = 'Found ' + sing_plural(len(user_list), 
                                         'unlocked user', 'unlocked users') + \
                  ' inactive for more than 30 days.'
        details = 'Inactive users: ' + join_list(user_list)
    else:
        severity = sat.SEV_OK
        summary = 'No unlocked users inactive for more than 30 days found.'
        details = None

    remarks = 'If a user account is no longer in use, it increases the ' + \
        'attack surface of the system unnecessarily while ' + \
        'providing no corresponding benefit. Furthermore, ' + \
        'unauthorized use is less likely to be noticed when no ' + \
        'one is regularly using the account. Accounts that have ' + \
        'been unused for more than 30 days should be ' + \
        'investigated to determine whether they should remain ' + \
        'active.'

    sat.finding('Inactive Users', 'USER.INACTIVE', summary,
        severity=severity, details=details, remarks=remarks)

# USER.CASE - Case-Sensitive Passwords
def case_sensitive_password():
    checked, num_issues, details = \
        param_should('SEC_CASE_SENSITIVE_LOGON', 'TRUE')

    if num_issues > 0:
        severity = sat.SEV_HIGH
        summary = 'Case-sensitive passwords are not used.'
    else:
        severity = sat.SEV_OK
        summary = 'Case-sensitive passwords are used.'

    remarks = 'Case-sensitive passwords are recommended because ' + \
        'including both upper and lower-case letters greatly ' + \
        'increases the set of possible passwords that must be ' + \
        'searched by an attacker who is attempting to guess a ' + \
        'password by exhaustive search. Setting ' + \
        'SEC_CASE_SENSITIVE_LOGON to TRUE ensures that the ' + \
        'database distinguishes between upper and lower-case ' + \
        'letters in passwords.'
    refs = {'CIS': 'Recommendation 2.2.12'}

    sat.finding('Case-Sensitive Passwords', 'USER.CASE', summary,
        severity, details, remarks, refs)

# USER.EXPIRED - Users with Expired Passwords
def expired_user():
    data = sat.get_data('user_account', 1)
    if data is None or collection_date is None:
        sat.diag('Skipped Expired Passwords')
        return
    user_name = sat.get_index('user_account', 'username')
    status = sat.get_index('user_account', 'status')
    expiry_date = sat.get_index('user_account', 'expiry_date')

    user_list = []
    for x in data:
        if x[user_name] not in acct_profiles:
            continue
        # Skip locked accounts
        if x[status] not in ('OPEN', 'EXPIRED', 'EXPIRED(GRACE)'):
            continue
        if len(x[expiry_date]) > 0:
            exp_date = datetime.datetime.strptime(
                                            x[expiry_date], '%d-%m-%Y %H:%M')
            delta = collection_date - exp_date
            if delta.days >= 30:
                user_list.append(x[user_name])

    if len(user_list) > 0:
        severity = sat.SEV_LOW
        summary = 'Found ' + sing_plural(len(user_list), 'unlocked user', 
                                                         'unlocked users') + \
                  ' with password expired for more than 30 days.'
        details = 'Users with expired passwords: ' + join_list(user_list)
    else:
        severity = sat.SEV_OK
        summary = 'No unlocked users with password expired ' + \
                  'for more than 30 days found.'
        details = None

    remarks = "Password expiration is used to ensure that users change " \
        "their passwords on a regular basis. If a user's " \
        "password has been expired for more than 30 days, it " \
        "indicates that the user has not logged in for at least " \
        "that long. Accounts that have been unused for an " \
        "extended period of time should be investigated to " \
        "determine whether they should remain active."

    sat.finding('Users with Expired Passwords', 'USER.EXPIRED', summary,
        severity=severity, details=details, remarks=remarks)

# USER.DEFPWD - Users with Default Passwords
def user_with_default_password():
    data = sat.get_data('user_with_default_password', 1)
    if data is None:
        sat.diag('Skipped Default Passwords')
        return
    account_open = sat.get_index('user_with_default_password', 'account_open')
    user_name = sat.get_index('user_with_default_password', 'username')

    open_list = [x[user_name] for x in data if x[account_open]
             and x[user_name] in acct_profiles]

    if len(open_list) > 0:
        severity = sat.SEV_HIGH
        summary = 'Found ' + \
                  sing_plural(len(open_list), 'unlocked user account',
                                              'unlocked user accounts') + \
                  ' with default password.'
        details = 'Users with default password: ' + join_list(open_list) + '\n'
    else:
        severity = sat.SEV_OK
        summary = 'No unlocked user accounts are using default password.'
        details = None

    remarks = 'Default account passwords for predefined Oracle ' + \
        'accounts are well known. Active accounts with default ' + \
        'passwords provide a trivial means of entry for ' + \
        'attackers, but well-known passwords should be changed ' + \
        'for locked accounts as well.'
    refs = {'CIS': 'Recommendation 1.2'}

    sat.finding('Users with Default Passwords', 'USER.DEFPWD', summary,
        severity, details, remarks, refs)

# USER.AUTHVERS - Minimum Client Authentication Version
def sqlnet_allowed_logon_version():
    dict = parse_configfile('sqlnet.ora')
    if dict is None or target_db_version is None:
        sat.diag('Skip Allowed Logon Version check') 
        return

    if target_db_version >= '12.1.0.2':
        para_name = 'ALLOWED_LOGON_VERSION_SERVER'
        default_value = '12'
        required_version = '12a'
    elif target_db_version >= '12':
        para_name = 'ALLOWED_LOGON_VERSION_SERVER'
        default_value = '11'
        required_version = '12'
    elif target_db_version >= '11':
        para_name = 'ALLOWED_LOGON_VERSION'
        default_value = '8'
        # the value, 12, was included in a CPU for 11g.
        required_version = '12'
    elif target_db_version >= '10':
        para_name = 'ALLOWED_LOGON_VERSIONS'
        default_value = '(10, 9, 8)'
        required_version = '10'
    else:
        sat.diag('Skip Allowed Logon Version check')
        return

    issue, details = network_parameter(dict=dict,
                                       para_name='SQLNET.'+para_name,
                                       unset_ok=True,
                                       default_value=default_value,
                                       required_value=required_version,
                                       forbidden_value=None,
                                       case_sensitive=True)

    if issue:
        severity = sat.SEV_LOW
        summary = 'Minimum client version is not configured correctly.'
    else:
        severity = sat.SEV_OK
        summary = 'Minimum client version is configured correctly.'

    remarks = 'Over time, Oracle releases have added support for ' + \
        'increasingly secure versions of the algorithm used for ' + \
        'password authentication of user accounts. In order to remain ' + \
        'compatible with older client software, the database ' + \
        'continues to support previous password versions ' + \
        'as well. The sqlnet.ora parameter ' + para_name + ' determines ' + \
        'the minimum password version that the database will accept. ' + \
        'For maximum security, ' + \
        'this parameter should be set to the highest value supported ' + \
        'by the database once all client systems have been upgraded.'

    sat.finding('Minimum Client Authentication Version', 'USER.AUTHVERS',
        summary, severity=severity, details=details, remarks=remarks)

# USER.VERIFIER - Password Verifiers
def user_password_version():
    # password_version is available from v11.
    data = sat.get_data('user_account', 11)
    if data is None or target_db_version is None:
        sat.diag('Skipped User Account Verifiers')
        return

    name = sat.get_index('user_account', 'username')
    versions = sat.get_index('user_account', 'password_versions')
    authen_type = sat.get_index('user_account', 'authentication_type')

    outdated_list = []
    http_list = []

    if target_db_version >= '12.1.0.2':
        latest_verifier = '12C'
    elif target_db_version >= '11':
        latest_verifier = '11G'
    elif target_db_version >= '10':
        latest_verifier = '10G'
    else:
        latest_verifier = ''
        sat.diag('Skipped User Account Verifiers')

    pw_users = [x for x in data if x[name] in acct_profiles]
    if authen_type is not None:
        pw_users = [x for x in pw_users if x[authen_type] not in \
                    ('EXTERNAL', 'GLOBAL')]
    for x in pw_users:
        if latest_verifier not in x[versions]:
            outdated_list.append(x[name] + '(' + x[versions] + ')')
        if 'HTTP' in x[versions]:
            http_list.append(x[name])

    details = 'Database supports password versions up to ' + \
        latest_verifier + '.\n'

    severity = sat.SEV_OK
    details += 'Users requiring updated password verifiers: ' + \
        join_list(outdated_list) + '\n'
    if len(outdated_list) > 0:
        severity = sat.SEV_MEDIUM
        summary = 'Found ' + sing_plural(len(outdated_list), 
                                         'user account', 'user accounts') + \
                  ' requiring updated password verifiers. '
    else:
        summary = 'All user accounts support the latest password version. '

    details += '\n' + 'Users with HTTP verifiers: ' + \
        join_list(http_list) + '\n'
    if len(http_list) > 0:
        if severity == sat.SEV_OK:
            severity = sat.SEV_LOW
        summary += 'Found ' + sing_plural(len(http_list), 
                                         'account', 'accounts') + \
                  ' with HTTP password verifiers.'
    else:
        summary += ' No user accounts have HTTP verifiers. '

    remarks = 'For each user account, the database may store multiple ' + \
        'verifiers, which are hashes of the user password. ' + \
        'Each verifier supports a different version of the password ' + \
        'authentication algorithm. Every user account should ' + \
        'include a verifier for the latest password version supported by ' + \
        'the database so that the user can be authenticated using ' + \
        'the latest algorithm supported by the client. When all clients ' + \
        'have been updated, the security of user accounts can be ' + \
        'improved by removing the obsolete verifiers. ' + \
        'HTTP password verifiers are used for XML Database authentication. ' + \
        'Use the ALTER USER command to remove these verifiers from user ' + \
        'accounts that do not require this access.' 

    sat.finding('Password Verifiers', 'USER.VERIFIER', summary,
        severity=severity, details=details, remarks=remarks)

# USER.PARAM - User Parameters
def user_params():
    checked, num_issues, details = \
        param_should_not('SEC_MAX_FAILED_LOGIN_ATTEMPTS', '0', 'not zero')
    checked, num_issues, details = \
        param_should('RESOURCE_LIMIT', 'TRUE', checked, num_issues, details)

    if checked == 0:
        sat.diag('Skipped User Parameter Check')
        return

    summary = param_check_summary(checked, num_issues)

    if num_issues > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    remarks = "SEC_MAX_FAILED_LOGIN_ATTEMPTS configures the maximum " \
        "number of failed login attempts in a single session before " \
        "the connection is closed. This is independent of the user " \
        "profile parameter FAILED_LOGIN_ATTEMPTS, which controls " \
        "locking the user account after multiple failed login attempts. " \
        "RESOURCE_LIMIT should be set to TRUE to enable enforcement " \
        "of any resource constraints set in user profiles."
    refs = {'CIS': 'Recommendation 2.2.13, 2.2.19'}
    sat.finding('User Parameters', 'USER.PARAM', summary,
        severity, details, remarks, refs)

# User Profiles
def user_profiles(profile_dict):
    if profile_dict is None:
        sat.diag('Skipped User Profiles')
        return

    rows = []
    for prof, dict in sorted(profile_dict.items()):
        for resource, value in sorted(dict.items()):
            if 'PASSWORD' in resource or 'LOGIN' in resource or \
               resource in ('CONNECT_TIME', 'IDLE_TIME', '(Number of Users)'):
                if value == 'DEFAULT':
                    value = profile_dict['DEFAULT'][resource] + ' (DEFAULT)'
                rows.append([prof, resource, value])

    sat.table('User Profiles',
        [['Profile Name', 'Resource', 'Value']] + rows, header=True)

# USER.NOEXPIRE - Users with Unlimited Password Lifetime
def user_password(profiles, users):
    if profiles is None:
        sat.diag('Skipped User Password checks')
        return
    severity = sat.SEV_OK
    summary = ''
    details = ''

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_LIFE_TIME', ('day', 'days'))
    details += 'PASSWORD_LIFE_TIME:\n'
    details += 'Profiles with limited password lifetime: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles with unlimited password lifetime: ' + \
               join_list(profile_list) + '\n'
    details += 'Users with unlimited password lifetime: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_LOW)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' with passwords that never expire. '
    else:
        summary += 'Password expiration is configured for all users. '

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_REUSE_MAX', ('time', 'times'))
    details += '\nPASSWORD_REUSE_MAX:\n'
    details += 'Profiles with limits on password reuse: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles without limits on password reuse: ' + \
               join_list(profile_list) + '\n'
    details += 'Users without limits on password reuse: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_LOW)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' with no limits on password reuse. '
    else:
        summary += 'All users have limits on password reuse. '

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_REUSE_TIME', ('day', 'days'))
    details += '\nPASSWORD_REUSE_TIME:\n'
    details += 'Profiles with minimum time before password reuse: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles without minimum time before password reuse: ' + \
               join_list(profile_list) + '\n'
    details += 'Users without minimum time before password reuse: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_LOW)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' with no minimum time before password reuse. '
    else:
        summary += 'All users require minimum time before password reuse. '

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_GRACE_TIME', ('day', 'days'))
    details += '\nPASSWORD_GRACE_TIME:\n'
    details += 'Profiles with locking after password expiration: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles without locking after password expiration: ' + \
               join_list(profile_list) + '\n'
    details += 'Users without locking after password expiration: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_LOW)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' without locking after password expiration.'
    else:
        summary += 'All user accounts will lock after password expiration.'

    remarks = 'Password expiration is used to ensure that users change ' + \
        'their passwords on a regular basis. Passwords that ' + \
        'never expire may remain unchanged for an extended ' + \
        'period of time. When passwords do not have to be ' + \
        'changed regularly, users are also more likely to use ' + \
        'the same passwords for multiple accounts.'
    refs = {'CIS': 'Recommendation 3.3, 3.4, 3.5, 3.6'}

    sat.finding('Users with Unlimited Password Lifetime', 'USER.NOEXPIRE',
        summary, severity, details, remarks, refs)

# USER.NOLOCK - Users with Unlimited Failed Login Attempts
def user_login(profiles, users):
    if profiles is None:
        sat.diag('Skipped User Login checks')
        return
    severity = sat.SEV_OK
    summary = ''
    details = ''

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'FAILED_LOGIN_ATTEMPTS')
    details += 'FAILED_LOGIN_ATTEMPTS:\n'
    details += 'Profiles with limited failed login attempts: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles with unlimited failed login attempts: ' + \
               join_list(profile_list) + '\n'
    details += 'Users with unlimited failed login attempts: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_MEDIUM)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' with unlimited failed login attempts. '
    else:
        summary += 'No users have unlimited failed login attempts. '

    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_LOCK_TIME', ('day', 'days'))
    details += '\nPASSWORD_LOCK_TIME:\n'
    details += 'Profiles with minimum lock time: '+ \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles without minimum lock time: ' + \
               join_list(profile_list) + '\n'
    details += 'Users without minimum lock time: ' + \
               join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = max(severity, sat.SEV_LOW)
        summary += 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' without minimum lock time.'
    else:
        summary += 'All users have minimum lock time.'

    remarks = "Attackers sometimes attempt to guess a user's password " \
        "by simply trying all possibilities from a set of common " \
        "passwords. To defend against this attack, it is " \
        "advisable to use the FAILED_LOGIN_ATTEMPTS and PASSWORD_LOCK_TIME " \
        "profile resources to lock user accounts for a specified time when " \
        "there are multiple failed login attempts without a successful " \
        "login."
    refs = {'CIS': 'Recommendation 3.1, 3.2'}

    sat.finding('Account Locking after Failed Login Attempts', 'USER.NOLOCK',
        summary, severity, details, remarks, refs)

# USER.PASSWD - Password Verification Functions
def password_verify_function(profiles, users):
    profile_list, user_list, exempt_prof_list = \
        profile_unset(profiles, users, 'PASSWORD_VERIFY_FUNCTION')

    if profile_list is None:
        sat.diag('Skipped Password Verification Functions')
        return

    details = 'Profiles with password verification function: ' + \
               join_list(exempt_prof_list) + '\n'
    details += 'Profiles without password verification '+ \
               'function: ' + join_list(profile_list) + '\n'
    details += 'Users without password verification function: ' + \
                   join_list(user_list) + '\n'
    if len(user_list) > 0:
        severity = sat.SEV_MEDIUM
        summary = 'Found ' + sing_plural(len(user_list), 'user', 'users') + \
                  ' not using password verification function.'
    else:
        severity = sat.SEV_OK
        summary = 'All user accounts are using password verification function.' 

    remarks = 'Password verification functions are used to ensure that ' + \
        'user passwords meet minimum requirements for ' + \
        'complexity, which may include factors such as length, ' + \
        'use of numbers or punctuation characters, difference ' + \
        'from previous passwords, etc. Oracle supplies several ' + \
        'predefined functions, or a custom PL/SQL function can ' + \
        'be used. Every user profile should include a password ' + \
        'verification function.'
    refs = {'CIS': 'Recommendation 3.8'}

    sat.finding('Password Verification Functions', 'USER.PASSWD', summary,
        severity, details, remarks, refs)

# get_profile_data
#   No parameters
# Returns
#   profile_dict - dictionary of profile contents
#   user_dict - mapping of username to profile
#
# Convert result tables for account profiles to dictionary form for
# easy access in subsequent rules. Also add a psuedo-entry to each
# profile indicating the number of user accounts that use the profile.
#
def get_profile_data():
    profile_data = sat.get_data('profiles', 1)
    if profile_data is None:
        return None

    profile_name = sat.get_index('profiles', 'profile')
    resource = sat.get_index('profiles', 'resource_name')
    limit = sat.get_index('profiles', 'limit')


    profile_dict = {}
    for x in profile_data:
        prof = x[profile_name]
        if prof not in profile_dict:
            profile_dict[prof] = {}
        profile_dict[prof][x[resource]] = x[limit]

    profile_list = list(acct_profiles.values())
    for prof in profile_dict:
        profile_dict[prof]['(Number of Users)'] = \
            str(profile_list.count(prof))

    return profile_dict

# profile_unset
#   profile_dict - dictionary containing all profile contents
#   user_profiles - dictionary of assigned profile for each account
#   resource_name - the resource name
# Returns
#   matching_profs - profiles with no setting for the specified resource
#   user_list - users with profiles in the matching_profs list
#   nonmatching_profs - profiles with a setting for the specifed resource
#   units - optional list of singular and plural units for parameter value
#
# Find profiles with no limit or setting for the specified resource.
# Values NULL or UNLIMITED are considered equivalent to no setting.
#
def profile_unset(profile_dict, user_profiles, resource_name, units=None):
    matching_profs = []
    nonmatching_profs = []
    for prof in profile_dict.keys():
        value = profile_dict[prof].get(resource_name, 'NULL')
        if value == 'DEFAULT':
            value = profile_dict['DEFAULT'].get(resource_name, 'NULL')
        if value in ('UNLIMITED', 'NULL'):
            matching_profs.append(prof)
        else:
            if units:
                value = sing_plural(int(value), units[0], units[1])
            nonmatching_profs.append('%s(%s)' % (prof, value))

    user_list = [name for name, prof in user_profiles.items()
                  if prof in matching_profs]

    return sorted(matching_profs), sorted(user_list), sorted(nonmatching_profs) 

###
### Privileges and Roles
###

# All System Privileges
# All Roles
# PRIV.ACCT - Account Management Privileges
# PRIV.MGMT - Privilege Management Privileges
# PRIV.DBMGMT - Database Management Privileges
# PRIV.AUDIT - Audit Management Privileges
# PRIV.DATA - Data Access Privileges
# PRIV.EXEMPT - Access Control Exemption Privileges
# PRIV.PASSWD - Access to Password Verifier Tables
# PRIV.OBJ - Access to Restricted Objects
# PRIV.USER - User Impersonation
# PRIV.EXFIL - Data Exfiltration
# PRIV.SYSPUB - System Privileges Granted to PUBLIC
# PRIV.ROLEPUB - Roles Granted to PUBCIC
# PRIV.COLPUB - Column Privileges Granted to PUBLIC
# PRIV.DBA - DBA Role
# PRIV.BIGROLES - Other Powerful Roles
def privs_and_roles():
    role_grants = sat.get_data('role_grants', 1)
    system_privs = sat.get_data('system_privs', 1)
    object_privs = sat.get_data('sensitive_obj_privs', 1)
    verifier_privs = sat.get_data('verifier_privs', 1)
    execute_privs = sat.get_data('execute_privs', 1)
    column_privs = sat.get_data('column_privs', 1)
    if role_grants is None or system_privs is None:
        # Used by virtually all privilege rules
        sat.diag('Skipped Privilege and Role checks')
        return

    r_grantee = sat.get_index('role_grants', 'grantee')
    r_role = sat.get_index('role_grants', 'granted_role')
    r_admin = sat.get_index('role_grants', 'is_admin')
    p_grantee = sat.get_index('system_privs', 'grantee')
    p_priv = sat.get_index('system_privs', 'privilege')
    p_admin = sat.get_index('system_privs', 'is_admin')
    o_grantee = sat.get_index('sensitive_obj_privs', 'grantee')
    o_priv = sat.get_index('sensitive_obj_privs', 'privilege')
    o_owner = sat.get_index('sensitive_obj_privs', 'owner')
    o_table = sat.get_index('sensitive_obj_privs', 'table_name')
    o_admin = sat.get_index('sensitive_obj_privs', 'is_admin')
    v_grantee = sat.get_index('verifier_privs', 'grantee')
    v_priv = sat.get_index('verifier_privs', 'privilege')
    v_owner = sat.get_index('verifier_privs', 'owner')
    v_table = sat.get_index('verifier_privs', 'table_name')
    v_admin = sat.get_index('verifier_privs', 'is_admin')
    e_grantee = sat.get_index('execute_privs', 'grantee')
    e_priv = sat.get_index('execute_privs', 'privilege')
    e_package = sat.get_index('execute_privs', 'package')
    e_admin = sat.get_index('execute_privs', 'is_admin')
    c_grantee = sat.get_index('column_privs', 'grantee')
    c_priv = sat.get_index('column_privs', 'privilege')
    c_owner = sat.get_index('column_privs', 'owner')
    c_table = sat.get_index('column_privs', 'table_name')
    c_column = sat.get_index('column_privs', 'column_name')
    c_admin = sat.get_index('column_privs', 'is_admin')

    syspriv_table = [[x[p_grantee], x[p_priv], x[p_admin]] 
                        for x in system_privs]
    role_dict = {}
    for x in role_grants:
        # Prior to 12c, the DV_PUBLIC role is granted to PUBLIC during Database
        # installation. This particular role grant should be ignored.
        if not (x[r_grantee] == 'PUBLIC' and x[r_role] == 'DV_PUBLIC'):
            role_dict[x[r_grantee]] = role_dict.get(x[r_grantee], []) + \
                [[x[r_role], x[r_admin]]]

    # All system privileges
    remarks = 'System privileges provide the ability to access data or ' + \
        'perform administrative operations for the entire ' + \
        'database. Consistent with the principle of least ' + \
        'privilege, these privileges should be granted sparingly. ' + \
        'The Privilege Analysis feature of Database Vault may be helpful ' + \
        'to determine the minimum set of privileges required by a ' + \
        'user or role. In some cases, it may be possible to ' + \
        'substitute a more limited object privilege grant in ' + \
        'place of a system privilege grant that applies to all ' + \
        'objects. System privileges should be granted with admin ' + \
        'option only when the recipient needs the ability to ' + \
        'grant the privilege to others.'
    refs = {'CIS': 'Recommendation 4.7'}
    priv_list = [x[p_priv] for x in system_privs]
    priv_list = sorted(list(set(priv_list)))
    details = 'Users directly or indirectly granted each system privilege:\n\n'
    num_total = 0
    num_admin = 0
    for priv in priv_list:
        users, admin = get_sys_priv_grantees(priv)
        details += '%s: %s\n' % (priv, join_list(users))
        num_total += len(users)
        num_admin += admin
    if num_admin > 0:
        details += '\n(*) = granted with admin option'
    severity, summary = grant_summary('system privileges', 'admin', 
        num_total, num_admin)
    sat.finding('All System Privileges', 'PRIV.SYSTEM', summary,
        severity, details, remarks, refs)

    # All roles
    role_list = [x[r_role] for x in role_grants]
    role_list = sorted(list(set(role_list)))
    details = 'Users directly or indirectly granted each role:\n\n'
    num_total = 0
    for role in role_list:
        users = get_role_grantees(role, role_grants, r_grantee, r_role)
        details += '%s: %s\n' % (role, join_list(users))
        num_total += len(users)
    severity, summary = grant_summary('roles', 'admin', num_total, 0)
    remarks = 'Roles are a convenient way to manage groups of related ' + \
        'privileges, especially when the privileges are required ' + \
        'for a particular task or job function. Beware of ' + \
        'broadly defined roles, which may confer more privileges ' + \
        'than an individual recipient requires. Roles should be ' + \
        'granted with admin option only when the recipient needs ' + \
        'the ability to modify the role or grant it to others.'
    refs = {'CIS': 'Recommendation 4.4.1'}
    sat.finding('All Roles', 'PRIV.ROLES', summary,
        severity, details, remarks, refs)

    # User management privileges
    priv_list = ['ALTER USER', 'CREATE USER', 'DROP USER']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'account management privileges'
    remarks = "User management privileges " +\
        '(' + join_list(priv_list) + ') ' + \
        "can be used to create and modify other " \
        "user accounts, including changing passwords. This power " \
        "can be abused to gain access to another user's account, " \
        "which may have greater privileges."
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Account Management Privileges', 'PRIV.ACCT',
        summary, severity, details, remarks)

    # Privilege management privileges
    priv_list = ['ALTER ANY ROLE', 'CREATE ROLE', 'DROP ANY ROLE', 
                 'GRANT ANY OBJECT PRIVILEGE', 
                 'GRANT ANY PRIVILEGE', 'GRANT ANY ROLE']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'privilege management privileges'
    remarks = 'Users with privilege management privileges ' + \
        '(' + join_list(priv_list) + ') ' + \
        'can change the set of ' + \
        'privileges granted to themselves and other users. This ability ' + \
        'should be granted sparingly, since it can be used to circumvent ' + \
        'many security controls in the database.'
    refs = {'CIS': 'Recommendation 4.3.10, 4.3.11, 4.3.12'}
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Privilege Management Privileges', 'PRIV.MGMT',
        summary, severity, details, remarks, refs)

    # Database management privileges
    priv_list = ['ALTER DATABASE', 'ALTER SYSTEM', 'CREATE ANY LIBRARY',
        'CREATE LIBRARY']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'database management privilege'
    remarks = 'Database management privileges ' + \
        '(' + join_list(priv_list) + ') ' + \
        'can be used to change the operation of the database ' + \
        'and potentially bypass security protections. This ability should ' + \
        'be granted only to trusted administrators.'
    refs = {'CIS': 'Recommendation 4.3.7, 4.3.8, 4.3.9'}
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Database Management Privileges', 'PRIV.DBMGMT',
        summary, severity, details, remarks, refs)

    # Audit privileges
    priv_list = ['AUDIT ANY', 'AUDIT SYSTEM']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'audit privilege'
    remarks = 'Audit management privileges ' + \
        '(' + join_list(priv_list) + ') ' + \
        'can be used to change the audit policies ' + \
        'for the database. This ability should be granted sparingly, ' + \
        'since it may be used to hide malicious activity.'
    refs = {'CIS': 'Recommendation 4.3.3'}
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Audit Management Privileges', 'PRIV.AUDIT',
        summary, severity, details, remarks, refs)

    # Data access privileges
    priv_list = ['ALTER ANY TABLE', 'ALTER ANY TRIGGER', 'CREATE ANY INDEX',
                 'CREATE ANY PROCEDURE', 'CREATE ANY TRIGGER', 
                 'DELETE ANY TABLE', 'INSERT ANY TABLE',
                 'READ ANY TABLE', 'SELECT ANY DICTIONARY', 
                 'SELECT ANY TABLE', 'UPDATE ANY TABLE']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'data access privileges'
    remarks = 'Users with data access privileges ' + \
        '(' + join_list(priv_list) + ') ' + \
        'have very broad access to data stored in any schema. ' + \
        'Most administrative tasks do not ' + \
        'require access to the data itself, so these privileges ' + \
        'should be granted rarely even to administrators. ' + \
        'In addition to minimizing grants of these privileges, ' + \
        'consider the use of Database Vault realms to limit the ' + \
        'use of these privileges to access sensitive data.'
    refs = {'CIS': 'Recommendation 4.3.1, 4.3.2'}
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Data Access Privileges', 'PRIV.DATA',
        summary, severity, details, remarks, refs)

    # Exemption privileges
    priv_list = ['EXEMPT ACCESS POLICY', 'EXEMPT REDACTION POLICY']
    privs, heading = filter_system_privs(syspriv_table, priv_list)
    desc= 'access control exemption privileges'
    remarks = 'Users with exemption privileges ' + \
        '(' + join_list(priv_list) + ') ' + \
        'can bypass the row and column access control ' + \
        'policies enforced by Virtual Private Database and ' + \
        'Data Redaction. Most administrative tasks do not require ' + \
        'access to the data itself, so these privileges should be ' + \
        'granted rarely even to administrators.'
    refs = {'CIS': 'Recommendation 4.3.4'}
    severity, summary, details = \
        priv_grant_details(privs, role_dict, 'admin', heading, desc)
    sat.finding('Access Control Exemption Privileges', 'PRIV.EXEMPT',
        summary, severity, details, remarks, refs)

    # Objects containing verifiers
    if verifier_privs is None:
        sat.diag('Skipped Access to Password Verifier checks')
    else:
        priv_grants = [[x[v_grantee],
             x[v_priv]+' on '+x[v_owner]+'.'+x[v_table],
             x[v_admin]] for x in verifier_privs]
        heading = 'Grants of READ, SELECT on objects containing verifiers'
        desc = 'object privileges on objects containing password verifiers'
        severity, summary, details = \
            priv_grant_details(priv_grants, role_dict, 'grant', heading, desc)
        remarks = 'Users with these privileges can access objects ' + \
            'that contain user password verifiers. ' + \
            'The verifiers can be used in offline attacks to discover ' + \
            'user passwords.'
        refs = {'CIS': 'Recommendation 4.5.1, 4.5.2, 4.5.3, 4.5.4, 4.5.6'}
        sat.finding('Access to Password Verifier Tables', 'PRIV.PASSWD',
            summary, severity, details, remarks, refs)

    # Write access to system objects
    if object_privs is None:
        sat.diag('Skipped Access to Restricted Object checks')
    else:
        priv_grants = [[x[o_grantee],
             x[o_priv]+' on '+x[o_owner]+'.'+x[o_table],
             x[o_admin]] for x in object_privs]
        heading = 'Grants of DELETE, INSERT, UPDATE on ' + \
            'SYS, DVSYS, or LBACSYS objects'
        desc = 'object privileges on restricted objects'
        severity, summary, details = \
            priv_grant_details(priv_grants, role_dict, 'grant', heading, desc)
        remarks = 'Users with these privileges can directly modify objects ' + \
            'in the SYS, DVSYS, or LBACSYS schemas. Manipulating these ' + \
            'system objects may allow security protections to be ' + \
            'circumvented or otherwise interfere with normal ' + \
            'operation of the database.'
        sat.finding('Access to Restricted Objects', 'PRIV.OBJ',
            summary, severity, details, remarks)

    if execute_privs is None:
        sat.diag('Skipped Execute Privilege checks')
    else:
        # Execute as other users
        priv_list = ['BECOME USER']
        privs, heading = filter_system_privs(syspriv_table, priv_list)
        desc= 'user impersonation privilege'
        severity, summary, details = \
            priv_grant_details(privs, role_dict, 'admin', heading, desc)
        pkgs = ['DBMS_AQADM_SYS', 'DBMS_AQADM_SYSCALLS', 
            'DBMS_IJOB', 'DBMS_PRVTAQIM', 'DBMS_REPCAT_SQL_UTL',
            'DBMS_SCHEDULER', 'DBMS_STREAMS_ADM_UTL', 'DBMS_STREAMS_RPC',
            'DBMS_SYS_SQL', 'INITJVMAUX', 'LTADM',
            'WWV_DBMS_SQL', 'WWV_EXECUTE_IMMEDIATE']
        priv_grants = [[x[e_grantee],
             x[e_priv]+' on '+x[e_package],
             x[e_admin]] for x in execute_privs if x[e_package] in pkgs]
        heading = 'Grants of EXECUTE on ' + join_list(pkgs)
        desc = 'EXECUTE on restricted packages'
        pkg_severity, pkg_summary, pkg_details = \
            priv_grant_details(priv_grants, role_dict, 'grant', heading, desc)
        severity = max(severity, pkg_severity)
        summary += ' ' + pkg_summary
        if pkg_details:
            details += '\n' + pkg_details
        remarks = 'The BECOME USER privilege and these PL/SQL packages ' + \
            '(' + join_list(pkgs) + ') ' + \
            'allow for execution of SQL code ' + \
            'or external jobs using the identity of a different user. ' + \
            'Access should be strictly limited and ' + \
            'granted only to users with a legitimate need for this ' + \
            'functionality.'
        refs = {'CIS': 'Recommendation 4.1.10, 4.2.1, 4.2.3 - 4.2.13, 4.3.5'}
        sat.finding('User Impersonation', 'PRIV.USER',
            summary, severity, details, remarks, refs)

        # Data exfiltration
        pkgs = ['DBMS_BACKUP_RESTORE', 'UTL_DBWS', 'UTL_ORAMTS'] 
        priv_grants = [[x[e_grantee],
             x[e_priv]+' on '+x[e_package],
             x[e_admin]] for x in execute_privs if x[e_package] in pkgs]
        heading = 'Grants of EXECUTE on ' + join_list(pkgs)
        desc = 'EXECUTE on restricted packages'
        severity, summary, details = \
            priv_grant_details(priv_grants, role_dict, 'grant', heading, desc)
        remarks = 'These PL/SQL packages ' + \
            '(' + join_list(pkgs) + ') ' + \
            'can send data from the ' + \
            'database using the network or file system. Access should be ' + \
            'granted only to users with a legitimate need for this ' + \
            'functionality.'
        refs = {'CIS': 
            'Recommendation 4.1.19, 4.1.20, 4.2.2'}
        sat.finding('Data Exfiltration', 'PRIV.EXFIL',
            summary, severity, details, remarks, refs)

    # System privs to PUBLIC
    priv_grants = [[x[p_grantee], x[p_priv], x[p_admin]] for
        x in system_privs]
    heading = 'Grants of system privileges to PUBLIC'
    desc = 'system privileges to PUBLIC'
    severity, summary, details = \
        priv_grant_details(priv_grants, role_dict, 'admin',
            heading, desc, public_only=True)
    remarks = 'Privileges granted to PUBLIC are available to all ' + \
        'users. This generally should include few, if any, ' + \
        'system privileges since these will not be needed by ordinary ' + \
        'users who are not administrators.'
    sat.finding('System Privileges Granted to PUBLIC', 'PRIV.SYSPUB', summary,
        severity, details, remarks)

    # Roles to PUBLIC
    heading = 'Grants of roles to PUBLIC'
    desc = 'roles to PUBLIC'
    severity, summary, details = \
        role_grant_details(role_dict, None, heading, desc, public_only=True)
    remarks = 'Roles granted to PUBLIC are available to all users. ' + \
        'Most roles contain privileges that are not appropriate ' + \
        'for all users.'
    sat.finding('Roles Granted to PUBLIC', 'PRIV.ROLEPUB', summary,
        severity, details, remarks)

    # Column privs to PUBLIC
    if column_privs is None:
        sat.diag('Skipped Column Privilege checks')
    else:
        priv_grants = [[x[c_grantee],
             x[c_priv]+' on '+x[c_owner]+'.'+x[c_table]+'('+x[c_column]+')',
             x[c_admin]] for x in column_privs]
        heading = 'Grants of column privileges to PUBLIC'
        desc = 'column privileges to PUBLIC'
        severity, summary, details = \
            priv_grant_details(priv_grants, role_dict, 'grant',
                heading, desc, public_only=True)
        remarks = 'Privileges granted to PUBLIC are available to all ' + \
            'users. This should include column privileges only for ' + \
            'data that is intended to be accessible to everyone.'
        sat.finding('Column Privileges Granted to PUBLIC', 'PRIV.COLPUB',
            summary, severity, details, remarks)

    # DBA role
    heading = 'Grants of DBA role'
    desc = 'DBA role'
    severity, summary, details = \
        role_grant_details(role_dict, ('DBA',), heading, desc)
    remarks = 'The DBA role is very powerful and can be used to bypass ' + \
        'many security protections. It should be granted to only ' + \
        'a small number of trusted administrators. Furthermore, ' + \
        'each trusted user should have an individual account for ' + \
        'accountability reasons. As with any powerful role, ' + \
        'avoid granting the DBA role with admin option unless ' + \
        'absolutely necessary.'
    refs = {'CIS': 'Recommendation 4.4.4'}
    sat.finding('DBA Role', 'PRIV.DBA', summary,
        severity, details, remarks, refs)

    # Other powerful roles
    role_list = ('AQ_ADMINISTRATOR_ROLE', 'EM_EXPRESS_ALL', 'EXP_FULL_DATABASE',
        'IMP_FULL_DATABASE', 'SELECT_CATALOG_ROLE', 'EXECUTE_CATALOG_ROLE',
        'DELETE_CATALOG_ROLE', 'OEM_MONITOR')
    heading = 'Grants of %s roles' % join_list(role_list)
    desc = 'powerful roles'
    severity, summary, details = \
        role_grant_details(role_dict, role_list, heading, desc)
    remarks = 'Like the DBA role, these roles ' + \
        '(' + join_list(role_list) + ') ' + \
        'contain powerful privileges that can be used to bypass security ' + \
        'protections. They should be granted only to a small ' + \
        'number of trusted administrators.'
    refs = {'CIS': 'Recommendation 4.4.1, 4.4.2, 4.4.3'}
    sat.finding('Other Powerful Roles', 'PRIV.BIGROLES', summary,
        severity, details, remarks, refs)

# PRIV.JAVA - Java Permissions
def java_permission():
    data = sat.get_data('java_permission', 1)
    if data is None:
        sat.diag('Skipped Java Permissions')
        return

    grantee = sat.get_index('java_permission', 'grantee')
    kind = sat.get_index('java_permission', 'kind')
    t_name = sat.get_index('java_permission', 'type_name')
    t_schema = sat.get_index('java_permission', 'type_schema')
    name = sat.get_index('java_permission', 'name')
    action = sat.get_index('java_permission', 'action')

    details = ''
    g_user = None
    num_grantees = 0
    users_to_report = all_users + all_roles + ['PUBLIC']

    for x in data:
        if x[grantee] not in users_to_report:
            continue

        # The collected data is expected to be sorted by grantee.
        if g_user is None:
            details += 'Grantee: ' + x[grantee] + '\n'
            num_grantees += 1
        elif g_user != x[grantee]:
            details += '\nGrantee: ' + x[grantee] + '\n'
            num_grantees += 1

        details += x[kind] + ', '
        details += 'Name: ' + x[name] + ', '
        details += 'Type Schema: ' + x[t_schema] + ', '
        details += 'Type Name: ' + x[t_name]
        if len(x[action]) > 0:
            details += ', Action: ' + x[action]
        details += '\n'
        g_user = x[grantee]

    if num_grantees > 0:
        summary = 'Found ' + sing_plural(num_grantees, 'user or role',
                                                       'users or roles') + \
                  ' with Java permission.'
    else:
        summary = 'No users or roles granted Java permission found.'

    if len(data) > 0:
        severity = sat.SEV_UNKNOWN
    else:
        severity = sat.SEV_OK

    remarks = 'Java permission grants control the ability of database ' + \
        'users to execute Java classes within the database server. ' + \
        'A database user executing Java code must have both Java security ' + \
        'permissions and database privileges to access resources within ' + \
        'the database. These resources include database ' + \
        'resources, such as tables and PL/SQL packages, operating system ' + \
        'resources, such as files and sockets, Oracle JVM classes, and ' + \
        'user-loaded classes. Make sure that these permissions are ' + \
        'limited to the minimum required by each user.'

    sat.finding('Java Permissions', 'PRIV.JAVA', summary,
        severity, details, remarks)

# PRIV.ADMIN - Users with Administrative Privileges
def user_password_file():
    data = sat.get_data('user_password_file', 1)
    if data is None:
        sat.diag('Skipped Administrative Privileges')
        return

    name = sat.get_index('user_password_file', 'username')
    sysdba = sat.get_index('user_password_file', 'sysdba')
    sysoper = sat.get_index('user_password_file', 'sysoper')
    sysbackup = sat.get_index('user_password_file', 'sysbackup')
    sysdg = sat.get_index('user_password_file', 'sysdg')
    syskm = sat.get_index('user_password_file', 'syskm')

    sysdba_user_list = []
    sysoper_user_list = []
    sysbackup_user_list = []
    sysdg_user_list = []
    syskm_user_list = []

    if sysdba is not None:
        sysdba_user_list = [x[name] for x in data if x[sysdba]]
    if sysoper is not None:
        sysoper_user_list = [x[name] for x in data if x[sysoper]]
    if sysbackup is not None:
        sysbackup_user_list = [x[name] for x in data if x[sysbackup]]
    if sysdg is not None:
        sysdg_user_list = [x[name] for x in data if x[sysdg]]
    if syskm is not None:
        syskm_user_list = [x[name] for x in data if x[syskm]]

    all_grantees = sysdba_user_list + sysoper_user_list + \
       sysbackup_user_list + sysdg_user_list + syskm_user_list
    all_grantees = set(all_grantees)
    ungranted_privs = 0;

    if sysdba is not None and len(sysdba_user_list) == 0:
        ungranted_privs += 1
    if sysoper is not None and len(sysoper_user_list) == 0:
        ungranted_privs += 1
    if sysbackup is not None and len(sysbackup_user_list) == 0:
        ungranted_privs += 1
    if sysdg is not None  and len(sysdg_user_list) == 0:
        ungranted_privs += 1
    if syskm is not None and len(syskm_user_list) == 0:
        ungranted_privs += 1

    if ungranted_privs > 0:
        severity = sat.SEV_LOW
    else:
        severity = sat.SEV_UNKNOWN

    summary = 'Found ' + sing_plural(len(all_grantees), 'user', 'users') + \
              ' granted administrative privileges. ' + \
              'Found ' + sing_plural(ungranted_privs, 
                                     'administrative privilege',
                                     'administrative privileges') + \
              ' not granted to any user.'

    details = 'SYSDBA    (%d): ' % len(sysdba_user_list) + \
              join_list(sysdba_user_list) + '\n'
    details += 'SYSOPER   (%d): ' % len(sysoper_user_list) + \
              join_list(sysoper_user_list) +  '\n'
    if sysbackup:
        details += 'SYSBACKUP (%d): ' % len(sysbackup_user_list) + \
                   join_list(sysbackup_user_list) + '\n'
    if sysdg:
        details += 'SYSDG     (%d): ' % len(sysdg_user_list) + \
                   join_list(sysdg_user_list) + '\n'
    if syskm:
        details += 'SYSKM     (%d): ' % len(syskm_user_list) + \
                   join_list(syskm_user_list) + '\n'

    remarks = 'Administrative privileges allow a user to perform ' + \
        'maintenance operations, including some that may occur ' + \
        'while the database is not open. The SYSDBA privilege ' + \
        'allows the user to run as SYS and perform virtually all ' + \
        'privileged operations. Starting with Oracle Database ' + \
        '12.1, less powerful administrative privileges were ' + \
        'introduced to allow users to perform common ' + \
        'administrative tasks with less than full SYSDBA ' + \
        'privileges. To achieve the benefit of this separation ' + \
        'of duty, each of these administrative privileges should ' + \
        'be granted to at least one user account.'

    sat.finding('Users with Administrative Privileges', 'PRIV.ADMIN',
        summary, severity, details, remarks)

# priv_grant_recur
#   grantee - single grantee to include
#   prefix - grant path prior to grantee
#   priv_grants - dictionary mapping grantee -> (priv, is_admin)
#   role_grants - dictionary mapping grantee -> (role, is_admin)
# Returns
#   num_total - total number of grants found
#   num_admin - number of grants with admin option
#   details - text output listing direct and indirect grants
#   roleset - roles included in output
#
# Recursive routine called by priv_grant_details()
#
def priv_grant_recur(grantee, prefix, priv_grants, role_grants):
    if prefix == '':
        prefix = grantee
    else:
        prefix = prefix + ' <- ' + grantee

    directs = priv_grants.get(grantee, [])
    list1 = [x[0]+'(*)' for x in directs if x[1]]
    list2 = [x[0] for x in directs if not x[1]]
    num_admin = len(list1)
    num_total = num_admin + len(list2)
    if num_total == 0:
        details = ''
    else:
        details = '%s: %s\n' % (prefix, join_list(sorted(list1 + list2)))

    roles_granted = [x[0] for x in role_grants.get(grantee, [])]
    roleset = set(roles_granted)
    for role in sorted(roles_granted):
        (role_total, role_admin, role_details, role_roleset) = \
            priv_grant_recur(role, prefix, priv_grants, role_grants)
        num_total += role_total
        num_admin += role_admin
        details += role_details
        roleset |= role_roleset

    return (num_total, num_admin, details, roleset)

# priv_grant_details
#   priv_grants - list of rows containing grantee, privilege, is_admin columns
#   role_grants - dictionary mapping grantee -> (role, is_admin)
#   admin_name - name of admin option ('admin' or 'grant')
#   heading - first line of details output, enumerating privileges checked
#   desc - description of privilege group used to form summary
#   public_only - if True, check only grants to PUBLIC
# Returns
#   severity - OK if no grants found, MEDIUM if PUBLIC grants found,
#              UNKNOWN in all other cases
#   summary - overall summary including number of regular and admin grants
#   details - text output listing direct and indirect grants
#
# Compactly format information about direct and indirect privilege grants
# including grant path and whether privilege is granted with admin/grant
# option. Summary includes separate counts for regular grants and grants
# to public, unless public_only is true.
#
def priv_grant_details(priv_grants, role_grants, admin_name,
                         heading, desc, public_only=False):
    num_total = 0
    num_admin = 0
    details = ''
    pub_summary = ''

    # Create dictionary from priv_grants table
    priv_dict = {}
    for x in priv_grants:
        priv_dict[x[0]] = priv_dict.get(x[0], []) + [[x[1], x[2]]]

    # Check for grants to PUBLIC
    num_total, num_admin, pub_details, roleset = \
        priv_grant_recur('PUBLIC', '', priv_dict, role_grants)
    if num_total > 0:
        details = pub_details + '\n'
        pub_summary = sing_plural(num_total, 'grant', 'grants') + ' to PUBLIC.'

    if not public_only:
        # Users with direct or indirect grants
        for name in all_users:
            (name_total, name_admin, name_details, name_roleset) = \
                priv_grant_recur(name, '', priv_dict, role_grants)
            num_total += name_total
            num_admin += name_admin
            if name_details != '':
                details += name_details + '\n'
            roleset |= name_roleset

        # Roles (not appearing in user grants above) with privilege grants
        roles = set(all_roles)
        roles -= roleset
        for name in sorted(list(roles)):
            (name_total, name_admin, name_details, name_roleset) = \
                priv_grant_recur(name, '(no users)', priv_dict, role_grants)
            num_total += name_total
            num_admin += name_admin
            if name_details != '':
                details += name_details + '\n'

    if num_admin > 0:
        details += '(*) = granted with %s option' % admin_name
    if details:
        details = heading + ':\n\n' + details
    severity, summary = grant_summary(desc, admin_name, num_total, num_admin)
    if pub_summary:
        severity = sat.SEV_MEDIUM
        if not public_only:
            summary += ' ' + pub_summary 

    return (severity, summary, details)

# role_grant_recur
#   grantee - single grantee to include
#   prefix - grant path prior to grantee
#   role_grants - dictionary mapping grantee -> (role, is_admin)
#   role_list - list of roles to report (None means all roles)
# Returns
#   num_total - total number of grants found
#   num_admin - number of grants with admin option
#   details - text output listing direct and indirect grants
#   roleset - roles included in output
#
# Recursive routine called by role_grant_details().
#
def role_grant_recur(grantee, prefix, role_grants, role_list):
    if prefix == '':
        prefix = grantee
    else:
        prefix = prefix + ' <- ' + grantee

    direct_roles = role_grants.get(grantee, [])
    if role_list == None:
        directs = direct_roles
    else:
        directs = [x for x in direct_roles if x[0] in role_list]
    list1 = [x[0]+'(*)' for x in directs if x[1]]
    list2 = [x[0] for x in directs if not x[1]]
    num_admin = len(list1)
    num_total = num_admin + len(list2)
    if num_total == 0:
        details = ''
    else:
        details = '%s: %s\n' % (prefix, join_list(list1 + list2))

    roles_granted = [x[0] for x in direct_roles]
    roleset = set(roles_granted)
    for role in sorted(roles_granted):
        (role_total, role_admin, role_details, role_roleset) = \
            role_grant_recur(role, prefix, role_grants, role_list)
        num_total += role_total
        num_admin += role_admin
        details += role_details
        roleset |= role_roleset

    return (num_total, num_admin, details, roleset)

# role_grant_details
#   role_grants - dictionary mapping grantee -> (role, is_admin)
#   role_list - list of roles to report (None means all roles)
#   heading - first line of details output, enumerating privileges checked
#   desc - description of privilege group used to form summary
#   public_only - if True, check only grants to PUBLIC
# Returns
#   severity - OK if no grants found, MEDIUM if PUBLIC grants found,
#              UNKNOWN in all other cases
#   summary - overall summary including number of regular and admin grants
#   details - text output listing direct and indirect grants
#
# Compactly format information about direct and indirect role grants
# including grant path and whether role is granted with admin option.
# Summary includes separate counts for regular grants and grants
# to public, unless public_only is true.
#
def role_grant_details(role_grants, role_list, heading, desc, public_only=False):
    num_total = 0
    num_admin = 0
    details = ''
    pub_summary = ''

    # Check for grants to PUBLIC
    num_total, num_admin, pub_details, roleset = \
        role_grant_recur('PUBLIC', '', role_grants, role_list)
    if num_total > 0:
        details = pub_details + '\n'
        pub_summary = sing_plural(num_total, 'grant', 'grants') + ' to PUBLIC.'

    if not public_only:
        # Users with direct or indirect grants
        for name in all_users:
            (name_total, name_admin, name_details, name_roleset) = \
                role_grant_recur(name, '', role_grants, role_list)
            num_total += name_total
            num_admin += name_admin
            if name_details != '':
                details += name_details + '\n'
            roleset |= name_roleset

        # Roles (not appearing in user grants above) with role grants
        roles = set(all_roles)
        roles -= roleset
        for name in sorted(list(roles)):
            (name_total, name_admin, name_details, name_roleset) = \
                role_grant_recur(name, '(no users)', role_grants, role_list)
            num_total += name_total
            num_admin += name_admin
            if name_details != '':
                details += name_details + '\n'

    if num_admin > 0:
        details += '(*) = granted with admin option'
    if details:
        details = heading + ':\n\n' + details
    severity, summary = grant_summary(desc, 'admin', num_total, num_admin)
    if pub_summary:
        severity = sat.SEV_MEDIUM
        if not public_only:
            summary += ' ' + pub_summary 

    return (severity, summary, details)

# grant_summary
#   desc - description of grants
#   admin_name - name of admin option ('admin' or 'grant')
#   num_total - total number of grants
#   num_admin - number of grants with admin option
# Returns
#   severity - severity to report (OK if no grants, else UNKNOWN)
#   msg - summary message
#
def grant_summary(desc, admin_name, num_total, num_admin):
    if num_total == 0:
        msg = 'No grants of ' + desc
        severity = sat.SEV_OK
    else:
        severity = sat.SEV_UNKNOWN
        if num_total == 1:
            msg = '1 grant of ' + desc
        else:
            msg = '%d grants of %s' % (num_total, desc)
    if num_admin > 0:
        msg += ' (%d with %s option)' % (num_admin, admin_name)
    return severity, msg + '.'

# filter_system_privs
#   syspriv_grants - table of all system privilege grants
#   priv_list - privileges to include in output table (None for no filtering)
# Returns
#   priv_grants - table including only specified privileges
#   heading - first line of details output, listing privileges
#
def filter_system_privs(syspriv_grants, priv_list):
    if priv_list:
        priv_grants = [x for x in syspriv_grants if x[1] in priv_list]
        heading = 'Grants of ' + join_list(priv_list)
    else:
        priv_grants = syspriv_grants
        heading = 'Grants of system privileges'
    return priv_grants, heading

# get_role_grantees
#   role        - target role
#   role_grants - list of rows containing grantee, role
#   r_grantee   - index of grantee column
#   r_role      - index of role column
# Returns
#   u_list      - list of users who are granted the roles
#
# This routine is called recursively.
#
def get_role_grantees(role, role_grants, r_grantee, r_role):
    users = []

    for rg in role_grants:
        if rg[r_role] == role:
            grantee = rg[r_grantee]
            if grantee in all_roles:
                users += get_role_grantees(grantee, 
                             role_grants, r_grantee, r_role)
            elif grantee in acct_profiles:
                users.append(grantee)

    return sorted(list(set(users)))

# get_sys_priv_grantees
#   priv - target system privilege
# Returns
#   users - list of users who are granted the target privilege directly or
#           indirectly (through roles)
#   num_admin - number of grants with admin option
#
def get_sys_priv_grantees(priv):
    system_privs = sat.get_data('system_privs', 1)
    role_grants = sat.get_data('role_grants', 1)
    if system_privs is None or role_grants is None or all_roles is None:
        sat.diag('Skipped Get System Privilege Grantees')
        return None

    s_grantee = sat.get_index('system_privs', 'grantee')
    s_priv = sat.get_index('system_privs', 'privilege')
    s_admin = sat.get_index('system_privs', 'is_admin')
    r_grantee = sat.get_index('role_grants', 'grantee')
    r_role = sat.get_index('role_grants', 'granted_role')

    # For each user granted the privilege (directly or indirectly),
    # record whether the grant is with admin option or not.
    has_admin = {}
    for x in system_privs:
        if x[s_priv] == priv:
            grantee = x[s_grantee]
            admin = x[s_admin]
            if grantee in all_roles:
                for u in get_role_grantees(grantee, role_grants, 
                r_grantee, r_role):
                    has_admin[u] = has_admin.get(u, False) | admin
            elif grantee in acct_profiles:
                has_admin[grantee] = has_admin.get(grantee, False) | admin

    users = []
    num_admin = 0
    for u in sorted(has_admin.keys()):
        if has_admin[u]:
            users.append(u + '(*)')
            num_admin += 1
        else:
            users.append(u)
    return users, num_admin

# get_execute_grantees
#   name  - the name of the target package (must be SYS-owned)
# Returns
#   users - list of users who are granted the EXECUTE privilege
#           on the target package directly or indirectly (through roles)
#
def get_execute_grantees(package):
    exec_data = sat.get_data('execute_privs', 2)
    role_grants = sat.get_data('role_grants', 1)

    if exec_data is None or role_grants is None:
        return None

    p_grantee = sat.get_index('execute_privs', 'grantee')
    p_priv = sat.get_index('execute_privs', 'privilege')
    p_name = sat.get_index('execute_privs', 'package')
    r_grantee = sat.get_index('role_grants', 'grantee')
    r_role = sat.get_index('role_grants', 'granted_role')

    # Find all users that are directly or indirectly granted the privilege.
    users = set()
    for x in exec_data:
        if x[p_name] == package and x[p_priv] == 'EXECUTE':
            grantee = x[p_grantee]
            if grantee in all_roles:
                for u in get_role_grantees(grantee, role_grants, 
                r_grantee, r_role):
                    users = users.union(set([u]))
            elif grantee in acct_profiles:
                users = users.union(set([grantee]))

    return sorted(list(users))

###
### Authorization Control
###

# AUTH.DV - Database Vault
def database_vault():
    dv_option = db_options_dict.get('Oracle Database Vault', False)
    severity = sat.SEV_UNKNOWN
    summary = ''
    details = ''

    if not dv_option:
        severity = sat.SEV_ENHANCEMENT
        summary = 'Database Vault is not enabled.'
        details = None
    else:
        dv_rlm_data = sat.get_data('dv_realm', 1)
        dv_cmd_rule_data = sat.get_data('dv_command_rule', 1)
        dv_rlm_obj_data = sat.get_data('dv_realm_object', 1)

        if dv_rlm_data is None and dv_cmd_rule_data is None and \
           dv_rlm_obj_data is None:
            sat.diag('Skipped Database Vault Checks')
            return
        else:
            rlm_name = sat.get_index('dv_realm', 'name')
            rlm_enabled = sat.get_index('dv_realm', 'enabled')
            default_realm = sat.get_index('dv_realm', 'oracle_supplied')

            name = sat.get_index('dv_realm_object', 'realm_name')
            owner = sat.get_index('dv_realm_object', 'owner')
            obj_name = sat.get_index('dv_realm_object', 'object_name')
            obj_type = sat.get_index('dv_realm_object', 'object_type')

            cmd_rule_enabled = sat.get_index('dv_command_rule', 'enabled')
            cmd_name = sat.get_index('dv_command_rule', 'command')
            obj_owner= sat.get_index('dv_command_rule', 'object_owner')
            obj_name = sat.get_index('dv_command_rule', 'object_name')
            clause = sat.get_index('dv_command_rule', 'clause_name')
            parameter_name = sat.get_index('dv_command_rule', 'parameter_name')
            event_name = sat.get_index('dv_command_rule', 'event_name')
            component_name = sat.get_index('dv_command_rule', 'component_name')
            action_name = sat.get_index('dv_command_rule', 'action_name')
            def_cmd_rule = sat.get_index('dv_command_rule', 'oracle_supplied')

            cmd_rules = []
            for x in dv_cmd_rule_data:
                cmd = x[cmd_name]
                if clause is not None and x[clause] != '%':
                    cmd += ' ' + x[clause]
                if parameter_name is not None and x[parameter_name] != '%': 
                    cmd += ' ' + x[parameter_name]
                if event_name is not None and x[event_name] != '%':
                    cmd += ' ' + x[event_name]
                if component_name is not None and x[component_name] != '%':
                    cmd += ' ' + x[component_name]
                if action_name is not None and x[action_name] != '%':
                    cmd += ' ' + x[action_name]
                if x[obj_owner] == '%':
                    object_owner = '<Any Schema>'
                else:
                    object_owner = x[obj_owner]
                if x[obj_name] == '%':
                    object_name = '<Any Object>'
                else:
                    object_name = x[obj_name]

                if x[obj_owner] != '%' or x[obj_name] != '%':
                    cmd += ' on ' + object_owner + '.' + object_name
               
                if x[cmd_rule_enabled]: 
                    cmd += ' (Enabled)'
                else:
                    cmd += ' (Disabled)'

                if def_cmd_rule and x[def_cmd_rule]:
                    cmd += ' (Default)'
                cmd_rules.append(cmd)

            rlms = []
            for x in dv_rlm_data:
                rlm = x[rlm_name]
                if x[rlm_enabled]:
                    rlm += ' (Enabled)'
                else:
                    rlm += ' (Disabled)' 
                if default_realm and x[default_realm]:
                    rlm += ' (Default)'

                rlm += '\n'
                role_list = [y[obj_name] for y in dv_rlm_obj_data \
                             if y[name] == x[rlm_name] and \
                                y[obj_type] == 'ROLE']
                rlm += 'Protects roles: %s\n' % join_list(role_list)

                obj_list = []
                for y in dv_rlm_obj_data:
                    if y[name] == x[rlm_name] and y[obj_type] != 'ROLE':
                        if y[obj_name] == '%':
                            obj = y[owner] + '.<Any Object>'
                        else:
                            obj = y[owner] + '.' + y[obj_name]
                        if y[obj_type] == '%':
                            obj += ' (Any Type)'
                        else:
                            obj += ' (' + y[obj_type] + ')'
                        obj_list.append(obj)
                rlm += 'Protects objects: %s\n' % join_list(obj_list) 

                rlms.append(rlm)
            
            if len(dv_rlm_data) == 0 and len(dv_cmd_rule_data) == 0:
                severity = sat.SEV_LOW
                summary = 'No Database Vault realms or command rules found.'
            else:
                severity = sat.SEV_UNKNOWN
                summary = 'Found ' + \
                          sing_plural(len(dv_rlm_data), 'Database Vault realm', 
                                      'Database Vault realms') + \
                          ' and ' + \
                          sing_plural(len(dv_cmd_rule_data), 
                                      'command rule.', 'command rules.')
                details += 'Realms:\n'
                details += join_list(rlms, '\n')
                details += '\n\n'
                details += 'Command rules:\n'
                details += join_list(cmd_rules, '\n')

        role_grants = sat.get_data('role_grants', 1)
        sys_role_grants = sat.get_data('sys_role_grants', 1)
        if role_grants is None or sys_role_grants is None or all_roles is None:
            sat.diag('Skipped Database Vault roles grant info')
        else:
            r_grantee = sat.get_index('role_grants', 'grantee')
            r_role = sat.get_index('role_grants', 'granted_role')
            s_role = sat.get_index('sys_role_grants', 'granted_role')
            sys_roles = [x[s_role] for x in sys_role_grants]

            details += '\n\n'
            # DV_OWNER must be processed before DV_PATCH_ADMIN. Do not change
            # the current order.
            dv_roles = ['DV_OWNER', 'DV_ADMIN', 'DV_PATCH_ADMIN', \
                        'DV_AUDIT_CLEANUP', 'DV_ACCTMGR']
            # the following roles can be granted to SYS.
            sys_grantable = ['DV_PATCH_ADMIN', 'DV_ACCTMGR']

            for x in dv_roles:
                owners = get_role_grantees(x, role_grants, r_grantee, r_role)
                if x in sys_grantable:
                    owners.append('SYS')
                if x == 'DV_OWNER':
                    dv_owners = owners
                # DV_PATCH_ADMIN is granted to DV_OWNER by default, but
                # DV_OWNER users cannot use this role. Remove DV_OWNER users.
                elif x == 'DV_PATCH_ADMIN':
                    owners = [u for u in owners if u not in dv_owners]
                details += 'Users with %s role: ' % x
                details += join_list(owners) + '\n'
             
    remarks = 'Database Vault provides for configurable policies to ' + \
        'control the actions of privileged administrative users, ' + \
        'in order to protect against insider threats, stolen ' + \
        'credentials, and human error. Database Vault realms prevent ' + \
        'unauthorized access to sensitive data objects, even by ' + \
        'users with system privileges. Command rules limit the ' + \
        'SQL commands and options that administrators can execute.'
    refs = {'GDPR': 'Article 6, 25, 29, 32, 34, 89; Recital 28, 29, 78, 156' }
    sat.finding('Database Vault', 'AUTH.DV', summary,
        severity, details, remarks, refs)

# AUTH.PRIV - Privilege Analysis
def privilege_capture():
    data = sat.get_data('privilege_capture', 1)
    if data is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped Privilege Analysis')
        return

    if len(data) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + \
                  sing_plural(len(data), 'privilege analysis policy.', 
                                         'privilege analysis policies.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No privilege analysis policies found.'

    name = sat.get_index('privilege_capture', 'name')
    type = sat.get_index('privilege_capture', 'type')
    enabled = sat.get_index('privilege_capture', 'enabled')
    begin = sat.get_index('privilege_capture', 'last_begin');
    end = sat.get_index('privilege_capture', 'last_end')

    details = ''

    for x in data:
        details += 'Policy ' + x[name] + ' (Type: ' + x[type] + ', '
        if x[enabled]:
            details += 'Currently running)\n'
        elif len(x[begin]) == 0 or len(x[end]) == 0:
            details += 'Never been run)\n'
        else:
            begin_time = format_date(read_date(x[begin]))
            end_time = format_date(read_date(x[end]))
            details += 'Latest run: ' + begin_time + ' - ' + end_time + ')\n'

    exec_users = get_execute_grantees('DBMS_PRIVILEGE_CAPTURE')
    if exec_users is not None:
        details += '\nUsers with EXECUTE on SYS.DBMS_PRIVILEGE_CAPTURE: '
        details += join_list(exec_users)

    remarks = 'Database Vault Privilege Analysis records the privileges ' + \
        'used during a ' + \
        'real or simulated workload. After collecting data about ' + \
        'the privileges that are actually used, this information can be ' + \
        'used to revoke privilege grants that are no longer needed.'

    sat.finding('Privilege Analysis', 'AUTH.PRIV', summary,
        severity=severity, details=details, remarks=remarks)

###
### Data Encryption
###

# CRYPT.TDE - Transparent Data Encryption
def data_encryption():
    tdata = sat.get_data('encrypted_tablespace', 2)
    enc_ts = []
    summary = ''
    details = ''

    if tdata is None:
        sat.diag('Skipped Encrypted Tablespaces')
    else:
        name = sat.get_index('encrypted_tablespace', 'name')
        algo = sat.get_index('encrypted_tablespace', 'algo')
        unenc_ts = []

        for x in tdata:
            if len(x[algo]) > 0:
                enc_ts.append(x[name] + ' (' + x[algo] + ')')
            else:
                unenc_ts.append(x[name])

        if len(enc_ts) > 0:
            summary += 'Found ' + \
                       sing_plural(len(enc_ts), 'encrypted tablespace. ',
                                                'encrypted tablespaces. ')
            details += 'Encrypted tablespaces: ' + join_list(enc_ts) + '\n'
            details += 'Unencrypted tablespaces: ' + join_list(unenc_ts)
            details += '\n\n'
        else:
            summary += 'No encrypted tablespaces found. '

    cdata = sat.get_data('encrypted_column', 1)
    enc_col = []
    if cdata is None:
        sat.diag('Skipped Encrypted Columns')
    else:
        owner = sat.get_index('encrypted_column', 'owner')
        tab_name = sat.get_index('encrypted_column', 'table_name')
        col_name = sat.get_index('encrypted_column', 'column_name')
        algo = sat.get_index('encrypted_column', 'encryption_alg')

        if len(cdata) > 0:
            summary += 'Found ' + \
                       sing_plural(len(cdata), 
                                   'encrypted column.', 'encrypted columns.')
            for x in cdata:
                enc_col.append('Column ' + x[col_name] + ' of ' + x[owner] + \
                               '.' + x[tab_name] + ' (' + x[algo] + ')')
            details += 'Encrypted columns: ' + join_list(enc_col) + '\n\n'
        else:
            summary += 'No encrypted columns found.'

    # no data collected for data encryption; return.
    if tdata is None and cdata is None and wdata is None:
        return

    checked, num_issues, param_details = \
       param_should('ENCRYPT_NEW_TABLESPACES', 'ALWAYS')

    if checked == 0:
        if target_db_version >= '12.2':
            sat.diag('Skipped ENCRYPT_NEW_TABLESPACES Parameter Check')
    else:
        summary += ' Examined ' + \
                   sing_plural(checked, 'initialization parameter.',
                                        'initialization parameters.')
        details += param_details

    if (len(enc_ts) + len(enc_col)) == 0:
        severity = sat.SEV_ENHANCEMENT
    else:
        if checked > 0 and num_issues > 0:
            severity = sat.SEV_ENHANCEMENT
        else:
            severity = sat.SEV_UNKNOWN

    remarks = 'Encryption of some sensitive data is a requirement ' + \
        'in certain regulated environments. ' + \
        'Transparent Data Encryption automatically encrypts ' + \
        'data as it is stored and decrypts it upon retrieval. ' + \
        'This protects sensitive data from attacks that bypass ' + \
        'the database to read data files directly. ' + \
        'Encryption keys may be stored in wallets on the database ' + \
        'server itself, or stored remotely in Oracle Key Vault for ' + \
        'improved security. '

    if checked > 0:
        remarks += 'The ENCRYPT_NEW_TABLESPACES parameter ensures '     + \
                   'that TDE tablespace encryption is applied to all '  + \
                   'newly created tablespaces. Setting this parameter ' + \
                   'to ALWAYS is recommended in order to protect all '  + \
                   'data regardless of the options specified when the ' + \
                   'tablespace is created.'
    refs = {'GDPR': 'Article 6, 32, 34; Recital 83'}
    sat.finding('Transparent Data Encryption', 'CRYPT.TDE', summary,
        severity, details, remarks, refs)

# CRYPT.WALLET - Encryption Key Wallet
def encryption_wallet():
    oh_dir = get_from_env_data('ORACLE_HOME')
    wdata = sat.get_data('encryption_wallet', 2)
    if oh_dir is None or wdata is None:
        sat.diag('Skipped Encryption Wallets')
        return

    type = sat.get_index('encryption_wallet', 'wrl_type')
    param = sat.get_index('encryption_wallet', 'wrl_parameter')
    status = sat.get_index('encryption_wallet', 'status')
    wtype = sat.get_index('encryption_wallet', 'wallet_type')
    order = sat.get_index('encryption_wallet', 'wallet_order')

    details = ''
    if len(wdata) > 0:
        summary = 'Found ' + sing_plural(len(wdata), 'wallet.', 'wallets.')
        for x in wdata:
            details += 'Encryption wallet location: ' + x[param] + '\n'
            details += 'Wallet type: ' + x[type] + '\n'
            details += 'Status: ' + x[status] + '\n'
            if wtype is not None:
               details += 'Keystore type: ' + x[wtype] + '\n'
            if order is not None:
               details += 'Wallet order: ' + x[order] + '\n'
            details += '\n'
    else:
        summary = 'No encryption wallets found.'

    if oh_dir[-1] != '/':
        oh_dir += '/'
    dbs_dir = oh_dir + 'dbs'

    details += 'Data file directory: %s\n' % dbs_dir
    wallets_with_dbs = []
    for x in wdata:
        if dbs_dir in x[param]:
            wallets_with_dbs.append(x[param])

    if len(wallets_with_dbs) > 0:
        severity = sat.SEV_MEDIUM
        summary += ' Found ' + sing_plural(len(wallet_with_dbs), 
                                           'wallet', 'wallets') + \
                   ' stored in the data file directory.'
        details += 'Wallets stored together with data files: \n'
        details += join_list(wallet_with_dbs, '\n')
    else:
        severity = sat.SEV_UNKNOWN
        summary += ' No wallets are stored in the data file directory.'

    remarks = 'Wallets are encrypted files used to store encryption keys, ' + \
        'passwords, and other sensitive data. Wallet files should not be '+ \
        'stored in the same directory with database data files, to avoid ' + \
        'accidentally creating backups that include both encrypted data ' + \
        'files and the wallet containing the master key protecting those ' + \
        'files. For maximum separation of keys and data, consider storing ' + \
        'encryption keys in Oracle Key Vault instead of wallet files.'
    refs = {'GDPR': 'Article 6, 32, 34; Recital 83'}

    sat.finding('Encryption Key Wallet', 'CRYPT.WALLET', summary,
        severity, details, remarks, refs)

###
### Fine-Grained Access Control
###

# ACCESS.REDACT - Data Redaction
def redaction():
    data = sat.get_data('redaction_policy', 1)
    if data is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped Redaction Policies')
        return

    obj_owner = sat.get_index('redaction_policy', 'object_owner')
    obj_name = sat.get_index('redaction_policy', 'object_name')
    pol_name = sat.get_index('redaction_policy', 'policy_name')
    col_name = sat.get_index('redaction_policy', 'column_name')

    pol_list = [x[pol_name] for x in data]
    if len(pol_list) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + \
                 sing_plural(len(set(pol_list)), 'data redaction policy', 
                                                 'data redaction policies') + \
                 ' protecting ' +  sing_plural(len(data), 'object.', 'objects.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No data redaction policies found.'

    dict = {}
    for x in data:
        str = x[obj_owner] + '.' + x[obj_name] + ' (col ' + x[col_name] + ')'
        if x[pol_name] in dict:
            dict.get(x[pol_name]).append(str)
        else:
            dict[x[pol_name]] = [str]

    details = ''
    for k, v in dict.items():
        details += 'Policy ' + k + ': Protects ' + join_list(v) + '\n'

    exempt_privs = ['EXEMPT REDACTION POLICY']
    for p in exempt_privs:
        g_list, num_admin = get_sys_priv_grantees(p)
        if g_list is not None:
            details += '\nUsers with ' + p + ' privilege: '
            details += join_list(g_list)

    exec_users = get_execute_grantees('DBMS_REDACT')
    if exec_users is not None:
        details += '\nUsers with EXECUTE on SYS.DBMS_REDACT: '
        details += join_list(exec_users)

    remarks = 'Data Redaction automatically masks sensitive data found ' + \
        'in the results of a database query. The data is masked ' + \
        'immediately before it is returned as part of the result ' + \
        'set, so it does not interfere with any conditions ' + \
        'specified as part of the query. ' + \
        'Access by users with the EXEMPT REDACTION POLICY privilege ' + \
        'will not be affected by the redaction policy. Users who can ' + \
        'execute the DBMS_REDACT package are able to create and modify ' + \
        'redaction policies. ' + \
        'Also consider the use of Oracle Data Masking and Subsetting to ' + \
        'permanently mask sensitive data when making copies for test ' + \
        'or development use.'
    refs = {'GDPR': 'Article 6, 25, 32, 34, 89; Recital 28, 29, 78, 156'}

    sat.finding('Data Redaction', 'ACCESS.REDACT', summary,
        severity, details, remarks, refs)

# ACCESS.VPD - Virtual Private Database
def vpd_policy():
    data = sat.get_data('vpd_policy', 1)
    if data is None:
        sat.diag('Skipped VPD Policies')
        return

    pol_name = sat.get_index('vpd_policy', 'policy_name')
    pf_owner = sat.get_index('vpd_policy', 'pf_owner')
    pol_function = sat.get_index('vpd_policy', 'function')
    obj_owner = sat.get_index('vpd_policy', 'object_owner')
    obj_name = sat.get_index('vpd_policy', 'object_name')

    pol_list = [x[pol_name] for x in data]
    if len(pol_list) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + sing_plural(len(set(pol_list)), 
                                         'VPD policy', 'VPD policies') + \
                  ' protecting ' + sing_plural(len(data), 'object.', 'objects.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No VPD policies found.'

    dict = {}
    for x in data:
        str = x[obj_owner] + '.' + x[obj_name]
        if x[pol_name] in dict:
            dict.get(x[pol_name]).append(str)
        else:
            dict[x[pol_name]] = [str]

    details = ''
    for k, v in dict.items():
        details += 'Policy ' + k + ': Protects ' + join_list(v) + '\n'

    exempt_priv = 'EXEMPT ACCESS POLICY'
    g_list, num_admin = get_sys_priv_grantees(exempt_priv)
    if g_list is not None:
        details += '\nUsers with ' + exempt_priv + ' privilege: '
        details += join_list(g_list)

    exec_users = get_execute_grantees('DBMS_RLS')
    if exec_users is not None:
        details += '\nUsers with EXECUTE on SYS.DBMS_RLS: '
        details += join_list(exec_users)

    remarks = 'Virtual Private Database (VPD) allows for fine-grained ' + \
        'control over which rows and columns of a table are ' + \
        'visible to a SQL statement. Access control using ' + \
        'VPD limits each database session to only the specific ' + \
        'data it should be able to access. ' + \
        'Access by users with the EXEMPT ACCESS POLICY privilege ' + \
        'will not be affected by VPD policies. Users who can ' + \
        'execute the DBMS_RLS package are able to create and modify ' + \
        'these policies.'
    refs = {'GDPR': 'Article 29, 32'}

    sat.finding('Virtual Private Database', 'ACCESS.VPD', summary,
        severity, details, remarks, refs)

# ACCESS.RAS - Real Application Security
def ras_policy():
    data = sat.get_data('ras_policy', 2)
    if data is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped RAS Policies')
        return

    pol_owner = sat.get_index('ras_policy', 'policy_owner')
    pol_name = sat.get_index('ras_policy', 'policy_name')
    obj_owner = sat.get_index('ras_policy', 'schema')
    obj_name = sat.get_index('ras_policy', 'object')
    owner_bypass = sat.get_index('ras_policy', 'owner_bypass')

    pol_list = [x[pol_owner] + '.' + x[pol_name] for x in data]
    if len(pol_list) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + sing_plural(len(set(pol_list)), 
                                         'RAS policy', 'RAS policies') + \
                  ' protecting ' + sing_plural(len(data), 'object.', 'objects.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No RAS policies found.'

    dict = {}

    for x in data:
        key = x[pol_owner] + '.' + x[pol_name]
        str = x[obj_owner] + '.' + x[obj_name]
        if x[owner_bypass]:
            str += ' (owner_bypass: Yes)'
        else:
            str += ' (owner_bypass: No)'
        if key in dict:
            dict.get(key).append(str)
        else:
            dict[key] = [str]

    details = ''
    for k, v in dict.items():
        details += 'Policy %s: Protects %s\n' % (k, join_list(v))

    details += '\n'
    exempt_priv = 'EXEMPT ACCESS POLICY'
    g_list, num_admin = get_sys_priv_grantees(exempt_priv)
    if g_list is not None:
        details += 'Users with %s privilege: %s\n' % \
                   (exempt_priv, join_list(g_list))

    ras_priv_list = ['ADMIN_ANY_SEC_POLICY', 'ADMIN_SEC_POLICY', 
        'APPLY_SEC_POLICY']
    for ras_priv in ras_priv_list:
        g_list = get_ras_priv_grantees(ras_priv)
        if g_list is not None:
            details += 'Users with %s privilege: %s\n' % \
                       (ras_priv, join_list(g_list))

    remarks = 'Like Virtual Private Database, Real Application ' + \
        'Security (RAS) provides fine-grained control over the rows ' + \
        'and columns of a table that are visible to a SQL ' + \
        'statement. Specification of RAS data access policies ' + \
        'uses a declarative syntax based on access control lists. ' + \
        'Access by users with the EXEMPT ACCESS POLICY privilege ' + \
        'will not be affected by RAS access policies. Users with ' + \
        'ADMIN_SEC_POLICY and APPLY_SEC_POLICY privileges are able ' + \
        'to create and modify these policies.'
    refs = {'GDPR': 'Article 6, 25, 32, 34, 89; Recital 28, 29, 64, 78, 156'}

    sat.finding('Real Application Security', 'ACCESS.RAS', summary,
        severity, details, remarks, refs)

# ACCESS.OLS - Label Security
def label_security():
    summary = ''
    details = ''

    if not db_options_dict.get('Oracle Label Security', False):
        severity = sat.SEV_ENHANCEMENT
        summary = 'Label Security is not enabled.'
        details = None
    else:
        severity = sat.SEV_UNKNOWN
        schema_pol_data = sat.get_data('ols_schema_policy', 1)
        table_pol_data = sat.get_data('ols_table_policy', 1)

        if schema_pol_data is None or table_pol_data is None:
            sat.diag('Skipped Label Security Checks')
            return
        else:
            pol_num = 0
            schema_pol_name = sat.get_index('ols_schema_policy', 'policy_name') 
            schema_name = sat.get_index('ols_schema_policy', 'schema_name')
            schema_pol_status = sat.get_index('ols_schema_policy', 'status')

            table_pol_name = sat.get_index('ols_table_policy', 'policy_name') 
            table_schema = sat.get_index('ols_table_policy', 'schema_name')
            table_name = sat.get_index('ols_table_policy', 'table_name')
            table_pol_status = sat.get_index('ols_table_policy', 'status')
    
            policy_dba_list = ['LBAC_DBA']       
            schema_pol_dict = {}
            for x in schema_pol_data: 
                if x[schema_pol_name] not in schema_pol_dict:
                    schema_pol_dict[x[schema_pol_name]] = []
                    pol_num += 1
                    policy_dba_list.append(x[schema_pol_name] + '_DBA')

                if x[schema_pol_status]:
                    schema_str  = x[schema_name] + ' (Enabled)'
                else:
                    schema_str  = x[schema_name] + ' (Disabled)'
                schema_pol_dict[x[schema_pol_name]].append(schema_str)

            for k, v in schema_pol_dict.items():
                details += 'Policy %s: Protects %s\n' % (k, join_list(v))

            table_pol_dict = {}
            for x in table_pol_data:
                if x[table_pol_name] not in schema_pol_dict:
                    pol_num += 1
                    policy_dba_list.append(x[table_pol_name] + '_DBA')
                    if x[table_pol_name] not in table_pol_dict:
                        table_pol_dict[x[table_pol_name]] = []

                    if x[table_pol_status]:
                        table_str  = x[table_schema] + '.' + \
                                     x[table_name] + ' (Enabled)'
                    else:
                        table_str  = x[table_schema] + '.' + \
                                     x[table_name] + ' (Disabled)'
                    table_pol_dict[x[table_pol_name]].append(table_str)

            for k, v in table_pol_dict.items():
                details += 'Policy %s: Protects %s\n' % (k, join_list(v))

            if len(schema_pol_data) == 0 and len(table_pol_data) == 0:
                severity = sat.SEV_ENHANCEMENT
                summary = 'No Label Security policies found.'
            else:
                severity = sat.SEV_UNKNOWN
                summary = 'Found ' + \
                          sing_plural(pol_num, 'Label Security policy', 
                                               'Label Security policies') + \
                          ' protecting ' + \
                          sing_plural(len(schema_pol_data), 
                                      'schema', 'schemas') + \
                          ' and ' + \
                          sing_plural(len(table_pol_data), 'table.', 'tables.')                                                         
            role_grants = sat.get_data('role_grants', 1)
            if role_grants is None or all_roles is None:
                sat.diag('Skipped Label Security roles grant info')
            else:
                r_grantee = sat.get_index('role_grants', 'grantee')
                r_role = sat.get_index('role_grants', 'granted_role')

                details += '\n'
                for p_admin in sorted(policy_dba_list): 
                    owners = get_role_grantees(p_admin, role_grants, 
                                               r_grantee, r_role)
                    details += 'Users with %s role: %s\n' % \
                               (p_admin, join_list(owners))

            exempt_priv = 'EXEMPT ACCESS POLICY'
            g_list, num_admin = get_sys_priv_grantees(exempt_priv)

            if g_list is not None:
                details += 'Users with ' + exempt_priv + ' privilege: '
                details += join_list(g_list)

    remarks = "Oracle Label Security provides the ability to tag data " \
        "with a data label or a data classification. Access to " \
        "sensitive data is controlled by comparing the data label with " \
        "the requesting user's label or security clearance. A user " \
        "label or security clearance can be thought of as an extension to " \
        "standard database privileges and roles. " + \
        "Access by users with the EXEMPT ACCESS POLICY privilege " + \
        "will not be affected by the Label Security policies. " + \
        "Each policy has a corresponding role; users who have this role " + \
        "are able to administer the policy."
    refs = {'GDPR': 'Article 18, 29, 32; Recital 67'}

    sat.finding('Label Security', 'ACCESS.OLS', summary,
        severity, details, remarks, refs)

# ACCESS.TSDP - Transparent Sensitive Data Protection
def tsdp_policy():
    data_type_col = sat.get_data('tsdp_sensitive_type_col', 1)
    data_policy = sat.get_data('tsdp_policy', 1)

    if data_type_col is None or data_policy is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped TSDP Policies')
        return

    severity = sat.SEV_UNKNOWN
    summary = ''
    details = ''

    # if there is no sensitive types/columns OR no policy, then there is
    # opportunity for improvement.
    if len(data_type_col) == 0 or len(data_policy) == 0:
        severity = sat.SEV_ENHANCEMENT

    if data_type_col is not None:
        type = sat.get_index('tsdp_sensitive_type_col', 'sensitive_type')
        owner = sat.get_index('tsdp_sensitive_type_col', 'schema_name')
        tab = sat.get_index('tsdp_sensitive_type_col', 'table_name')
        col = sat.get_index('tsdp_sensitive_type_col', 'column_name')
        
        if len(data_type_col) > 0:
            type_list = [x[type] for x in data_type_col]
            summary = 'Found ' + \
                      sing_plural(len(set(type_list)), 'sensitive type',
                                                       'sensitive types') + \
                      ' and ' + \
                      sing_plural(len(data_type_col), 'sensitive column.',
                                                      'sensitive columns.')
            tc_list = []
            for t in type_list:
                cols = []
                for x in data_type_col:
                    if x[type] == t:
                        cols.append('Col ' + x[col] + ' of ' + x[owner] + \
                                    '.' + x[tab])
                if len(cols) > 0:
                    tc_list.append(t + ' (' + join_list(cols) + ')')
                else:
                    tc_list.append(t)

            details += 'Sensitive types and columns: ' + join_list(tc_list)
            details += '\n\n'
        else:
            summary = 'No sensitive types and columns found. '

    if data_policy:
        policy = sat.get_index('tsdp_policy', 'policy_name')
        feature = sat.get_index('tsdp_policy', 'security_feature')

        p_list = [x[policy] + ' (' + x[feature] + ')' for x in data_policy \
                  if x[policy] != 'REDACT_AUDIT']
        summary += ' Found ' + sing_plural(len(p_list), 'TSDP policiy.', 
                                                        'TSDP policies.')
        details += 'Policies: ' + join_list(p_list)
    else:
        summary = ' No TSDP policies found.'

    exec_users = get_execute_grantees('DBMS_TSDP_MANAGE')
    if exec_users is not None:
        details += '\n\nUsers with EXECUTE on SYS.DBMS_TSDP_MANAGE: '
        details += join_list(exec_users)

    exec_users = get_execute_grantees('DBMS_TSDP_PROTECT')
    if exec_users is not None:
        details += '\nUsers with EXECUTE on SYS.DBMS_TSDP_PROTECT: '
        details += join_list(exec_users)

    remarks = 'Transparent Sensitive Data Protection (TSDP), introduced in ' + \
        'Oracle Database 12.1, allows a data type to be ' + \
        'associated with each column that contains sensitive ' + \
        'data. TSDP can then apply various data security ' + \
        'features to all instances of a particular type so that ' + \
        'protection is uniform and consistent. ' + \
        'Data from columns marked as sensitive is also automatically ' + \
        'redacted in the database audit trail and trace logs. ' + \
        'Users who can execute the DBMS_TSDP_MANAGE and DBMS_TSDP_PROTECT ' + \
        'packages are able to manage sensitive data types and the ' + \
        'protection actions that are applied to them.'
    sat.finding('Transparent Sensitive Data Protection',
        'ACCESS.TSDP', summary,
        severity=severity, details=details, remarks=remarks)

# get_ras_priv_grantees
#   priv  - RAS privilege
# Returns
#   u_list - list of users who are granted the RAS privilege directly 
#            or indirectly (through roles). Note that the returned list 
#            contains only database users (i.e., RAS users/roles are not 
#            considered during search).
#
def get_ras_priv_grantees(priv):
    ras_privs = sat.get_data('ras_privs', 1)
    role_grants = sat.get_data('role_grants', 1)

    if ras_privs is None or role_grants is None or all_roles is None:
        sat.diag('Skipped Get RAS Privilege Grantees')
        return None

    ras_grantee = sat.get_index('ras_privs', 'principal')
    ras_priv = sat.get_index('ras_privs', 'privilege')
    r_grantee = sat.get_index('role_grants', 'grantee')
    r_role = sat.get_index('role_grants', 'granted_role')

    # get all the users and roles that are directly granted the privilege.
    users = set()
    for x in ras_privs:
        if x[ras_priv] == priv:
            grantee = x[ras_grantee]
            if grantee in all_roles:
                for u in get_role_grantees(grantee, role_grants, 
                r_grantee, r_role):
                    users = users.union(set([u]))
            else:
                users = users.union(set([grantee]))

    return sorted(list(users))

###
### Auditing
###

# AUDIT.RECORDS - Audit Records
def audit_trail():
    # 1. Check audit trails.
    nonempty = 0
    trails_checked = 0
    details =''
    # unified_audit_trail simply indicates whether unified_audit_trail is
    # empty or not. unified_audit_trail_stats queries audsys.aud$unified,
    # introduced in 12.2, and contains the number of unified audit records
    # and min/max dates of unified audit records.
    audit_trails = (('traditional_audit_trail', 'Traditional Audit Trail'),
                    ('fine_grained_audit_trail', 'FGA Audit Trail'),
                    ('unified_audit_trail_stats', 'Unified Audit Trail'))

    for source, name in audit_trails:
        data = sat.get_data(source, 1)
        # if unified_audit_trail_stats is not available (12.1), try to fall 
        # back to unified_audit_trail
        if data is None and source == 'unified_audit_trail_stats':
            source = 'unified_audit_trail'
            data = sat.get_data(source, 1)

        if data is not None:
            trails_checked += 1
            num_idx = sat.get_index(source, 'num')
            min_idx = sat.get_index(source, 'min_date')
            max_idx = sat.get_index(source, 'max_date')
            num_records = data[0][num_idx];

            if num_records == 0:
                details += name + ': No records found'
            else:
                nonempty += 1
                details += name + ': In use'
                if source != 'unified_audit_trail':
                    details += ', ' + \
                       sing_plural(num_records, 'record', 'records') + ' found'
                   
            if num_records > 0 and min_idx is not None and max_idx is not None:
                min_date = format_date(read_date(data[0][min_idx]), '%b %d %Y')
                max_date = format_date(read_date(data[0][max_idx]), '%b %d %Y')
                details += ' (' + min_date + ' - ' + max_date + ')'

            details += '\n'

    # 2. Check audit related parameters.
    num_issues = 0
    param_details = ''
    param_checked = 0

    val = sys_param_dict.get('AUDIT_FILE_DEST')
    if val is not None:
        param_details = 'AUDIT_FILE_DEST=' + display_string(val) + '\n'

    val = sys_param_dict.get('AUDIT_SYSLOG_LEVEL')
    if val:
        param_details += 'AUDIT_SYSLOG_LEVEL=' + display_string(val) + '\n'
    else:
        param_details += 'AUDIT_SYSLOG_LEVEL is not set.\n'

    param_checked, num_issues, param_details = \
       param_should_not('AUDIT_TRAIL', 'NONE',
                        'OS, DB, DB,EXTENDED, XML, or XML,EXTENDED',
                        param_checked, num_issues, param_details)

    details += '\n' + param_details

    summary = 'Examined ' + \
              sing_plural(trails_checked, 'audit trail. ', 'audit trails. ')

    severity = sat.SEV_UNKNOWN
    if trails_checked > 0:
        if nonempty == 0:
            severity = sat.SEV_HIGH
            summary += 'Found no audit records. '
        else:
            summary += 'Found records in ' + \
                   sing_plural(nonempty, 'audit trail. ', 'audit trails. ')

    if param_checked:
        if num_issues > 0:
            summary += 'Found ' + sing_plural(num_issues, 'error', 'errors') + \
                       ' in audit initialization parameters.'
            if severity == sat.SEV_UNKNOWN:
                severity = sat.SEV_MEDIUM
        else:
            summary += 'No errors found in audit initialization parameters.'
        
    remarks = 'Auditing is an essential component for securing any ' + \
        'system. The audit trail allows for monitoring the ' + \
        'activities of highly privileged users. For any attack that ' + \
        'exploits gaps in other security policies, auditing cannot ' + \
        'prevent the attack but it forms the critical last line of defense ' + \
        'by detecting the malicious activity. ' + \
        'Sending audit data to a remote system is recommended in order ' + \
        'to prevent any possible tampering with the audit records. ' + \
        'The AUDIT_SYSLOG_LEVEL parameter can be set to send an ' + \
        'abbreviated version of some audit records to a remote syslog ' + \
        'collector. A better solution is to use Oracle Audit Vault and ' + \
        'Database Firewall to centrally collect full audit records from ' + \
        'multiple databases.'
    refs = {'CIS': 'Recommendation 2.2.2', 'GDPR': 'Article 30, 33, 34'}

    sat.finding('Audit Records', 'AUDIT.RECORDS', summary,
        severity, details, remarks, refs)

# AUDIT.STMT - Statement Audit
def statement_audit():
    tdata = sat.get_data('statement_audit', 1)
    udata = sat.get_data('unified_audit_details', 1)

    if tdata is None and udata is None:
        sat.diag('Skipped Statement Audit')
        return

    t_list = []
    if tdata is not None:
        opt = sat.get_index('statement_audit', 'audit_option')
        t_list = [t[opt] for t in tdata]
        t_list = list(set(t_list))

    u_list = []
    if udata is not None:
        ty = sat.get_index('unified_audit_details', 'audit_option_type')
        opt = sat.get_index('unified_audit_details', 'audit_option')
        u_list = [u[opt] for u in udata if u[ty] == 'STANDARD ACTION']
        u_list = list(set(u_list))

    details = ''

    if len(t_list) > 0:
        details += 'Traditional Audit (%d): ' % len(t_list)
        details += join_list(sorted(t_list)) + '\n'

    if len(u_list) > 0:
        if len(t_list) > 0:
            details += '\n'
        details += 'Unified Audit (%d): ' % len(u_list)
        details += join_list(sorted(u_list))

    total = len(t_list) + len(u_list)

    if total > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Auditing enabled for ' + \
                  sing_plural(total, 'statement.', 'statements.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No auditing enabled for statements.'
        details = None

    remarks = 'This finding shows the SQL statements that are audited ' + \
        'by enabled audit policies.'

    sat.finding('Statement Audit', 'AUDIT.STMT', summary,
        severity=severity, details=details, remarks=remarks)

# AUDIT.OBJ - Object Audit
def object_audit():
    tdata = sat.get_data('object_audit', 1)
    udata = sat.get_data('unified_audit_details', 1)

    if tdata is None and udata is None:
        sat.diag('Skipped Object Audit')
        return

    t_dict = {}
    if tdata is not None:
        owner = sat.get_index('object_audit', 'owner')
        name = sat.get_index('object_audit', 'object_name')

        for x in tdata:
            if x[owner] in t_dict.keys():
                if x[name] not in t_dict[x[owner]]:
                    t_dict[x[owner]].append(x[name])
            else:
                t_dict[x[owner]] = []
                t_dict[x[owner]].append(x[name])

    u_dict = {}
    if udata is not None:
        ty = sat.get_index('unified_audit_details', 'audit_option_type')
        owner = sat.get_index('unified_audit_details', 'object_schema')
        name = sat.get_index('unified_audit_details', 'object_name')

        for x in udata:
            if x[ty] != 'OBJECT ACTION':
                continue
            if x[owner] in u_dict.keys():
                if x[name] not in u_dict[x[owner]]:
                    u_dict[x[owner]].append(x[name])
                else:
                    u_dict[x[owner]] = []
                    u_dict[x[owner]].append(x[name])

    details = ''
    total = 0

    if len(t_dict) > 0:
        details += 'Traditional Audit:\n'
        for x in sorted(t_dict.keys()):
            objs = t_dict[x]
            num = len(objs)
            total += num
            details += 'Schema %s (%d): %s\n' % (x, num, join_list(objs))

    if len(u_dict) > 0:
        if len(t_dict) > 0:
            details += '\n'
        details += 'Unified Audit:\n'
        for x in sorted(u_dict.keys()):
            objs = u_dict[x]
            num = len(objs)
            total += num
            details += 'Schema %s (%d): %s\n' % (x, num, join_list(objs))

    if total > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Auditing enabled for ' + \
                  sing_plural(total, 'object.', 'objects.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No auditing enabled for objects.'
        details = None

    remarks = 'This finding shows the object accesses that are audited ' + \
        'by enabled audit policies.'

    sat.finding('Object Audit', 'AUDIT.OBJ', summary,
        severity=severity, details=details, remarks=remarks)

# AUDIT.PRIV - Privilege Audit
def privilege_audit():
    tdata = sat.get_data('privilege_audit', 1)
    udata = sat.get_data('unified_audit_details', 1)

    if tdata is None and udata is None:
        sat.diag('Skipped Privilege Audit')
        return

    t_list = []
    if tdata is not None:
        priv = sat.get_index('privilege_audit', 'privilege')
        t_list = [t[priv] for t in tdata]
        t_list = sorted(list(set(t_list)))

    u_list = []
    if udata is not None:
        ty = sat.get_index('unified_audit_details', 'audit_option_type')
        opt = sat.get_index('unified_audit_details', 'audit_option')
        u_list = [u[opt] for u in udata if u[ty] == 'SYSTEM PRIVILEGE']
        u_list = sorted(list(set(u_list)))

    details = ''

    if len(t_list) > 0:
        details += 'Traditional Audit (%d): ' % len(t_list)
        details += join_list(t_list) + '\n'

    if len(u_list) > 0:
        if len(t_list) > 0:
            details += '\n'
        details += 'Unified Audit (%d): ' % len(u_list)
        details += join_list(u_list)

    total = len(t_list) + len(u_list)
    if total > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Auditing enabled for ' + \
                  sing_plural(total, 'privilege.', 'privileges.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No auditing enabled for privileges.'
        details = None

    remarks = 'This finding shows the privileges that are audited ' + \
        'by enabled audit policies.'
    refs = {'CIS': 'Recommendation 5.1.15, 5.1.16, 5.1.17'}

    sat.finding('Privilege Audit', 'AUDIT.PRIV', summary,
        severity, details, remarks, refs)

# AUDIT.ADMIN - Administrative User Audit
def check_admin_audit():
    udata = sat.get_data('unified_audit_details', 2)
    if not sys_param_dict and udata is None:
        sat.diag('Skipped Administrative User Audit')
        return

    details = ''

    # check AUDIT_SYS_OPERATIONS parameter setting.
    t_sys_audit = None
    if sys_param_dict:
        val = sys_param_dict.get('AUDIT_SYS_OPERATIONS').upper()
        details = \
            'Traditional Audit: AUDIT_SYS_OPERATIONS is set to %s.\n\n' % val

        t_sys_audit = (val == 'TRUE')

    # check Unified Audit setting if available.
    u_sys_audit = False
    if udata is not None:
        uname = sat.get_index('unified_audit_details', 'user_name')
        pname = sat.get_index('unified_audit_details', 'policy_name')
        dict = {}

        # collect audit policies enabled for administrative users, and
        # check whether there is a policy enabled for SYS.
        for x in udata:
            if x[uname] in oracle_admin_users:
                if x[uname] == 'SYS':
                    u_sys_audit = True
                if x[uname] in dict:
                    dict.get(x[uname]).append(x[pname])
                else:
                    dict[x[uname]] = [x[pname]]

        details += 'Unified Audit policies enabled for administrators: '
        pol_list = []
        for  k, v in dict.items():
            pol_list.append(k + ' (' + join_list(sorted(list(set(v)))) + ')')
        details += join_list(pol_list)

    # If any of the followings is true, then SYS user is audited.
    # 1. Unified Audit is available, and there is audit policy enabled
    #    for SYS user.
    # 2. AUDIT_SYS_OPERATIONS is set to TRUE.
    if u_sys_audit or t_sys_audit:
        summary = 'Actions of the SYS user are audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Actions of the SYS user are not audited.'
        severity = sat.SEV_MEDIUM

    remarks = 'It is important to audit administrative actions performed ' + \
        'by the SYS user. Traditional audit policies do not apply to ' + \
        'SYS, so the AUDIT_SYS_OPERATIONS parameter must be set to ' + \
        'record SYS actions to a separate audit trail. Beginning with ' + \
        'Oracle 12c, the same Unified Audit policies can be applied to ' + \
        'SYS that are used to monitor other users.'
    refs = {'CIS': 'Recommendation 2.2.1'}

    sat.finding('Administrative User Audit', 'AUDIT.ADMIN', summary,
        severity, details, remarks, refs)

# AUDIT.PRIVMGMT - Privilege Management Audit
def check_audited_grant_stmt():
    role_privs = set(['CREATE ROLE', 'ALTER ROLE', 'DROP ROLE'])
    sys_grant_privs = set(['GRANT ANY ROLE', 'GRANT ANY PRIVILEGE'])
    grant_privs = sys_grant_privs.union(set(['GRANT ANY OBJECT PRIVILEGE']))
    privmgmt_privs = role_privs.union(grant_privs)

    t_audits = check_traditional_audit(privmgmt_privs)
    u_audits = check_unified_audit(privmgmt_privs)

    if t_audits is None and u_audits is None:
        sat.diag('Skipped Privilege Management Audit Check')
        return

    uncovered = grant_privs.difference(set_union([t_audits, u_audits]))

    # check for shortcuts
    # 1. ROLE in traditional audit covers all the role operations.
    uncovered, t_audits = check_audit_shortcut(False, 'ROLE',
                                           role_privs, uncovered, t_audits)

    # 2. SYSTEM GRANT in traditional audit covers system privilege/role grants.
    uncovered, t_audits = check_audit_shortcut(False, 'SYSTEM GRANT',
                                           sys_grant_privs, uncovered, t_audits)

    # 3. GRANT/REVOKE in unified audit covers all the privilege/role grants.
    grant_revoke = set(['GRANT', 'REVOKE'])
    uset = check_unified_audit(grant_revoke)
    if uset is not None:
        u_audits = u_audits.union(uset)
        # if both GRANT and REVOKE are audited, all grants are covered.
        if grant_revoke.issubset(uset):
            uncovered = uncovered.difference(grant_privs)

    # if either traditional audit or unified audit covers all the
    # required statements or actions, consider sufficient.
    if len(uncovered) == 0:
        summary = 'Actions related to privilege management are ' \
                    'sufficiently audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Actions related to privilege management are ' \
                    'not sufficiently audited.'
        severity = sat.SEV_MEDIUM

    details = get_audit_details(t_audits, u_audits, uncovered)

    remarks = 'Granting additional privileges to users or roles ' + \
        'potentially affects most security protections and ' + \
        'should be audited. ' + \
        'Each action or privilege listed here should be included in ' + \
        'at least one enabled audit policy.'
    refs = {'CIS': 'Recommendation 5.1.4, 5.1.5, 5.1.15, 5.1.16, 5.2.4 - 5.2.8'}

    sat.finding('Privilege Management Audit', 'AUDIT.PRIVMGMT', summary,
        severity, details, remarks, refs)

# AUDIT.ACCTMGMT - Account Management Audit
def check_audited_account_stmt():
    user_stmts = set(['CREATE USER', 'ALTER USER', 'DROP USER'])
    prof_stmts = set(['CREATE PROFILE', 'ALTER PROFILE', 'DROP PROFILE'])
    acct_stmts = user_stmts.union(prof_stmts)

    # check for every target audit statement
    t_audits = check_traditional_audit(acct_stmts)
    u_audits = check_unified_audit(acct_stmts)

    if t_audits is None and u_audits is None:
        sat.diag('Skipped Account Management Audit Check')
        return

    uncovered = acct_stmts.difference(set_union([t_audits, u_audits]))

    # check for shortcuts
    # 1. USER in traditional audit covers CREATE/ALTER/DROP USER.
    uncovered, t_audits = check_audit_shortcut(False, 'USER', user_stmts, \
                                               uncovered, t_audits)

    # 2. PROFILE in traditional audit covers CREATE/ALTER/DROP PROFILE.
    uncovered, t_audits = check_audit_shortcut(False, 'PROFILE', prof_stmts, \
                                               uncovered, t_audits)

    # if all the statements are covered by either traditional or unified
    # audit, consider sufficient.
    if len(uncovered) == 0:
        summary = 'Actions related to account management are ' \
                    'sufficiently audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Actions related to account management are ' \
                    'not sufficiently audited.'
        severity = sat.SEV_MEDIUM

    details = get_audit_details(t_audits, u_audits, uncovered)

    remarks = 'Creation of new user accounts or modification of ' + \
        'existing accounts can be used to gain access to the ' + \
        'privileges of those accounts and should be audited. ' + \
        'Each action or privilege listed here should be included in ' + \
        'at least one enabled audit policy.'
    refs = {'CIS': 
        'Recommendation 5.1.1, 5.1.2, 5.1.3, 5.1.6, 5.1.7, 5.1.8, ' +
        '5.2.1, 5.2.2, 5.2.3, 5.2.9, 5.2.10, 5.2.11'}

    sat.finding('Account Management Audit', 'AUDIT.ACCTMGMT', summary,
        severity, details, remarks, refs)

# AUDIT.DBMGMT - Database Management Audit
def check_audited_system_stmt():
    sys_stmts  = set(['ALTER SYSTEM', 'ALTER DATABASE',
                      'CREATE LIBRARY', 'CREATE ANY LIBRARY',
                      'SYSTEM AUDIT', 'CREATE EXTERNAL JOB', 'AUDIT ANY'])
    proc_stmts = set(['ALTER PROCEDURE', 'CREATE PROCEDURE', 'DROP PROCEDURE', 
                      'DROP ANY PROCEDURE'])
    dir_stmts  = set(['CREATE ANY DIRECTORY', 'DROP ANY DIRECTORY'])
    psyn_stmts = set(['CREATE PUBLIC SYNONYM', 'DROP PUBLIC SYNONYM'])
    dbl_stmts  = set(['CREATE DATABASE LINK', 'ALTER DATABASE LINK',
                      'DROP DATABASE LINK'])
    pdbl_stmts = set(['CREATE PUBLIC DATABASE LINK',
                     'ALTER PUBLIC DATABASE LINK', 'DROP PUBLIC DATABASE LINK'])
    trig_stmts  = set(['CREATE TRIGGER', 'ALTER TRIGGER', 'DROP TRIGGER'])
    plug_stmts = set(['CREATE PLUGGABLE DATABASE', 'ALTER PLUGGABLE DATABASE',
                     'DROP PLUGGABLE DATABASE'])
    stmts_12   = set(['ADMINISTER KEY MANAGEMENT', 'CREATE SPFILE'])
    obj_aud    = set(['EXECUTE ON SYS.DBMS_RLS'])
    
    all_stmts = set_union([sys_stmts, proc_stmts, dir_stmts, psyn_stmts, 
        dbl_stmts, pdbl_stmts, trig_stmts])
    if target_db_version >= '12':
        all_stmts = set_union([all_stmts, plug_stmts, stmts_12])

    # check privilege/statement audit.
    t_audits = check_traditional_audit(all_stmts)
    u_audits = check_unified_audit(all_stmts)

    if t_audits is None and u_audits is None:
        sat.diag('Skipped Database Management Audit Check')

    uncovered = all_stmts.difference(set_union([t_audits, u_audits]))

    # check object audit.
    tset = check_traditional_audit(obj_aud, True)
    if tset is not None:
        t_audits = t_audits.union(tset)
    uset = check_unified_audit(obj_aud, True)
    if uset is not None:
        u_audits = u_audits.union(uset)

    uncovered_obj = obj_aud.difference(set_union([tset, uset]))
    uncovered = uncovered.union(uncovered_obj)

    # check shortcuts
    # 1. DIRECTORY in traditional audit covers CREATE/DROP ANY DIRECTORY.
    uncovered, t_audits = check_audit_shortcut(False, 'DIRECTORY', dir_stmts,
                                               uncovered, t_audits)

    # 2. PUBLIC SYNONYM in traditional audit covers CREATE/DROP PUBLIC SYNONYM.
    uncovered, t_audits = check_audit_shortcut(False, 'PUBLIC SYNONYM',
                                               psyn_stmts, uncovered, t_audits)

    # 3. DATABASE LINK in traditional audit covers CREATE/ALTER/DROP 
    #    DATABASE LINK.
    uncovered, t_audits = check_audit_shortcut(False, 'DATABASE LINK',
                                               dbl_stmts, uncovered, t_audits)

    # 4. PUBLIC DATABASE LINK in traditional audit covers CREATE/ALTER/DROP 
    #    PUBLIC DATABASE LINK.
    uncovered, t_audits = check_audit_shortcut(False, 'PUBLIC DATABASE LINK',
                                               pdbl_stmts, uncovered, t_audits)

    # 5. PLUGGABLE DATABASE in traditional audit covers CREATE/ALTER/DROP
    #    PLUGGABLE DATABASE.
    uncovered, t_audits = check_audit_shortcut(False, 'PLUGGABLE DATABASE',
                                               plug_stmts, uncovered, t_audits)

    # 6. TRIGGER in traditional audit covers CREATE/ALTER/DROP TRIGGER.
    uncovered, t_audits = check_audit_shortcut(False, 'TRIGGER',
                                               trig_stmts, uncovered, t_audits)

    # 7. PROCEDURE in tradtional audit covers CREATE/DROP PROCEDURE.
    uncovered, t_audits = check_audit_shortcut(False, 'PROCEDURE', 
                                               proc_stmts, uncovered, t_audits)

    # if everything is covered by either traditional or unified audit,
    # consider sufficient.
    if len(uncovered) == 0:
        summary = 'Actions related to database management are ' \
                  'sufficiently audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Actions related to database management are not ' \
                  'sufficiently audited.'
        severity = sat.SEV_MEDIUM

    details = get_audit_details(t_audits, u_audits, uncovered)

    remarks = 'Actions that affect the management of ' + \
        'database features should always be audited. ' + \
        'Each action or privilege listed here should be included in ' + \
        'at least one enabled audit policy.'
    refs = {'CIS': 'Recommendation 5.1.9, 5.1.10, 5.1.11, 5.1.17, ' +
        '5.1.19 - 5.1.21, 5.2.12 - 5.2.14, 5.2.20 - 5.2.26'}

    sat.finding('Database Management Audit', 'AUDIT.DBMGMT',
        summary, severity, details, remarks, refs)

# AUDIT.PRIVUSE - Privilege Usage Audit
def check_audited_privs_usage():
    privs    = set(['EXEMPT ACCESS POLICY', 'CREATE ANY TRIGGER',
                   'SELECT ANY DICTIONARY',
                   'CREATE ANY JOB', 'CREATE ANY PROCEDURE', 'BECOME USER'])
    priv_112 = set(['EXEMPT REDACTION POLICY'])
    privs_12 = set(['LOGMINING', 'CREATE ANY SQL TRANSLATION PROFILE',
                    'ALTER ANY SQL TRANSLATION PROFILE', 'TRANSLATE ANY SQL'])

    if target_db_version >= '11.2':
        privs = privs.union(priv_112)

    if target_db_version >= '12':
        privs = privs.union(privs_12)

    # check privilege audit.
    t_audits = check_traditional_audit(privs)
    u_audits = check_unified_audit(privs)

    if t_audits is None and u_audits is None:
        sat.diag('Skipped Privilege Usage Audit Check')

    uncovered = privs.difference(set_union([t_audits, u_audits]))

    # if everything is covered by either traditional or unified audit,
    # consider sufficient.
    if len(uncovered) == 0:
        summary = 'Usages of powerful system privileges are ' \
                  'sufficiently audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Usages of powerful system privileges are not ' \
                  'sufficiently audited.'
        severity = sat.SEV_MEDIUM

    details = get_audit_details(t_audits, u_audits, uncovered)

    remarks = 'Usage of powerful system privileges should always ' + \
        'be audited. Each privilege listed here should be included in ' + \
        'at least one enabled audit policy.'
    refs = {'CIS': 'Recommendation 5.1.14, 5.2.18'}

    sat.finding('Privilege Usage Audit', 'AUDIT.PRIVUSE',
        summary, severity, details, remarks, refs)

# AUDIT.CONN - Database Connection Audit
def check_audited_connect_stmt():
    sess_priv = set(['LOGON', 'LOGOFF'])

    t_audits = check_traditional_audit(sess_priv)
    u_audits = check_unified_audit(sess_priv)

    if t_audits is None and u_audits is None:
        sat.diag('Skipped Database Connection Audit Check')
        return

    uncovered = sess_priv.difference(set_union([t_audits, u_audits]))

    # check for shortcuts
    # 1. CREATE SESSION in traditional audit also audits database connections.
    uncovered, t_audits = check_audit_shortcut(False, 'CREATE SESSION',
        sess_priv, uncovered, t_audits)

    # if either traditional audit or unified audit covers database connections,
    # consider sufficient.
    if len(uncovered) == 0:
        summary = 'Database connections are sufficiently audited.'
        severity = sat.SEV_OK
    else:
        summary = 'Database connections are not sufficiently audited.'
        severity = sat.SEV_MEDIUM

    details = get_audit_details(t_audits, u_audits, uncovered)

    remarks = "Successful user connections to the database should be " \
        "audited to assist with future forensic analysis. " \
        "Unsuccessful connection attempts can provide early " \
        "warning of an attacker's attempt to gain access to the " \
        "database."
    refs = {'CIS': 'Recommendation 5.1.22, 5.2.27'}

    sat.finding('Database Connection Audit', 'AUDIT.CONN',
        summary, severity, details, remarks, refs)

# AUDIT.FGA - Fine Grained Audit
def fine_grained_audit():
    data = sat.get_data('fine_grained_audit', 1)
    if data is None:
        sat.diag('Skipped Fine-Grained Audit')
        return

    policy = sat.get_index('fine_grained_audit', 'policy_name')
    obj_owner = sat.get_index('fine_grained_audit', 'object_schema')
    obj_name = sat.get_index('fine_grained_audit', 'object_name')
    col_name = sat.get_index('fine_grained_audit', 'policy_column')
    pol_state = sat.get_index('fine_grained_audit', 'enabled');
    details = ''

    pol_list = [x[policy] for x in data]
    if len(pol_list) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + \
                  sing_plural(len(set(pol_list)), 'fine grained audit policy',
                                                  'fine grained audit policies')
        summary += ' for ' + sing_plural(len(data), 'object.', 'objects.')
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No fine grained audit policies found.'

    dict = {}
    for x in data:
        if x[policy] in dict:
            dict[x[policy]] = dict.get(x[policy]) + ', ' + x[obj_owner] + \
                              '.' + x[obj_name] + ' (col ' + x[col_name] + ')'
        else:
            if x[pol_state]:
                str = '(Enabled): '
            else:
                str = '(Disabled): '
            str += 'Audits ' + x[obj_owner] + '.' + x[obj_name]
            str += ' (col ' + x[col_name] + ')'
            dict[x[policy]] = str 

    details = ''
    for k, v in dict.items():
        details += 'Policy %s %s\n' % (k, v)

    exec_users = get_execute_grantees('DBMS_FGA')
    if exec_users is not None:
        details += '\nUsers with EXECUTE on SYS.DBMS_FGA: '
        details += join_list(exec_users)

    remarks = 'Fine Grained Audit policies can record highly specific ' + \
        'activity, such as access to particular table columns or ' + \
        'access that occurs under specified conditions. This is ' + \
        'a useful way to monitor unexpected data access while ' + \
        'avoiding unnecessary audit records that correspond to ' + \
        'normal activity.'

    sat.finding('Fine Grained Audit', 'AUDIT.FGA', summary,
        severity=severity, details=details, remarks=remarks)

# AUDIT.UNIFIED - Unified Audit
def unified_audit_policy():
    data = sat.get_data('unified_audit_policy', 1)
    if data is None:
        if target_db_version >= '12.1':
            sat.diag('Skipped Unified Audit Policies')
        return

    policy = sat.get_index('unified_audit_policy', 'policy_name')
    state = sat.get_index('unified_audit_policy', 'state')
    num = sat.get_index('unified_audit_policy', 'num')

    if len(data) > 0:
        summary = 'Found ' + sing_plural(len(data), 'unified audit policy. ',
                                                    'unified audit policies. ')
        details = ''
        num_audits = 0
        for x in data:
            details += 'Policy ' + x[policy] + ' (' + x[state] + '): '
            details += 'Audits %d objects/statements' % x[num] + '\n'
            if x[state] == 'Enabled':
                num_audits += x[num]

        if num_audits > 0:
            severity = sat.SEV_UNKNOWN
            summary += 'Found ' + \
                       sing_plural(num_audits, 'object or statement',
                                               'objects or statements') + \
                       ' being audited.'
        else:
            severity = sat.SEV_ENHANCEMENT
            summary += 'No unified audit policies are enabled.'
    else:
        severity = sat.SEV_ENHANCEMENT
        summary = 'No unified audit policies found.'
        details = None

    remarks = 'Unified Audit, available in Oracle Database 12.1 and ' + \
        'later releases, combines multiple audit trails into a ' + \
        'single unified view. It also introduces new syntax for ' + \
        'specifying effective audit policies.'

    sat.finding('Unified Audit', 'AUDIT.UNIFIED', summary,
            severity=severity, details=details, remarks=remarks)

# check_traditional_audit
#   aset         - traditional audit options to check
#   is_obj_audit - whether the target audit option is object audit
# Returns
#   result   - enabled traditional audit options among aset
# Notes
#   returns None if and only if data is not available or aset is None.
#   An empty set is returned if there are no enabled traditional audit options.
#
def check_traditional_audit(aset, is_obj_audit=False):
    if is_obj_audit:
        data = sat.get_data('object_audit', 1)
    else:
        # Unless the target audit option is object audit, it is sufficient 
        # to check statement_audit only as statement_audit always includes 
        # privilege_audit as well.
        data = sat.get_data('statement_audit', 1)

    if data is None or aset is None:
        return None

    if is_obj_audit:
        owner = sat.get_index('object_audit', 'owner')
        obj_name = sat.get_index('object_audit', 'object_name')
        sel = sat.get_index('object_audit', 'sel')
        upd = sat.get_index('object_audit', 'upd')
        ins = sat.get_index('object_audit', 'ins')
        dele = sat.get_index('object_audit', 'del')
        exe = sat.get_index('object_audit', 'exe')
        alt = sat.get_index('object_audit', 'alt')
        obj_aud_list = []
        not_audit = '-/-'
        for x in data:
            if x[sel] != not_audit:
                obj_aud_list.append('SELECT ON ' +
                                     x[owner] + '.' + x[obj_name])
            if x[upd] != not_audit:
                obj_aud_list.append('UDPATE ON ' +
                                     x[owner] + '.' + x[obj_name])
            if x[ins] != not_audit:
                obj_aud_list.append('INSERT ON ' +
                                     x[owner] + '.' + x[obj_name])
            if x[dele] != not_audit:
                obj_aud_list.append('DELETE ON ' +
                                     x[owner] + '.' + x[obj_name])
            if x[exe] != not_audit:
                obj_aud_list.append('EXECUTE ON ' +
                                     x[owner] + '.' + x[obj_name])
            if x[alt] != not_audit:
                obj_aud_list.append('ALTER ON ' +
                                     x[owner] + '.' + x[obj_name])
        result = set(obj_aud_list).intersection(aset)
    else:
        option = sat.get_index('statement_audit', 'audit_option')
        result = set([x[option] for x in data if x[option] in aset])

    return result

# check_unified_audit
#   aset         - unified audit options to check
#   is_obj_audit - whether the target audit option is object audit
# Returns
#   result   - enabled unified audit options among aset
# Notes
#   returns None if and only if data is not available or aset is None.
#   An empty set is returned if there is no enabled unified audit options.
#
def check_unified_audit(aset, is_obj_audit=False):
    data = sat.get_data('unified_audit_details', 1)
    if data is None or aset is None:
        return None

    op = sat.get_index('unified_audit_details', 'audit_option')
    if is_obj_audit:
        obj_name = sat.get_index('unified_audit_details', 'object_name')
        obj_schema = sat.get_index('unified_audit_details', 'object_schema') 
        audit_list = [x[op] + ' ON ' + x[obj_schema] + '.' + x[obj_name] 
                        for x in data]
    else:
        audit_list = [x[op] for x in data]
        if 'ALL' in audit_list:
            # ALL covers all actions
            return aset

    return set(audit_list).intersection(aset)

# get_audit_details
#   tset      - enabled traditional audit options
#   uset      - enabled unified audit options
#   uncovered - actions that are not being audited
# Returns
#   text summary of audit settings
#
def get_audit_details(tset, uset, uncovered):
    details = ''

    if uncovered:
        details += 'Auditing not enabled: ' + join_list(sorted(uncovered))
        details += '\n\n'

    if tset is not None:
        details += 'Traditional audit - auditing enabled: ' 
        details += join_list(sorted(tset)) + '\n'

    if uset is not None:
        details += 'Unified audit - auditing enabled: ' 
        details += join_list(sorted(uset)) + '\n'

    return details

# check_audit_shortcut
#   is_unified - whether audit type is unified audit
#   shortcut   - an audit shortcut to check
#   covering   - audit options that the given shorcut covers
#   uncovered  - audit options that are not covered so far
#   covered    - audit options that are covered so far
# Returns
#   uncovered  - updated uncovered audit options after the shortcut check
#   covered    - updated covered audit options after the shortcut check
#
def check_audit_shortcut(is_unified, shortcut, covering, uncovered, covered):
    if is_unified:
        aset = check_unified_audit(set([shortcut]))
    else:
        aset = check_traditional_audit(set([shortcut]))

    if aset is not None and shortcut in aset:
        uncovered = uncovered.difference(covering)
        covered = covered.union(aset)

    return uncovered, covered

###
### Database Configuration
###

# Initialization Parameters for Security
def security_parameters():
    if not sys_param_dict:
        sat.diag('Skipped Security Parameters')
        return

    sec_params = set(('DBFIPS_140', 'O7_DICTIONARY_ACCESSIBILITY',
           'AUDIT_FILE_DEST', 'AUDIT_SYS_OPERATIONS',
           'AUDIT_SYSLOG_LEVEL', 'AUDIT_TRAIL',
           'CURSOR_BIND_CAPTURE_DESTINATION',
           'ENCRYPT_NEW_TABLESPACES', 'LDAP_DIRECTORY_ACCESS',
           'LDAP_DIRECTORY_SYSAUTH', 'OS_AUTHENT_PREFIX', 'OS_ROLES',
           'PDB_LOCKDOWN', 'PDB_OS_CREDENTIAL',
           'REMOTE_LOGIN_PASSWORDFILE',
           'REMOTE_OS_AUTHENT', 'REMOTE_OS_ROLES',
           'RESOURCE_LIMIT', 'SEC_CASE_SENSITIVE_LOGON',
           'SEC_MAX_FAILED_LOGIN_ATTEMPTS',
           'SEC_PROTOCOL_ERROR_FURTHER_ACTION',
           'SEC_PROTOCOL_ERROR_TRACE_ACTION',
           'SEC_RETURN_SERVER_RELEASE_BANNER', 'SQL92_SECURITY',
           'UNIFIED_AUDIT_SGA_QUEUE_SIZE', 'COMPATIBLE',
           'DISPATCHERS', 'GLOBAL_NAMES',
           'REMOTE_LISTENER', 'UTL_FILE_DIR', '_TRACE_FILES_PUBLIC'))

    rows = [[k, v] for k, v in sys_param_dict.items() if k in sec_params]

    sat.table('Initialization Parameters for Security',
                  [['Name', 'Value']] + sorted(rows), header=True)

def sec_parameter_checks():
    if not sys_param_dict:
        sat.diag('Skipped Security Parameter Checks')
        return

    access_parameter_checks()
    connection_parameter_checks()
    os_parameter_checks()
    utl_dir_parameter_check()

# CONF.SYSOBJ - Access to Dictionary Objects
# CONF.INFER - Inference of Table Data
def access_parameter_checks():
    checked, num_issues, details = \
       param_should('O7_DICTIONARY_ACCESSIBILITY', 'FALSE')
    if num_issues > 0:
        summary = 'Dictionary objects can be accessed with ' + \
            'regular table system privileges.'
        severity = sat.SEV_HIGH
    else:
        summary = 'Access to dictionary objects is properly limited.'
        severity = sat.SEV_OK
    remarks = 'When O7_DICTIONARY_ACCESSIBILITY is set to FALSE, ' + \
        'tables owned by SYS '+ \
        'are not affected by the ANY TABLE system privileges. ' + \
        'This parameter should always be set to FALSE because ' + \
        'tables owned by SYS control the overall state of the ' + \
        'database and should not be subject to manipulation by ' + \
        'users with ANY TABLE privileges.'
    refs = {'CIS': 'Recommendation 2.2.5'}
    sat.finding('Access to Dictionary Objects', 'CONF.SYSOBJ', summary,
        severity, details, remarks, refs)

    checked, num_issues, details = param_should('SQL92_SECURITY', 'TRUE')
    if num_issues > 0:
        summary = 'UPDATE and DELETE statements can be used to ' + \
            'infer data values.'
        severity = sat.SEV_MEDIUM
    else:
        summary = 'Data inference attacks are properly blocked.'
        severity = sat.SEV_OK
    remarks = 'When SQL92_SECURITY is set to TRUE, UPDATE and ' + \
        'DELETE statements that refer to a column in their WHERE ' + \
        'clauses will succeed only when the user has the ' + \
        'privilege to SELECT from the same column. This ' + \
        'parameter should be set to TRUE so that this ' + \
        'requirement is enforced in order to prevent users from ' + \
        'inferring the value of a column which they do not have ' + \
        'the privilege to view.\n'
    refs = {'CIS': 'Recommendation 2.2.17'}
    sat.finding('Inference of Table Data', 'CONF.INFER', summary,
        severity, details, remarks, refs)

# CONF.NETCOM - Network Communications
def connection_parameter_checks():
    checked, num_issues, details = param_should('REMOTE_LISTENER', '')
    checked, num_issues, details = \
        param_should_not('SEC_PROTOCOL_ERROR_FURTHER_ACTION', 'CONTINUE',
             '(DELAY,integer) or (DROP,integer)', checked, num_issues, details)
    checked, num_issues, details = \
        param_should_not('SEC_PROTOCOL_ERROR_TRACE_ACTION', 'NONE',
             'TRACE, LOG, or ALERT', checked, num_issues, details)
    checked, num_issues, details = \
        param_should('SEC_RETURN_SERVER_RELEASE_BANNER', 'FALSE',
             checked, num_issues, details)

    if checked == 0:
        sat.diag('Skipped Network Communication Parameter Check')
        return

    summary = param_check_summary(checked, num_issues)

    if num_issues > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    remarks = "REMOTE_LISTENER allows a network listener running on " \
                  "another system to be used. This parameter should " \
                  "normally be unset to ensure that the local listener " \
                  "is used. " \
                  "The SEC_PROTOCOL_ERROR parameters control the " \
                  "database server's response when it receives " \
                  "malformed network packets from a client. Because " \
                  "these malformed packets may indicate an attempted " \
                  "attack by a malicious client, the parameters should " \
                  "be set to log the incident and terminate the " \
                  "connection. SEC_RETURN_SERVER_RELEASE_BANNER should " \
                  "be set to FALSE to limit the information that is " \
                  "returned to an unauthenticated client, which could be " \
                  "used to help determine the server's vulnerability to " \
                  "a remote attack."
    refs = {'CIS': 'Recommendation 2.2.7, 2.2.14, 2.2.15, 2.2.16'}

    sat.finding('Network Communications', 'CONF.NETCOM', summary,
        severity, details, remarks, refs)

# CONF.EXTAUTH - External Authorization
def os_parameter_checks():
    checked, num_issues, details = param_should('REMOTE_OS_AUTHENT', 'FALSE')
    checked, num_issues, details = \
       param_should('REMOTE_OS_ROLES', 'FALSE', checked, num_issues, details)
    severe_issues = num_issues
    checked, num_issues, details = \
       param_should('OS_ROLES', 'FALSE', checked, num_issues, details)
 
    if checked == 0:
        sat.diag('Skipped External Authorization Parameter Check')
        return

    summary = param_check_summary(checked, num_issues)

    if severe_issues > 0:
        severity = sat.SEV_HIGH
    elif num_issues > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    remarks = "The OS_ROLES parameter " + \
        "determines whether roles granted to users are controlled " + \
        "by GRANT statements in the database or by the database server's " + \
        "operating system. " + \
        "REMOTE_OS_AUTHENT and REMOTE_OS_ROLES allow the client operating " + \
        "system to set the database user and roles. " + \
        "All of these parameters " + \
        "should be set to FALSE so that the authorizations " + \
        "of database users are managed by the database itself."
    refs = {'CIS': 'Recommendation 2.2.6, 2.2.9, 2.2.10'}

    sat.finding('External Authorization', 'CONF.EXTAUTH', summary,
        severity, details, remarks, refs)

# CONF.FILESYS - File System Access
def utl_dir_parameter_check():
    checked = 0
    num_issues = 0
    details = ''

    val = sys_param_dict.get('UTL_FILE_DIR')

    if val is None:
        if target_db_version < '18':
            sat.diag('Skipped File System Access Parameter Check')
        return
    else:
        checked += 1

    if len(val) == 0:
        # add single quotes for better presentation.
        details = 'UTL_FILE_DIR=\'\''
    else:
        num_issues += 1
        details = 'UTL_FILE_DIR=' + val + '. ' + \
                  'Recommended value is \'\'.'

    summary = param_check_summary(checked, num_issues)

    if num_issues > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    remarks = "The UTL_FILE_DIR parameter controls which part "  \
                  "of the server's file system can be accessed by " \
                  "PL/SQL code. Because the directories specified in " \
                  "the UTL_FILE_DIR parameter may be accessed by " \
                  "any database user, it should be set to specify one or " \
                  "more safe directories that do not contain "       \
                  "restricted files such as the configuration or "   \
                  "data files for the database. For maximum security, " \
                  "use directory objects which " \
                  "allow finer grained control of access, rather than " \
                  "relying on this parameter."
    refs = {'CIS': 'Recommendation 2.2.11'}

    sat.finding('File System Access', 'CONF.FILESYS', summary,
        severity, details, remarks, refs)

# CONF.TRACE - Trace Files
def trace_files():
    checked, num_issues, details = param_should('_TRACE_FILES_PUBLIC', 'FALSE')

    summary = param_check_summary(checked, num_issues)

    if num_issues > 0:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_OK

    remarks = "The hidden parameter _TRACE_FILES_PUBLIC " + \
        "determines whether trace files generated by the database " + \
        "should be accessible to all OS users. " + \
        "Since these files may contain sensitive information, " + \
        "access should be limited by setting this parameter to FALSE."
    refs = {'CIS': 'Recommendation 2.2.18'}

    sat.finding('Trace Files', 'CONF.TRACE', summary,
        severity, details, remarks, refs)

# CONF.TRIG - Triggers
def triggers():
    data = sat.get_data('triggers', 1)
    if data is None:
        sat.diag('Skipped Triggers')
        return
    owner = sat.get_index('triggers', 'owner')
    name = sat.get_index('triggers', 'trigger_name')
    status = sat.get_index('triggers', 'status')
    event = sat.get_index('triggers', 'triggering_event')

    # Logon triggers
    trgs = [x[owner]+'.'+x[name]+'(' + x[status] + ')'
            for x in data if x[event].rstrip() == 'LOGON']
    if len(trgs) > 0:
        summary = 'Found ' + sing_plural(len(trgs), 'logon trigger.', 
                                                    'logon triggers.')
        details = 'Logon triggers: ' + join_list(trgs) + '\n'
    else:
        summary = 'No logon triggers found. '
        details = ''

    # Default triggers
    default_triggers = ['LBACSYS.LBAC$AFTER_CREATE', 'LBACSYS.LBAC$AFTER_DROP',
         'LBACSYS.LBAC$BEFORE_ALTER', 'MDSYS.SDO_GEOR_ADDL_TRIGGER',
         'MDSYS.SDO_GEOR_BDDL_TRIGGER', 'MDSYS.SDO_TOPO_DROP_FTBL',
         'MDSYS.SDO_DROP_USER', 'MDSYS.SDO_NETWORK_DROP_USER',
         'MDSYS.SDO_ST_SYN_CREATE',
         'SYS.NO_VM_DROP', 'SYS.NO_VM_DROP_A', 
         'SYS.NO_VM_CREATE', 'SYS.NO_VM_ALTER', 
         'SYS.AURORA$SERVER$STARTUP', 'SYS.AURORA$SERVER$SHUTDOWN',
         'SYS.CDC_ALTER_CTABLE_BEFORE', 'SYS.CDC_CREATE_CTABLE_AFTER',
         'SYS.CDC_CREATE_CTABLE_BEFORE', 'SYS.CDC_DROP_CTABLE_BEFORE',
         'SYS.LOGMNRGGC_TRIGGER', 'SYS.SYSLSBY_EDS_DDL_TRIG', 
         'EXFSYS.EXPFIL_RESTRICT_TYPEEVOLVE', 'EXFSYS.EXPFIL_ALTEREXPTAB_MAINT',
         'EXFSYS.EXPFIL_DROPOBJ_MAINT', 'EXFSYS.EXPFIL_DROPUSR_MAINT',
         'EXFSYS.RLMGR_TRUNCATE_MAINT',
         'WMSYS.NO_VM_DDL', 'WMSYS.NO_VM_DROP_A']

    # Disabled non-default triggers
    trgs = [x[owner]+ '.' + x[name] for x in data if x[status] == 'DISABLED']
    trgs = [x for x in trgs if x not in default_triggers]

    if len(trgs) > 0:
        summary += ' Found ' + sing_plural(len(trgs), 'disabled trigger.', 
                                                      'disabled triggers.')
        severity = sat.SEV_LOW
        details += 'Disabled triggers: ' + join_list(trgs)
    else:
        summary += ' No disabled triggers found.'
        severity = sat.SEV_OK

    if details == '':
        details = None

    remarks = 'A trigger is code that executes whenever a specific ' + \
        'event occurs, such as inserting data in a table or ' + \
        'connecting to the database. Disabled triggers are a ' + \
        'potential cause for concern because whatever protection ' + \
        'or monitoring they may be expected to provide is not ' + \
        'active.'

    sat.finding('Triggers', 'CONF.TRIG', summary, severity=severity,
                details=details, remarks=remarks)

# CONF.CONST - Disabled Constraints
def disabled_constraint():
    data = sat.get_data('disabled_constraint', 1)
    if data is None:
        sat.diag('Skipped Disabled Constraints')
        return
    owner = sat.get_index('disabled_constraint', 'owner')
    tab_name = sat.get_index('disabled_constraint', 'table_name')
    constraint_name = sat.get_index('disabled_constraint',
                                        'constraint_name')

    constraint_list = [x[constraint_name] + ' on ' + x[owner] + \
                       '.' + x[tab_name] for x in data]

    if len(data) > 0:
        severity = sat.SEV_LOW
        summary = 'Found ' + \
                  sing_plural(len(data), 'disabled constraint.',
                                         'disabled constraints.')
        details = 'Disabled constraints: ' + \
                  join_list(constraint_list);
    else:
        severity = sat.SEV_OK
        summary = 'No disabled constraints found.'
        details = None

    remarks = 'Constraints are used to enforce and guarantee specific ' + \
        'relationships between data items stored in the ' + \
        'database. Disabled constraints are a potential cause ' + \
        'for concern because the conditions they ensure are not ' + \
        'enforced.'

    sat.finding('Disabled Constraints', 'CONF.CONST', summary,
        severity=severity, details=details, remarks=remarks)

# CONF.EXTPROC - External Procedures
def external_procedure():
    data = sat.get_data('external_procedure', 1)
    dict = parse_configfile('listener.ora')
    if data is None or dict is None:
        sat.diag('Skipped External Procedures')
        return
    extproc_envs = {}
    owner = sat.get_index('external_procedure', 'owner')
    lib_name = sat.get_index('external_procedure', 'library_name')

    lib_list = [x[owner] + '.' + x[lib_name] for x in data]

    for k, v in dict.items():
        if k.startswith('SID_LIST_'):
            sid_list = v.get('SID_LIST', {})
            sid_desc_list = sid_list.get('SID_DESC', [])
            if type(sid_desc_list) != type([]):
                # convert singleton to one-element list
                sid_desc_list = [sid_desc_list]
            for x in sid_desc_list:
                # each element is a dictionary describing a service
                if x.get('PROGRAM') == 'extproc':
                    name = x.get('SID_NAME', '(no name)')
                    env_val = x.get('ENVS', {})
                    # env_val must be a dictionary. If it is a string, then
                    # try re-parsing it to get a dictionary.
                    if type(env_val) == type(''):
                        envlex = tokenizer(env_val)
                        try:
                            env_val = parse_value(envlex)
                            # if still not a dictionary, then give up.
                            if type(env_val) != type({}):
                                sat.diag('Failed to get the ENVS value')
                                env_val = {}
                        except Exception as e:
                            sat.diag('Failed to parse ENVS: ' + str(e))
                            env_val = {}
                    extproc_envs[name] = env_val

    details = ''
    if len(data) > 0:
        severity = sat.SEV_UNKNOWN
        summary = 'Found ' + sing_plural(len(data), 'external procedure.',
                                                    'external procedures.')
        details = 'External procedures: %s \n\n' % join_list(lib_list);
    else:
        severity = sat.SEV_OK
        summary = 'No external procedures found.'

    if len(extproc_envs) > 0:
        severity = sat.SEV_UNKNOWN
        summary += ' Found %s.' % \
                   sing_plural(len(extproc_envs), 
                               'external service', 'external services')
        details += 'Listener services for external procedures: \n'
        for name, env in extproc_envs.items():
            ddls = env.get('EXTPROC_DLLS', '(not set)')
            details += name + ': EXTPROC_DLLS=' + ddls + '\n'
            if ddls == 'ANY' or ddls == '(not set)':
                severity = sat.SEV_LOW
    else:
        summary += ' No external services found.'

    remarks = 'External procedures allow code written in other languages ' + \
              'to be executed from PL/SQL. Note that modifications to ' + \
              'external code cannot be controlled by the database. Be ' + \
              'careful to ensure that only trusted code libraries are ' + \
              'available to be executed. ' + \
              'Although the database can spawn its own process to execute ' + \
              'the external procedure, it is advisable to configure a ' + \
              'listener service for this purpose so that the external ' + \
              'code can run as a less-privileged OS user. The ' + \
              'listener configuration should set EXTPROC_DLLS to identify ' + \
              'the specific shared library code that can be executed ' + \
              'rather than using the default value ANY.'
    refs = {'CIS': 'Recommendation 2.1.2'}

    sat.finding('External Procedures', 'CONF.EXTPROC', summary,
        severity, details, remarks, refs)

# CONF.DIR - Directory Objects
def directories_info():
    data = sat.get_data('directory_info', 1)
    db_info_data = sat.get_data('db_identity', 1)

    if data is None or db_info_data is None:
        sat.diag('Skipped Directory Objects')
        return

    platform = sat.get_index('db_identity', 'platform')
    if 'WINDOWS' in db_info_data[0][platform].upper():
        path_delimiter = '\\'
    else:
        path_delimiter = '/'

    # Try to get version 11 as the information is more reliable.
    priv_data = sat.get_data('directory_priv', 11)
    if priv_data is None:
         priv_data = sat.get_data('directory_priv', 1)

    if priv_data is None:
        sat.diag('Skipped Directory Privileges')
        priv_data = []
    else:
        dir_name = sat.get_index('directory_priv', 'directory_name')
        grantee = sat.get_index('directory_priv', 'grantee')
        priv = sat.get_index('directory_priv', 'privilege')

    db_file_data = sat.get_data('data_files', 1)
    if db_file_data is None:
        sat.diag('Skipped Data Files')
        db_file_data = []
    else:
        file_name = sat.get_index('data_files', 'file_name')

    name = sat.get_index('directory_info', 'directory_name')
    path = sat.get_index('directory_info', 'directory_path')

    # Get ORACLE_HOME directory path.
    oh_dir = get_from_env_data('ORACLE_HOME')
    if oh_dir is None:
        sat.diag('Skipped ORACLE_HOME Directory Check')
    else:
        # ORACLE_HOME/dbs and ORACLE_HOME/bin
        dbs_dir = oh_dir + path_delimiter + 'dbs'
        bin_dir = oh_dir + path_delimiter + 'bin'

    # Get AUDIT_FILE_DEST
    audit_file_dir = sys_param_dict.get('AUDIT_FILE_DEST')

    dict = {}
    dict['oh_dir'] = []
    dict['dbs_dir'] = []
    dict['bin_dir'] = []
    dict['audit_file_dir'] = []
    dict['data_file_dir'] = []
    write_exec_dirs = []

    if len(data) > 0:
        summary = 'Found ' + sing_plural(len(data), 'directory object.',
                                                    'directory objects.')
    else:
        summary = 'No directory objects found.'

    db_file_dict = {}
    for x in db_file_data:
        db_file_dir = x[file_name][0:x[file_name].rfind(path_delimiter)+1]
        db_file_name = x[file_name].split(path_delimiter)[-1]
        if not db_file_dict.get(db_file_dir): 
            db_file_dict[db_file_dir] = []
        db_file_dict[db_file_dir].append(db_file_name) 

    details =''
    for x in data:
        if x[path] and x[path][-1] != path_delimiter:
            dir_path = x[path] + path_delimiter
        else:
            dir_path = x[path]
        details += 'Directory Name: ' + x[name] + '\n'
        details += 'Path = ' +  dir_path

        grantees = []
        write_access = False
        execute_access = False

        for y in priv_data:
            if x[name] == y[dir_name]:
                g_info = y[grantee] + '(' +  y[priv] + ')'
                grantees.append(g_info)
                if y[priv] == 'WRITE':
                    write_access = True
                elif y[priv] == 'EXECUTE':
                    execute_access = True

        if len(grantees) > 0:
            details += '\nUsers or roles with access: '
            details += join_list(grantees)

        if db_file_dict.get(dir_path):
            details += '\nAccess to data files: '
            details += join_list(db_file_dict[dir_path])
            dict['data_file_dir'].append(x[name])
        
        details += '\n\n'

        # check if the directory is both writable and executable
        # by database users.
        if write_access and execute_access:
            write_exec_dirs.append(x[name])

        # Check if the directory points to ORACLE_HOME, ORACLE_HOME/bin,
        # or ORACLE_HOME/dbs.
        if oh_dir is not None:
            if x[path] == oh_dir:
                dict['oh_dir'].append(x[name])
            elif x[path] == dbs_dir:
                dict['dbs_dir'].append(x[name])
            elif x[path] == bin_dir:
                dict['bin_dir'].append(x[name])

        # Check if the directory points to AUDIT_FILE_DEST.
        if audit_file_dir is None:
            sat.diag('Skipped Audit File Destination Check')
        else:
            if x[path] == audit_file_dir:
                dict['audit_file_dir'].append(x[name])

    count = len(dict['oh_dir']) + len(dict['dbs_dir']) + \
            len(dict['bin_dir']) + len(dict['audit_file_dir']) + \
            len(dict['data_file_dir'])

    if write_exec_dirs or dict['dbs_dir'] or \
       dict['bin_dir'] or dict['audit_file_dir'] or dict['data_file_dir']:
        severity = sat.SEV_HIGH
    elif dict['oh_dir']:
        severity = sat.SEV_MEDIUM
    else:
        severity = sat.SEV_UNKNOWN

    if count > 0:
        summary += ' Found ' + sing_plural(count, 'directory object', 
                                                  'directory objects') + \
                   ' allowing access to restricted Oracle directory paths.'

        details += '\n'
        if len(dict['oh_dir']) > 0:
            details += 'Access to $ORACLE_HOME: ' + \
                       join_list(dict['oh_dir']) + '\n'
        if len(dict['dbs_dir']) > 0:
            details += 'Access to $ORACLE_HOME/dbs: ' + \
                       join_list(dict['dbs_dir']) + '\n'
        if len(dict['bin_dir']) > 0:
            details += 'Access to $ORACLE_HOME/bin: ' + \
                       join_list(dict['bin_dir']) + '\n'
        if len(dict['audit_file_dir']) > 0:
            details += 'Access to audit file destination: ' + \
                       join_list(dict['audit_file_dir']) + '\n'
        if len(dict['data_file_dir']) > 0:
            details += 'Access to data file directories: ' + \
                       join_list(dict['data_file_dir']) + '\n'
    else:
        summary += ' No directory objects allow access to ' + \
                           'restricted Oracle directory paths.'

    if len(write_exec_dirs) > 0:
        summary += ' Found ' + sing_plural(len(write_exec_dirs), 
                                           'directory object',
                                           'directory objects') + \
                   ' with both write and execute access.'

        details += '\nDirectories with both write and execute access: '
        details += join_list(write_exec_dirs)
    else:
        summary += ' No directory objects allow both write and execute access.'

    remarks = "Directory objects allow access to the server's file " \
        "system from PL/SQL code within the database. Access to " \
        "files that are used by the database kernel itself " \
        "should not be permitted, as this may alter the " \
        "operation of the database and bypass its access " \
        "controls."

    sat.finding('Directory Objects', 'CONF.DIR', summary,
        severity=severity, details=details, remarks=remarks)

# CONF.LINKS - Database Links
def dblink_info():
    data = sat.get_data('db_links', 1)
    if data is None:
        sat.diag('Skipped Database Links')
        return

    link_name = sat.get_index('db_links', 'db_link')
    username = sat.get_index('db_links', 'username')
    owner = sat.get_index('db_links', 'owner')

    val = sys_param_dict.get('GLOBAL_NAMES')
    if val is None:
        details = ''
        sat.diag('Skipped GLOBAL_NAMES parameter check')
    else:
        details = 'GLOBAL_NAMES=' + display_string(val) + '\n\n'

    for priv in ('CREATE DATABASE LINK', 'CREATE PUBLIC DATABASE LINK'):
        g_list, num_admin = get_sys_priv_grantees(priv)
        details += 'Users with ' + priv + ' privilege: ' + \
            join_list(g_list) + '\n'

    details += '\n'
    private_links = []
    public_links = []
    if len(data) == 0:
        summary = 'No database links found.'
        severity = sat.SEV_OK
    else:
        summary = 'Found ' + sing_plural(len(data),
            'database link', 'database links') + '.'
        severity = sat.SEV_UNKNOWN
        for x in data:
            if x[username]:
                link = '%s (User %s)' % (x[link_name], x[username])
            else:
                link = x[link_name]
            if x[owner] == 'PUBLIC':
                public_links.append(link)
            else:
                private_links.append('%s: %s' % (x[owner], link))

        if private_links:
            details += 'Private links:\n'
            for link in private_links:
                details += link + '\n'
            details += '\n'
        if public_links:
            details += 'Public links:\n'
            for link in public_links:
                details += link + '\n'

    remarks = 'Database links allow users to execute SQL statements ' + \
        'that access tables in other databases. This allows for both ' + \
        'querying and storing data on the remote database. ' + \
        'It is advisable to set GLOBAL_NAMES to TRUE in order to ensure ' + \
        'that link names match the databases they access.'
    refs = {'CIS': 'Recommendation 2.2.3'}
    sat.finding('Database Links', 'CONF.LINKS', summary,
        severity, details, remarks, refs)

# CONF.NETACL - Network Access Control
def network_acl():
    data = sat.get_data('network_acl', 1)
    if data is None:
        sat.diag('Skipped Network ACL')
        return

    acl = sat.get_index('network_acl', 'acl')
    host = sat.get_index('network_acl', 'host')
    l_port = sat.get_index('network_acl', 'lower_port')
    u_port = sat.get_index('network_acl', 'upper_port')

    if len(data) > 0:
        summary = 'Found ' + \
                  sing_plural(len(data), 'network ACL.', 'network ACLs.')
    else:
        summary = 'No network ACLs found.'

    data2 = sat.get_data('network_acl_privilege', 1)
    if data2 is None:
        sat.diag('Skipped Network ACL privilege')
    else:
        acl2 = sat.get_index('network_acl_privilege', 'acl')
        prin = sat.get_index('network_acl_privilege', 'principal')
        priv = sat.get_index('network_acl_privilege', 'privilege')
        grant = sat.get_index('network_acl_privilege', 'is_grant')
        inv = sat.get_index('network_acl_privilege', 'invert')
        sdate = sat.get_index('network_acl_privilege', 'start_date')
        edate = sat.get_index('network_acl_privilege', 'end_date')

    if len(data) == 0:
        details = None
    else:
        details = ''
        for x in data:
            if x[l_port] is None:
                lower = 'Min'
            else:
                lower = x[l_port]
            if x[u_port] is None:
                upper = 'Max'
            else:
                upper = x[l_port]

            details += x[acl] + ' (Host: ' + x[host] + ', '
            details += 'Ports: %s - %s)\n' % (lower, upper)

            if data2 is None:
                continue

            # build the principal list.
            plist = []
            for y in data2:
                if y[inv].upper() == 'TRUE':
                    details += 'Inverse Principal: %s, ' % y[prin]
                else:
                    details += 'Principal: %s, ' % y[prin]
                if y[grant]:
                    details += 'Action: grant, '
                else:
                    details += 'Action: deny, '
                details += 'Privilege: %s' % y[priv]
                if len(y[sdate]) > 0:
                    details += ', start_date=' + y[sdate]
                if len(y[edate]) > 0:
                    details += ', end_date=' + y[edate]
                details += '\n'
            details += '\n'

    severity = sat.SEV_UNKNOWN
    remarks = 'Network ACLs control the external servers that database ' + \
        'users can access using network packages such as UTL_TCP ' + \
        'and UTL_HTTP. Specifically, a database user needs the connect ' + \
        'privilege to an external network host computer if he or she is ' + \
        'connecting using the UTL_TCP, UTL_HTTP, UTL_SMTP, and UTL_MAIL ' + \
        'utility packages. To convert between a host name and its IP ' + \
        'address using the UTL_INADDR package, the resolve privilege is ' + \
        'required. Make sure that these permissions are limited ' + \
        'to the minimum required by each user.'

    sat.finding('Network Access Control', 'CONF.NETACL', summary,
                severity, details=details, remarks=remarks)

# CONF.XMLACL - XML Database Access Control
def xml_acl():
    data = sat.get_data('xml_acl', 1)
    if data is None:
        sat.diag('Skipped XML ACL')
        return
    xml_acl = sat.get_index('xml_acl', 'xml_acl')

    if len(data) > 0:
        summary = 'Found ' + sing_plural(len(data), 'XML Database ACL.',
                                                    'XML Database ACLs.')
        details = ''
        for x in data:
            acl = x[xml_acl]
            details += process_xml_acl(acl) + '\n'
    else:
        summary = 'No XML Database ACLs found. '
        details = None

    severity = sat.SEV_UNKNOWN
    remarks = 'XML ACLs control access to database resources using the ' + \
        'XML DB feature. Every resource in the Oracle XML DB Repository ' + \
        'hierarchy has an associated ACL. The ACL mechanism specifies ' + \
        'a privilege-based access control for resources to principals, ' + \
        'which are database users or roles. Whenever a resource is ' + \
        'accessed, a security check is performed, and the ACL determines ' + \
        'if the requesting user has sufficient privileges to access the ' + \
        'resource. Make sure that these privileges are limited to the ' + \
        'minimum required by each user.'

    sat.finding('XML Database Access Control', 'CONF.XMLACL', summary,
           severity, details=details, remarks=remarks)

# param_should
#   param      - parameter name
#   rec_val    - recommended value
#   cnt        - the number of parameters checked by the caller (default 0)
#   num_issues - the number of issues found by the caller (default 0)
#   msg        - the detailed message collected by the caller (default '')
# Returns
#   cnt        - cnt+1 if the parameter is checked; otherwise cnt
#   num_issues - num_issues+1 if an issue is found; otherwise num_issues
#   msg        - msg+parameter_setting_string if the paramter is checked;
#                otherwise msg
#
# This routine checks if the given parameter setting matches the given
# recommended value. The routine can be used to keep track of the number
# of checked parameters, the number of issues found, etc.
#
def param_should(param, rec_val, cnt=0, num_issues=0, msg=''):
    val = sys_param_dict.get(param)

    if val is None:
        return cnt, num_issues, msg
    else:
        val = val.upper()
        cnt += 1

    if val != rec_val:
        num_issues += 1
        msg += param + '=' + display_string(val) + '. ' + \
               'Recommended value is ' + display_string(rec_val)  + '.\n'
    else:
        msg += param + '=' + display_string(val) + '\n'

    return cnt, num_issues, msg

# param_should_not
#   param      - parameter name
#   risky_val  - value that should not be set
#   rec_val    - recommended value
#   cnt        - the number of parameters checked by the caller (default 0)
#   num_issues - the number of issues found by the caller (default 0)
#   msg        - the detailed message collected by the caller (default '')
# Returns
#   cnt        - cnt+1 if the parameter is checked; otherwise cnt
#   num_issues - num_issues+1 if an issue is found; otherwise num_issues
#   msg        - msg+parameter_setting_string if the paramter is checked;
#                otherwise msg
#
# This routine checks if the given parameter setting matches the
# risky value. The routine can be used to keep track of the number
# of checked parameters, the number of issues found, etc.
#
def param_should_not(param, risky_val, rec_val, cnt=0, num_issues=0, msg=''):
    val = sys_param_dict.get(param)

    if val is None:
        return cnt, num_issues, msg
    else:
        val = val.upper()
        cnt += 1

    if val == risky_val:
        num_issues += 1
        msg += param + '=' + display_string(val) + '. ' + \
               'Recommended value is ' + display_string(rec_val)  + '.\n'
    else:
        msg += param + '=' + display_string(val) + '\n'

    return cnt, num_issues, msg

# param_check_summary
#   num_checked - total parameters examined
#   num_issues - number of issues found
# Returns
#   summary text
#
# Format a summary message for the number or parameters examined and
# issues found.
#
def param_check_summary(num_checked, num_issues):
    summary = 'Examined ' + \
              sing_plural(num_checked, 'initialization parameter. ', 
                                       'initialization parameters. ')

    if num_issues > 0:
        summary += 'Found ' + sing_plural(num_issues, 'issue.', 'issues.')
    else:
        summary += 'No issues found.'

    return summary

# process_xml_acl
#   xacl - string containing ACL in XML format
# Returns
#   text description
#
# Parse an XML ACL and return human-readable text including namespace,
# description, and one line for each ACE.
#
def process_xml_acl(xacl):
    try:
        acl = ET.fromstring(xacl)
    except Exception as e:
        sat.diag('Error during XML ACL parsing')
        sat.diag(str(e))
        return ''

    if acl.tag.endswith('acl'):
        ns = acl.tag[:-3]
    else:
        sat.diag('Skipped Invalid XML ACL')
        return ''

    detail = 'Namespace: ' + ns + '\n'

    desc = acl.get('description')
    if desc is not None:
        detail += 'Description: ' + desc + '\n'

    for ace in acl:
        principal = ace.find(ns + 'principal')

        if principal is None:
            invert = ace.find(ns + 'invert')

            if invert is not None:
                ip = invert.find(ns + 'principal')
                detail += 'Inverse Principal: ' + ip.text
            else:
                detail += 'No Principal'
        else:
            detail += 'Principal: ' + principal.text

        type = ace.find(ns + 'grant')
        if type is not None:
            if type.text == 'true':
                detail += ', Action: grant'
            else:
                detail += ', Action: deny'

        priv = ace.find(ns + 'privilege')
        if priv is not None:
            plist = []
            for p in priv:
                plist.append(p.tag.replace(ns, '', 1))
            detail += ', Privileges: ' + join_list(plist) + '\n'

    return detail

###
### Network Configuration
###

def sqlnet_ora():
    dict = parse_configfile('sqlnet.ora')
    if dict is None:
        sat.diag('Skipped SQLNET Parameters')
        return

    sqlnet_network_encryption(dict)
    sqlnet_tcp_nodes(dict)
    sqlnet_banner(dict)

# NET.CRYPT - Network Encryption
def sqlnet_network_encryption(dict):
    details = ''
    summary = ''
    severity = sat.SEV_OK

    server_enc = dict.get('SQLNET.ENCRYPTION_SERVER')
    # the default value of SQLNET.ENCRYPTION_SERVER is ACCEPTED.
    if server_enc is None:
        details += 'SQLNET.ENCRYPTION_SERVER is not set ' + \
                   '(default value = ACCEPTED).\n'
        server_enc = 'ACCEPTED'
    else:
        server_enc = server_enc.upper()
        details += 'SQLNET.ENCRYPTION_SERVER = ' + server_enc + '\n'

    server_cs = dict.get('SQLNET.CRYPTO_CHECKSUM_SERVER')
    # the default value of SQLNET.CRYPTO_CHECKSUM_SERVER is ACCEPTED.
    if server_cs is None:
        details += 'SQLNET.CRYPTO_CHECKSUM_SERVER is not set ' + \
                   '(default value = ACCEPTED).'
        server_cs = 'ACCEPTED'
    else:
        server_cs = server_cs.upper()
        details += 'SQLNET.CRYPTO_CHECKSUM_SERVER = ' + server_cs

    details += '\n\n'

    # get listener protocols from LISTENER.ORA.
    l_dict = parse_configfile('listener.ora')
    num_listeners = 0
    num_tcp = 0
    num_tcps = 0

    if l_dict is None:
        details += 'LISTENER.ORA not available.\n'
    else:
        l_protocols = get_listener_protocols(l_dict)

        if len(l_protocols) == 0:
            details += 'No valid listeners found.\n'
        else:
            num_listeners = len(l_protocols)
            details += 'Examined ' + \
                       sing_plural(num_listeners, 'listener.', 'listeners.')
            details += '\n\n'

            for x in l_protocols:
                listener = x[0]
                proto = x[1]
                details += listener + ': '
                details += 'IPC (%d), ' % proto['IPC']
                details += 'TCP (%d), ' % proto['TCP']
                details += 'TCPS (%d)' % proto['TCPS']
                details += '\n'
                num_tcp +=  proto['TCP']
                num_tcps += proto['TCPS']

    details += '\n'
    ssl_cert_revoc = dict.get('SSL_CERT_REVOCATION')
    # the default value of SSL_CERT_REVOCATION is NONE.
    if ssl_cert_revoc is None:
        details += 'SSL_CERT_REVOCATION is not set (default value = NONE).'
        ssl_cert_revoc = 'NONE'
    else:
        ssl_cert_revoc = ssl_cert_revoc.upper()
        details += 'SSL_CERT_REVOCATION = ' + ssl_cert_revoc

    # native encryption is being used.
    if server_enc != 'REJECTED':
        if server_enc == 'REQUIRED':
            summary += 'Native encryption is fully enabled. '
        else:
            summary += 'Native encryption is accepted but not required. '
            severity = sat.SEV_MEDIUM

        if server_cs == 'REQUIRED':
            summary += 'Integrity check using checksums is ' + \
                           'fully enabled.'
        elif server_cs == 'REJECTED':
            summary += 'Integrity check using checksums is '+ \
                       'not enabled.'
            severity = max(severity, sat.SEV_LOW)
        else:
            summary += 'Integrity check using checksums is ' + \
                       'accepted but not required.'
            severity = max(severity, sat.SEV_LOW)
    # native encryption is disabled, but SSL is used for some ports.
    elif num_tcps > 0:
        if num_tcp == 0:
            summary += 'TLS encryption is fully enabled. '
        else:
            summary += 'TLS encryption is enabled on some ports. '
            severity = sat.SEV_MEDIUM

        if ssl_cert_revoc == 'REQUIRED':
            summary += 'Certificate revocation check is ' + \
                                   'fully enabled.'
        elif ssl_cert_revoc == 'NONE':
            summary += 'Certificate revocation check is disabled.'
            severity = max(severity, sat.SEV_LOW)
        else:
            summary += 'Certificate revocation check is ' + \
                                   'requested but not required.'
            severity = max(severity, sat.SEV_LOW)
    # native encryption is disabled, and no ports are using SSL.
    else:
        if num_tcp > 0:
            summary += 'Neither native encryption nor TLS ' + \
                                   'encryption is used.'
            severity = sat.SEV_MEDIUM
        # no TCP or TCPS ports found; just complain about native
        # encryption.
        else:
            summary += 'Native encryption is not enabled. '
            severity = sat.SEV_MEDIUM

            if server_cs == 'REQUIRED':
                summary += 'Integrity check using ' + \
                           'checksums is fully enabled.'
            elif server_cs == 'REJECTED':
                summary += 'Integrity check using checksums is not enabled.'
            else:
                summary += 'Integrity check using checksums is ' + \
                            'accepted but not required.'

    remarks = 'Network encryption protects the confidentiality and ' + \
        'integrity of communication between the database server ' + \
        'and its clients. Either Native Encryption or TLS should ' + \
        'be enabled. For Native Encryption, both ENCRYPTION_SERVER ' + \
        'and CRYPTO_CHECKSUM_SERVER should be set to REQUIRED. ' + \
        'If TLS is used, TCPS should be specified for all network ' + \
        'ports and SSL_CERT_REVOCATION should be set to REQUIRED.'

    sat.finding('Network Encryption', 'NET.CRYPT', summary,
        severity=severity, details=details, remarks=remarks)

# NET.CLIENTS - Client Nodes
def sqlnet_tcp_nodes(dict):
    severity = sat.SEV_OK

    # TCP.VALIDNODE_CHECKING must be set to YES for node check to be enabled.
    issue, details = network_parameter(dict=dict,
                                       para_name='TCP.VALIDNODE_CHECKING',
                                       unset_ok=True,
                                       default_value='NO',
                                       required_value='YES')

    if issue:
        summary = 'Valid node check is not enabled. '
        severity = sat.SEV_LOW
    else:
        summary = 'Valid node check is enabled. '

    # check TCP.INVITED_NODES and TCP.EXCLUDED_NODES
    inv_nodes = dict.get('TCP.INVITED_NODES')
    if inv_nodes is None:
        details += 'TCP.INVITED_NODES is not set.\n'
    else:
         details += 'TCP.INVITED_NODES=' + to_string(inv_nodes) + '\n'
    exc_nodes = dict.get('TCP.EXCLUDED_NODES')
    if exc_nodes is None:
        details += 'TCP.EXCLUDED_NODES is not set.\n'
    else:
        details += 'TCP.EXCLUDED_NODES=' + to_string(exc_nodes) + '\n'

    # complain if none of the paramters is set.
    if inv_nodes is None and exc_nodes is None:
        severity = sat.SEV_MEDIUM
        summary += 'Neither TCP.INVITED_NODES nor TCP.EXCLUDED_NODES is set.'
    # complain if both parameters are set.
    elif inv_nodes and exc_nodes:
        severity = sat.SEV_LOW
        summary += 'Both TCP.INVITED_NODES and TCP.EXCLUDED_NODES are set.'
    else:
        summary += 'TCP.INVITED_NODES or TCP.EXCLUDED_NODES is set.'

    remarks = 'TCP.VALIDNODE_CHECKING should be enabled to control which ' + \
        'client nodes can connect to the database server. ' + \
        'Either a whitelist of client nodes ' + \
        'allowed to connect (TCP.INVITED_NODES) or a blacklist ' + \
        'of nodes that are not allowed (TCP.EXCLUDED_NODES) ' + \
        'may be specified. Configuring both lists ' + \
        'is an error; only the invited node list will be used in this case.'

    sat.finding('Client Nodes', 'NET.CLIENTS', summary,
        severity=severity, details=details, remarks=remarks)

# NET.BANNER - SQLNET Banners
def sqlnet_banner(dict):
    issue1, det1 = network_parameter(dict=dict,
                                     para_name='SEC_USER_AUDIT_ACTION_BANNER',
                                     case_sensitive=True)
    issue2, det2 = network_parameter(dict=dict,
                               para_name='SEC_USER_UNAUTHORIZED_ACCESS_BANNER',
                               case_sensitive=True)

    if issue1 or issue2:
        severity = sat.SEV_LOW
        summary = 'Connect banners are not fully configured.'
    else:
        severity = sat.SEV_OK
        summary = 'Connect banners are configured.'

    details = det1 + det2
    remarks = 'These banner messages are used to warn connecting users ' + \
        'that unauthorized access is not permitted and that ' + \
        'their activities may be audited.'

    sat.finding('SQLNET Banners', 'NET.BANNER', summary,
        severity=severity, details=details, remarks=remarks)

def listener_ora():
    dict = parse_configfile('listener.ora')
    if dict is None:
        sat.diag('Skipped LISTENER Parameters')
        return

    lsnr_cost_parameter(dict)
    lsnr_logging_listener_name(dict)

# NET.COST - Network Listener Configuration
def lsnr_cost_parameter(dict):
    list = get_listeners(dict)
    good = []
    bad = []
    sub_details = ''
    severity = sat.SEV_OK

    for lsnr in list:
        lsnr_name = lsnr.upper()
        sub_details += 'Parameter setting for ' + lsnr_name + ':\n'

        # check ADMIN_RESTRICTIONS_listener. Should be ON.
        para_name = 'ADMIN_RESTRICTIONS_' + lsnr_name
        admin_issue, det = network_parameter(dict=dict,
                                          para_name=para_name,
                                          unset_ok=True,
                                          default_value='OFF',
                                          required_value='ON')
        sub_details += det

        # check DYNAMIC_REGISTRATION_listener. Should be OFF.
        para_name = 'DYNAMIC_REGISTRATION_' + lsnr_name
        dr_issue, det = network_parameter(dict=dict,
                                          para_name=para_name,
                                          unset_ok=True,
                                          default_value='ON',
                                          required_value='OFF')
        sub_details += det

        # check VALID_NODE_CHECKING_REGISTRATION_listener. Should be ON.
        para_name = 'VALID_NODE_CHECKING_REGISTRATION_' + lsnr_name
        vncr_issue, det = network_parameter(dict=dict,
                                          para_name=para_name,
                                          unset_ok=True,
                                          default_value='OFF',
                                          forbidden_value='OFF')
        sub_details += det

        # check SECURE_PROTOCOL_listener.
        para_name = 'SECURE_PROTOCOL_' + lsnr_name
        sec_pro = dict.get(para_name)
        if sec_pro is None:
            sub_details += para_name + ' is not set.\n'
        else:
            sub_details += para_name + '=' + join_list(sec_pro) + '\n'

        # check SECURE_CONTROL_listener.
        para_name = 'SECURE_CONTROL_' + lsnr_name
        sec_con = dict.get(para_name)
        if sec_con is None:
            sub_details += para_name + ' is not set.\n'
        else:
            sub_details += para_name + '=' + join_list(sec_con) + '\n'

        # check SECURE_REGISTER_listener.
        para_name = 'SECURE_REGISTER_' + lsnr_name
        sec_reg = dict.get(para_name)
        if sec_reg is None:
            sub_details += para_name + ' is not set.\n'
        else:
            sub_details += para_name + '=' + join_list(sec_reg) + '\n'

        sub_details += '\n'

        # The recommended setting is:
        # ADMIN_RESTRICTIONS is on AND
        #   ((DYNAMIC_REGISTRATION is off) OR
        #   (VNCR is enabled) OR
        #   (either SECURE_PROTOCOL is set OR 
        #         both SECURE_CONTROL and SECURE_REGISTER are set)).
        if not admin_issue and (not dr_issue or not vncr_issue or \
        (sec_pro or (sec_con and sec_reg))):
            good.append(lsnr_name)
        else:
            bad.append(lsnr_name)

    if len(bad) > 0:
        severity = sat.SEV_MEDIUM

    summary, details = listener_summary(good, bad)
    details += '\n' + sub_details

    remarks = 'These parameters are used to limit changes to ' + \
        'the network listener configuration. ' + \
        'ADMIN_RESTRICTIONS should be enabled to prevent ' + \
        'parameter changes to the running listener. ' + \
        'One of the following ' + \
        'restrictions on service registration should be implemented: ' + \
        '(a) prevent changes by disabling DYNAMIC_REGISTRATION, ' + \
        '(b) limit the nodes that can make changes by enabling ' + \
        'VALID_NODE_CHECKING_REGISTRATION, or ' + \
        '(c) limit the network sources for changes using the COST ' + \
        'parameters SECURE_PROTOCOL, SECURE_CONTROL, and SECURE_REGISTER.'
    refs = {'CIS': 'Recommendation 2.1.1, 2.1.3, 2.1.4'}

    sat.finding('Network Listener Configuration', 'NET.COST', summary,
        severity, details, remarks, refs)

# NET.LISTENLOG - Listener Logging Control
def lsnr_logging_listener_name(dict):
    good = []
    bad = []
    severity = sat.SEV_OK
    sub_details = ''

    for lsnr in get_listeners(dict):
        lsnr_name = lsnr.upper()

        para_name = 'LOGGING_' + lsnr_name
        issue, det = network_parameter(dict=dict,
                                       para_name=para_name,
                                       unset_ok=True,
                                       default_value='ON',
                                       required_value='ON')

        sub_details += 'Parameter setting for ' + lsnr_name + ':\n'
        sub_details += det

        if issue:
            bad.append(lsnr_name)
        else:
            good.append(lsnr_name)

    if len(bad) > 0:
        severity = sat.SEV_LOW

    summary, details = listener_summary(good, bad)
    details += '\n' + sub_details

    remarks = 'This parameter enables logging of listener activity. ' + \
        'Log information can be useful for troubleshooting and ' + \
        'to provide early warning of attempted attacks.'

    sat.finding('Listener Logging Control', 'NET.LISTENLOG', summary=summary,
        severity=severity, details=details, remarks=remarks)

# network_parameter
#   dict - parsed data from sqlnet file or listener file
#   para_name - the name of the result table
#   unset_ok - True if it is OK for the parameter to be unset
#   default_value - the default value of the parameter
#   required_value - the required value for the parameter, if set
#   forbidden_value - the value that the parameter cannot be set to
#   case_sensitive - True if required_value/forbidden_value is case sensitive,
#                    If False, these values must be upper case.
# Returns
#   issue_found - True if issue is found; otherwise False
#   details - the details of the parameter setting
# Check whether a network parameter in the listener.ora file or sqlnet.ora file
# is set properly.
#
def network_parameter(dict, para_name, unset_ok=False, default_value=None,
                      required_value=None, forbidden_value=None,
                      case_sensitive=False):
    details = ''
    issue_found = False
    input_value = ''

    if para_name not in dict:
        if not unset_ok:
            details = para_name + ' is not set. '
            details += 'Should be set to a proper value.\n'
            issue_found = True
            return issue_found, details

        if default_value is not None:
            input_value = default_value
            details = para_name + ' is not set '
            details += '(default value = ' + default_value + ')'
    else:
        input_value = to_string(dict[para_name])
        if not case_sensitive:
            input_value = input_value.upper()
        details += para_name + '=' + input_value

    if required_value is not None and input_value != required_value:
        details += '. Recommended value is %s.\n' % required_value
        issue_found = True
    elif forbidden_value is not None and input_value == forbidden_value:
        details += '. Should not be set to %s.\n' % forbidden_value
        issue_found = True
    else:
        details += '.\n'

    return issue_found, details

# listener_summary
#   good_list - list of listener names with no errors
#   bad_list - list of listener names with errors
# Returns
#   summary - summary text
#   details - detail text
#
# Return summary and detail text listing the names of listeners with
# and without configuration errors.
#
def listener_summary(good_list, bad_list):
    total = len(good_list) + len(bad_list)
    summary = 'Examined ' + sing_plural(total, 'listener. ', 'listeners. ') + \
              'Found ' + sing_plural(len(bad_list), 'listener', 'listeners') + \
              ' not configured properly.' 
    details = ''
    if len(good_list) > 0:
        details += 'Listeners configured properly: ' + \
            join_list(good_list) + '\n'
    if len(bad_list) > 0:
        details += 'Listeners not configured properly: ' + \
            join_list(bad_list) + '\n'
    return summary, details

# get_protocol_from_address
#   address - dict containing info for a listener address
#   proto_count - result from previous call
# Returns
#   dict containing number of instances for each protocol name
#
# Count the number of instances of each protocol for a given address.
#
def get_protocol_from_address(address, proto_count):
    protocol = address.get('PROTOCOL')

    if protocol is None:
        return proto_count
    else:
        protocol = protocol.upper()

    if protocol in ('IPC', 'TCP', 'TCPS'):
        proto_count[protocol] += 1

    return proto_count

# collect_protocols
#   dict - parsed info for a single listener
#   proto_count - result from previous call
# Returns
#   dict containing number of instances of each protocol
#
# Count the number of instances of each protocol used by a listener.
#
def collect_protocols(dict, proto_count):
    for k, v in dict.items():
        if k == 'ADDRESS':
            # it is possible that we have a list of addresses.
            if type(v) == type([]):
                for x in v:
                    proto_count = get_protocol_from_address(x, proto_count)
                continue

            protcocols = get_protocol_from_address(v, proto_count)
        elif type(v) == type({}):
            proto_count = collect_protocols(v, proto_count)
        elif type(v) == type([]):
            for x in v:
                proto_count = collect_protocols(x, proto_count)
        else:
            continue

    return proto_count

# get_listener_protcols
#   dict - parsed listener.ora file
# Returns
#   list of listeners and the protocols used by each
#
# Find all listener instances and the protocols they use.
#
def get_listener_protocols(dict):
    result = []

    for k, v in dict.items():
        # skip static service registrations
        if k.startswith('SID_LIST_'):
            continue

        if type(v) != type({}):
            continue

        proto_count = {'IPC': 0, 'TCP': 0, 'TCPS': 0}
        proto_count = collect_protocols(v, proto_count)

        if sum(proto_count.values()) > 0:
            result.append([k, proto_count])

    return result

# contains_key
#   struct - data structure representing sqlnet.ora or listener.ora
#   keywords - list of keywords to find
# Returns
#   True if struct contains a dictionary with at least one specified key
#
# Traverse the input data structure (containing dictionaries and lists)
# recursively to see if it includes a dictionary with at least one of
# the specified keys.
#
def contains_key(struct, keywords):
    if type(struct) == dict:
        for k, v in struct.items():
            if k in keywords:
                return True
            elif contains_key(v, keywords):
                return True
        return False
    elif type(struct) == list:
        for elem in struct:
            if contains_key(elem, keywords):
                return True
        return False
    else:
        return False

# get_listeners
#   dict - parsed listener.ora file
# Returns
#   list of listener names
#
# Find all listener instances in listener.ora.
#
def get_listeners(dict):
    listener_list = []
    for k, v in dict.items():
        if contains_key(v, ('ADDRESS', 'ADDRESS_LIST')):
            listener_list.append(k)

    return listener_list

###
### Operating System
###

# OS.AUTH - OS Authentication
def os_authentication_user():
    data_group = sat.get_data('os_group_file', 1)
    if data_group is None:
        sat.diag('Skipped OS Authentication')
        return None

    data_dba = sat.get_data('osdba_group', 1)
    mem_dba, details_dba = os_group_members('SYSDBA', data_dba)
    all_group_users = list(mem_dba)

    details_opr = ''
    details_bkp = ''
    details_km = ''
    details_dg = ''
    details_rac = ''

    # In 10g, osdbagrp works only for the OS group for SYSDBA.
    if target_db_version >= '11':
        data_opr = sat.get_data('sysoper_group', 1)
        data_bkp = sat.get_data('sysbackup_group', 1)
        data_km  = sat.get_data('syskm_group', 1)
        data_dg  = sat.get_data('sysdg_group', 1)
        data_rac = sat.get_data('sysrac_group', 1)
        mem_opr, details_opr = os_group_members('SYSOPER', data_opr)
        mem_bkp, details_bkp = os_group_members('SYSBACKUP', data_bkp)
        mem_km,  details_km  = os_group_members('SYSKM', data_km)
        mem_dg,  details_dg  = os_group_members('SYSDG', data_dg)
        mem_rac, details_rac = os_group_members('SYSRAC', data_rac)
        all_group_users += list(mem_opr + mem_bkp + mem_km  + \
                                        mem_dg  + mem_rac)

    total_num = len(set(all_group_users))

    summary = sing_plural(total_num, 'OS user', 'OS users') + \
              ' can connect to the database via OS authentication.'

    details = details_dba + details_opr + details_bkp + \
                  details_km + details_dg + details_rac

    remarks = 'OS authentication allows operating system users within ' + \
        'the specified user group to connect to the database ' + \
        'with administrative privileges. This shows the OS group ' + \
        'names and users that can exercise each administrative ' + \
        'privilege.'

    sat.finding('OS Authentication', 'OS.AUTH', summary,
        severity=sat.SEV_UNKNOWN, details=details, remarks=remarks)

# OS.PMON - Process Monitor Process
def check_pmon_proc():
    proclist = find_processes('pmon')
    if proclist is None:
        sat.diag('Skipped PMON processes')
        return None

    # Get Oracle instance name from env.
    inst_name = get_from_env_data('ORACLE_SID')

    # Get ORACLE_HOME from env.
    oh_dir = get_from_env_data('ORACLE_HOME')

    # Find the Oracle home owner.
    oh_owner = None
    oh_data =  sat.get_data('oracle_home_owner', 1)
    if oh_data is not None:
        oh_owner = oh_data[0][0]

    # Process the PMON process information. Note that it is possible that
    # there are more than one PMON processes (e.g., multiple instances).
    owners = set([])
    plist = []
    pmon_owner = None
    pmon_proc = None

    for p in proclist:
        owners.add(p['owner'])
        info = '\tOwner: ' + p['owner'] + ', Command: ' + p['command']
        # Try to find the owner of the PMOM process belonging to
        # the target instance.
        if inst_name is not None and inst_name in p['command']:
            pmon_owner = p['owner']
            pmon_proc = p['command']
        else:
            plist.append(info)

    if pmon_proc is None:
        num_proc = len(plist)
    else:
        num_proc = len(plist) + 1

    summary = 'Found ' + \
              sing_plural(num_proc, 'PMON process. ', 'PMON processes. ')
    details = ''

    if pmon_owner is None or oh_owner is None:
        severity = sat.SEV_UNKNOWN
        sat.diag('Skipped PMON process owner check')
    else:
        if pmon_owner == oh_owner:
            severity = sat.SEV_OK
            summary += 'The owner of the PMON process ' + \
                                  'matches the ORACLE_HOME owner.'
        else:
            severity = sat.SEV_MEDIUM
            summary += 'The owner of the PMON process ' + \
                          'does not match the ORACLE_HOME owner.'

        details = 'PMON process: ' + pmon_proc + ', '
        details += 'Owner: ' + pmon_owner + '\n'
        details += 'ORACLE_HOME owner: ' + oh_owner + '\n'

    if len(plist) > 0:
        details += '\nOther PMON processes found:\n'
        details += join_list(plist, '\n')

    remarks = 'The PMON process monitors user processes and frees ' + \
        'resources when they terminate. This process should run ' + \
        'with the user ID of the ORACLE_HOME owner.'

    sat.finding('Process Monitor Process', 'OS.PMON', summary,
        severity=severity, details=details, remarks=remarks)

    return owners

# OS.AGENT - Agent Processes
# OS.LISTEN - Listener Processes
def pmon_agent_tnslsnr():
    powners = check_pmon_proc()
    aowners, asummary, adetails = process_ps_data('agent', 'Agent')
    lowners, lsummary, ldetails = process_ps_data('tnslsnr', 'Listener')

    aseverity = sat.SEV_OK
    lseverity = sat.SEV_OK

    if powners is None or aowners is None or lowners is None:
        sat.diag('Skipped Agent and Listener process check')
    else:
        # Check if Agent process owners overlap with PMON or Listener
        # process owners
        overlap = aowners.intersection(powners.union(lowners))
        if len(overlap) == 0:
            asummary += 'Agent process owners ' + \
                  'do not overlap with Listener or PMON ' + \
                  'process owners.'
        else:
            aseverity = sat.SEV_LOW
            asummary = 'Some Agent process owners overlap ' + \
                       'with Listener or PMON process owners.'

        # Check if Listener process owners overlap with PMON or Agent
        # process owners
        overlap =  lowners.intersection(powners.union(aowners))
        if len(overlap) == 0:
            lsummary += 'Listener process owners ' + \
              'do not overlap with Agent or PMON process owners.'
        else:
            lseverity = sat.SEV_LOW
            lsummary += 'Some Listener process owners overlap ' + \
                       'with Agent or PMON process owners.'

    remarks = 'Agent processes are used by Oracle Enterprise Manager ' + \
        'to monitor and manage the database. These processes ' + \
        'should run with a user ID separate from the database ' + \
        'and listener processes.'

    if asummary is not None:
        sat.finding('Agent Processes', 'OS.AGENT',
                    summary=asummary, severity=aseverity, details=adetails,
                    remarks=remarks)

    remarks = 'Listener processes accept incoming network connections ' + \
        'and connect them to the appropriate database server ' + \
        'process. These processes should run with a user ID ' + \
        'separate from the database and agent processes.'

    if lsummary is not None:
        sat.finding('Listener Processes', 'OS.LISTEN',
                    summary=lsummary, severity=lseverity, details=ldetails,
                    remarks=remarks)

# OS.FILES - File Permissions in ORACLE_HOME
def db_file_permission():
    severity = sat.SEV_OK
    summary = ''
    details = ''

    oh_owner_data = sat.get_data('oracle_home_owner', 1)
    oh_owner = ''
    if oh_owner_data is not None and len(oh_owner_data) > 0:
        oh_owner = oh_owner_data[0][0]

    dbs_file_num, dbs_dir_num, dbs_file_perm_list, \
        dbs_dir_perm_list, dbs_file_owner_list = \
          file_permission(name='dbs_file_permission',
                          diag_msg='Skipped DBS File Permissions',
                          max_perms=int('660', 8), prefix_path='dbs')

    bin_file_num, bin_dir_num, bin_file_perm_list, \
        bin_dir_perm_list, bin_file_owner_list = \
          file_permission(name='executable_permission',
                          diag_msg='Skipped Executable File Permissions',
                          max_perms=int('755', 8), prefix_path='bin')

    sqlnet_file_num, sqlnet_dir_num, sqlnet_file_perm_list, \
        sqlnet_dir_perm_list, sqlnet_file_owner_list = \
          file_permission(name='ls_sqlnet.ora',
                          diag_msg='Skipped SQLNET.ORA Permission',
                          max_perms=int('664', 8))

    lsnr_file_num, lsnr_dir_num, lsnr_file_perm_list, \
        lsnr_dir_perm_list, lsnr_file_owner_list = \
          file_permission(name='ls_listener.ora',
                          diag_msg='Skipped LISTENER.ORA Permission',
                          max_perms=int('664', 8))

    total = dbs_file_num + dbs_dir_num + \
                bin_file_num + bin_dir_num + \
                sqlnet_file_num + sqlnet_dir_num + \
                lsnr_file_num + lsnr_dir_num

    # no data collected for file permissions; return.
    if total == 0:
        return

    total_errors = len(dbs_file_perm_list) + len(dbs_dir_perm_list) + \
                   len(dbs_file_owner_list) + len(bin_file_perm_list) + \
                   len(bin_dir_perm_list) + len(bin_file_owner_list) + \
                   len(sqlnet_file_perm_list) + len(sqlnet_dir_perm_list) + \
                   len(sqlnet_file_owner_list) + len(lsnr_file_perm_list) + \
                   len(lsnr_dir_perm_list) + len(lsnr_file_owner_list)

    dir_total = dbs_dir_num + bin_dir_num
    dir_errors = len(dbs_dir_perm_list) + len(bin_dir_perm_list) + \
                     len(sqlnet_dir_perm_list) + len(lsnr_dir_perm_list)

    bin_total = bin_file_num
    bin_errors = len(bin_file_perm_list)

    config_total = sqlnet_file_num+lsnr_file_num;
    config_errors = len(sqlnet_file_perm_list) + len(lsnr_file_perm_list)

    data_file_total = dbs_file_num
    data_file_errors = len(dbs_file_perm_list)

    summary = 'Examined ' + sing_plural(total, 'file. ', 'files. ') + \
              'Found ' + sing_plural(total_errors, 'error.', 'errors.')

    if total_errors > 0:
        severity = sat.SEV_MEDIUM

    oh_dir = get_from_env_data('ORACLE_HOME')
    if oh_dir is not None:
        details = 'ORACLE_HOME: ' + oh_dir + '\n'

    details += 'ORACLE_HOME owner: %s \n' % oh_owner + \
               'Directories: %d (%d permission errors) \n' % \
                   (dir_total, dir_errors) + \
               'Executables in $ORACLE_HOME/bin: ' \
                   '%d (%d permission errors) \n' % \
                   (bin_total, bin_errors) + \
               'Configuration files in $TNS_ADMIN: ' \
                   '%d (%d permission errors) \n' % \
                   (config_total, config_errors) + \
               'Data files in $ORACLE_HOME/dbs: ' \
                   '%d (%d permission errors) \n\n' % \
                   (data_file_total, data_file_errors)

    file_perm_list = dbs_file_perm_list + bin_file_perm_list + \
                         sqlnet_file_perm_list + lsnr_file_perm_list

    if len(file_perm_list) > 0:
        details += db_file_detail('Files with permission errors',
                                      file_perm_list)
    dir_perm_list = dbs_dir_perm_list + bin_dir_perm_list + \
                        sqlnet_dir_perm_list + lsnr_dir_perm_list

    if len(dir_perm_list) > 0:
        details += db_file_detail('Directories with permission errors',
                                      dir_perm_list)

    file_owner_list = dbs_file_owner_list + bin_file_owner_list + \
                          sqlnet_file_owner_list + lsnr_file_owner_list

    if len(file_owner_list) > 0:
        details += \
                  db_file_detail('Files or directories with unexpected owner',
                             file_owner_list)

    remarks = 'The ORACLE_HOME directory and its subdirectories contain ' +\
                'files that are critical to the correct operation of the ' +\
                'database, including executable programs, data files, and ' +\
                'configuration files. Operating system file permissions ' +\
                'must not allow these files to be modified by users other ' +\
                'than the ORACLE_HOME owner and must not allow other ' +\
                'users to directly read the contents of Oracle data files.'

    sat.finding('File Permissions in ORACLE_HOME', 'OS.FILES',
        summary, severity=severity, details=details, remarks=remarks)

# find_processes
#   cmdname - name of executable
# Returns
#   list of process tuples
#
# Find all processes runing the given command. Return a list of tuples
# containing owner and command strings.
#
def find_processes(cmdname):
    data = sat.get_data('processes', 1)
    if data is None or len(data) == 0:
        return None

    proclist = []
    # User is first field. Use header to find start of command field.
    cmd_index = data[0][0].find('COMMAND')
    if cmd_index < 0:
        cmd_index = data[0][0].find('CMD')
    for x in data:
        if re.search(cmdname, x[0]):
            fields = x[0].split()
            user = fields[0]
            if cmd_index >= 0:
                cmd = x[0][cmd_index:]
            else:
                cmd = ' '.join(fields[1:])
            proclist.append({'owner': user, 'command': cmd})
    return proclist

# process_ps_data
#   cmdname - name of executable
#   pname - human-readable process name
# Returns
#   owners - set of OS users executing instances of this command
#   summary - summary of processes found
#   details - details of processes found
#
# Return information about all processes running the given command.
#
def process_ps_data(cmdname, pname):
    proclist = find_processes(cmdname)
    if proclist is None:
        sat.diag('Skipped ' + pname + ' processes')
        return None, None, None

    owners = set()
    if len(proclist) > 0:
        summary = 'Found ' + sing_plural(len(proclist), pname + ' process. ', 
                                                        pname + ' processes. ')
        list = []
        for p in proclist:
            owners.add(p['owner'])
            info = 'Owner: ' + p['owner'] + '\nCommand: ' + p['command']
            list.append(info)
        details = join_list(list, '\n\n')
    else:
        summary = 'No ' + pname + ' processes found. '
        details = ''

    return owners, summary, details

# get_from_env_data
#   keyword - environment variable name
# Returns
#   string value or None
#
# Look up an environment variable and return its value.
#
def get_from_env_data(keyword):
    data = sat.get_data('environment', 1)
    if data is None:
        return None

    value = None
    for x in data:
        keyval = x[0].split('=')
        if keyword == keyval[0]:
            value = keyval[1]
            break
    return value

# decode_ls_data
#   data - result table containing /bin/ls output
# Returns
#   list of rows containing permission, owner, group, filename
#
# Parse output from ls command.
#
def decode_ls_data(data):
    rows = []

    for x in data:
        fields = x[0].split()

        # make sure that each line of ls command result is in proper format;
        # specifically, each line should have 9 fields and the permission 
        # values should be 10 chars long (e.g., -rwxr-x--x).
        if len(fields) != 9:
            continue

        rows.append([fields[0][0:10], fields[2], fields[3], fields[-1]])

    return rows

# capped_perms
#   perm - actual file permissions ('rwx' format)
#   max_perms - maximum permissions allowed (octal number)
# Returns
#   capped - capped file permissions ('rwx' format)
#
# Return the actual file permissions, including only bits allowed by
# max_perms.
#
def capped_perms(perm, max_perms):
    capped = ''
    n = len(perm) - 1
    for i in range(len(perm)):
        if max_perms & 1<<(n-i):
            capped += perm[i]
        else:
            capped += '-'
    return capped

# file_permission
#   name - the name of the result table
#   diag_msg - the diagnostic message
#   max_perms - maximum file permission bits (octal number)
#   prefix_path - the prefix path of the file
# Returns
#   num_file - The total number of files
#   num_dir - the total number of sub-directories list
#   file_perm_list - list of files with permission violation
#   dir_perm_list - list of directories with permission violation
#   file_owner_list - list of files and directories whose owner
#                     are not the same as ORACLE_HOME owner
#
def file_permission(name, diag_msg, max_perms, prefix_path=None):
    file_perm_list = []
    dir_perm_list = []
    file_owner_list = []
    num_file = 0
    num_dir = 0
    path = ''
    if prefix_path is not None:
        path = prefix_path + '/'

    data = sat.get_data(name, 1)

    if data is None or len(data) == 0:
        sat.diag(diag_msg)
        return num_file, num_dir, file_perm_list, \
                   dir_perm_list, file_owner_list

    oh_owner_data = sat.get_data('oracle_home_owner', 1)
    oh_owner = ''
    if oh_owner_data is not None and len(oh_owner_data) > 0:
        oh_owner = oh_owner_data[0][0]

    rows = decode_ls_data(data)
    for x in rows:
        perms = x[0]
        if perms[0] == '-':
            num_file += 1
            capped = capped_perms(perms[1:], max_perms)
            if capped != perms[1:]:
                file_perm_list.append('%s (%s should be %s)' %
                    (path + x[3], perms[1:], capped))
        elif perms[0] == 'd' and x[3] != '..':
            num_dir += 1
            capped = capped_perms(perms[1:], int('775', 8))
            if capped != perms[1:]:
                dir_perm_list.append('%s (%s should be %s)' %
                    (path + x[3], perms[1:], capped))

        # skip if not file or directory.
        if perms[0] not in ['-', 'd']:
            continue

        # All the files should be owned by the ORACLE_HOME owner. However,
        # some executables under the bin directory are expected to be
        # owned by root (e.g., jssu, oradism, extjob, etc.). For the files
        # under bin, make sure they are owned by root or the ORACLE_HOME owner.
        if len(oh_owner) > 0 and x[1] != oh_owner:
            if not (path == 'bin/' and x[1] == 'root'):
                file_owner_list.append(path + x[3] + ' (owner = ' + x[1] + ')')

    return num_file, num_dir, file_perm_list, dir_perm_list, file_owner_list

# db_file_detail
#   title - description of file group
#   file_list - list of files and errors
# Returns
#   text paragraph 
#
# Format a list of file warnings into a details paragraph.
#
def db_file_detail(title, file_list):
    details = title + ':\n'
    details += join_list(file_list, '\n')
    details += '\n\n'
    return details

# os_group_members
#   db_priv - name of administrative privilege
#   name_data - result table containing output from osdbagrp
# Returns
#   mem_list - list of OS users
#   details - details text
#
# Parse output of osdbagrp command for the given admin privilege.
#
def os_group_members(db_priv, name_data):
    data_group = sat.get_data('os_group_file', 1)
    details = ''
    mem_list = []

    # the length should be 1 if the correct data is collected.
    if name_data is None or len(name_data) != 1:
        return mem_list, details

    os_group = name_data[0][0]

    for y in data_group:
        for z in y:
            items = z.split(':')

            # make sure the entry is in the right format.
            if len(items) == 4 and items.pop(0) == os_group:
                group_members = items.pop()
                mem_list = group_members.split(',')
                group_members = group_members.replace(',', ', ')
                details += db_priv + ' [' + os_group + ' group]: ' + \
                           group_members + '\n'

    return mem_list, details

##
## Global state and utility functions
##

# Runtime options
check_oracle_accts = False

# Users and roles to examine
all_users = []
all_roles = []
oracle_users = []
acct_profiles = {}

oracle_admin_users = ['SYS', 'SYSBACKUP', 'SYSDG', 'SYSKM', 'SYSRAC']

# Date of data collection
collection_date = None

# Version of target database
target_db_version = None

# system parameter setting
sys_param_dict = {}

# Database options
db_options_dict = {}

# to_string
#   obj - any object
# returns
#   s - string representation
#
# Convert an object of any type to its string representation. If the 
# argument is known to be a non-string type (e.g. an integer) or
# known to contain only ASCII characters, the built-in str() function
# can be used instead. This function is needed for portability across
# Python versions whenever the argument may contain Unicode characters.
#
def to_string(obj):
    try:
        return unicode(obj)
    except NameError:
        return str(obj)

# enumerate_users
#   No parameters
# Returns
#   None
#
# Populate the global lists all_users, all_roles, oracle_users,
# and acct_profiles.
#
def enumerate_users():
    global all_users, all_roles, oracle_users, acct_profiles

    default_oracle_users = ['SYS', 'SYSTEM', 'GSMCATUSER', \
        'XS$NULL', 'MDDATA', 'REMOTE_SCHEDULER_AGENT',\
        'DBSFWUSER', 'SYSBACKUP', 'GSMUSER', \
        'APEX_PUBLIC_USER', 'SYSRAC', 'CTXSYS', \
        'OJVMSYS', 'DVF', 'DVSYS', 'AUDSYS', 'DIP', \
        'SPATIAL_WFS_ADMIN_USR', 'LBACSYS', 'SYSKM', \
        'OUTLN', 'ORACLE_OCM', 'SYS$UMF', \
        'SPATIAL_CSW_ADMIN_USR', 'SYSDG', 'DBSNMP', \
        'APPQOSSYS', 'GGSYS', 'ANONYMOUS', \
        'FLOWS_FILES', 'SI_INFORMTN_SCHEMA', \
        'GSMADMIN_INTERNAL', 'ORDPLUGINS', \
        'APEX_050000', 'MDSYS', 'OLAPSYS', 'ORDDATA', \
        'XDB', 'WMSYS', 'ORDSYS', 'EXFSYS', 'TSMSYS', \
        'SCOTT', 'ADAMS', 'JONES', 'CLARK', 'BLAKE', \
        'HR', 'OE', 'SH', 'AWR_STAGE', 'CSMIG', 'DMSYS', \
        'PERFSTAT', 'TRACESVR', 'IX', 'PM', 'HTTP_REDIRECT',
        'XS$NULL']
    excluded_users = ['XS$NULL']

    user_data = sat.get_data('user_account', 1)
    if user_data is None:
        sat.diag('User list not available')
    else:
        name = sat.get_index('user_account', 'username')
        acct_status = sat.get_index('user_account', 'status')
        user_prof = sat.get_index('user_account', 'profile')
        is_oracle = sat.get_index('user_account', 'oracle_supplied')

        oracle_users = set(default_oracle_users)
        if is_oracle is not None:
            oracle_users.update([x[name] for x in user_data if x[is_oracle]])

        for x in user_data:
            if (x[name] not in excluded_users and
            (check_oracle_accts or
             x[acct_status] == 'OPEN' or
             x[name] not in oracle_users)):
                all_users.append(x[name])
                acct_profiles[x[name]] = x[user_prof]

    # version 11 contains is_oracle column, but it is not used now.
    # just get version 1 for now.
    role_data = sat.get_data('roles', 1)

    if role_data is None:
        sat.diag('Role list not available')
    else:
        name = sat.get_index('roles', 'role')
        all_roles = [x[name] for x in role_data]

# populate_globals
#   No parameters
# Returns
#   None
#
# Register references used by report findings. Populate the following 
# global data structures:
#   sys_param_dict - database parameter settings
#   db_options_dict - installed database options
#
def populate_globals():
    sat.add_reference('CIS', 'CIS Oracle Database 12c Benchmark v2.0.0')
    sat.add_reference('GDPR', 'EU General Data Protection Regulation 2016/679')

    global sys_param_dict
    data = sat.get_data('parameters', 1)
    if data is None:
        sat.diag('System parameters not available')
    else:
        name = sat.get_index('parameters', 'name')
        value = sat.get_index('parameters', 'value')
        for x in data:
            sys_param_dict[x[name].upper()] = to_string(x[value])

    global db_options_dict
    data = sat.get_data('option_check', 1)
    if data is None:
        sat.diag('Database options not available')
    else:
        name = sat.get_index('option_check', 'parameter')
        value = sat.get_index('option_check', 'value')
        for x in data:
            db_options_dict[x[name]] = x[value]

#
#   Parser for Oracle config files
#

# tokenizer
#    data - string to be parsed
# Returns
#    lexical analyzer instance
#
# Create the lexical analyzer used for parsing Oracle config files. Note
# that space and tab are not used as token delimiters, so even unquoted
# tokens may contain embedded white space.
#
def tokenizer(data):
    mylex = shlex.shlex(data)
    mylex.wordchars += '!$%&*+-./:;<>?@[\]^`{|}~ \t'
    mylex.whitespace = '\r\n'
    return mylex

# parse_gettoken
#    lex - lexical analyzer instance
# Returns
#    Next token or '' at end of file
#
# Return the next token string, with leading and trailing spaces removed.
# Note that there may be spaces embedded in the middle of the token
# string.
#
def parse_gettoken(lex):
    while True:
        tok = lex.get_token()
        if not tok:
            return ''
        tok = tok.strip()
        if tok:
            return tok

# parse_expect
#   lex - lexical analyzer instance
#   expected - expected token
#
# Consume the next token and raise an exception if it does not match
# the expected token.
#
def parse_expect(lex, expected):
    token = parse_gettoken(lex)
    if expected != token:
        raise Exception('expected %s, found %s' % (expected, token))

# parse_lookahead
#   lex - lexical analyzer instance
# Returns
#   next token
#
# Return the next token without consuming it.
#
def parse_lookahead(lex):
    token = parse_gettoken(lex)
    lex.push_token(token)
    return token

# parse_stmt
#   lex - lexical analyzer instance
# Returns
#   dictionary containing single key-value pair
#
# Parse a single statement:
#    [SET] identifier = value
#
def parse_stmt(lex):
    id = parse_gettoken(lex)
    if id.upper() == 'SET':
        id = parse_gettoken(lex)
    parse_expect(lex, '=')
    value = parse_value(lex)
    return { id.upper(): value }

# parse_value
#   lex - lexical analyzer instance
# Returns
#   data structure representing value (may be string, list, or dictionary)
#
# Parse the right-hand side of an assignment statement:
#    string
#    (string, string, ...)
#    (id=value) (id=value) ...
#    id=value, id=value, ...
#    <empty string>
#
def parse_value(lex):
    token = parse_gettoken(lex)
    token = token.strip('"')
    if token == '(':
        token1 = parse_gettoken(lex)
        if parse_lookahead(lex) == '=':
            lex.push_token(token1)
            lex.push_token('(')
            value = parse_stmtlist(lex, '(', ')', None)
        else:
            lex.push_token(token1)
            value = parse_idlist(lex)
            parse_expect(lex, ')')
        return value
    elif token == ')':
        lex.push_token(')')
        return ''
    else:
        if parse_lookahead(lex) == '=':
            lex.push_token(token)
            value = parse_stmtlist(lex, None, None, ',')
        else:
            value = token
        return value

# parse_stmtlist
#   lex - lexical analyzer instance
#   pre - required token before statement
#   post - required token after statement
#   between - required token between statements
# Returns
#   dictionary with key-value pair for each statement
#
# Parse a sequence of statements, with delimiters specified by pre,
# post, and between.
#
def parse_stmtlist(lex, pre, post, between):
    dict = {}
    while True:
        if parse_lookahead(lex) == lex.eof:
            break
        if pre != None:
            parse_expect(lex, pre)
        value = parse_stmt(lex)
        if post != None:
            parse_expect(lex, post)
        merge_dict(dict, value)

        token = parse_lookahead(lex)
        if between != None:
            if token != between:
                break
            parse_expect(lex, between)
        elif pre != None and token != pre:
            break
    return dict

# parse_idlist
#   lex - lexical analyzer instance
# Returns
#   list of string values
#
# Parse a list of strings:
#   string1, string2, ...
#
def parse_idlist(lex):
    id = parse_gettoken(lex)
    token = parse_gettoken(lex)
    if token == ',':
        value = parse_idlist(lex)
        return [id] + value
    else:
        lex.push_token(token)
        return [id]

# merge_dict
#   current - existing dictionary to be updated
#   new - new dictionary
#
# Merge the contents of the new dictionary into an existing dictionary.
# For each key-value pair, if the key already exists convert the
# existing value to a list (if necessary) and append the new value.
#
def merge_dict(current, new):
    for key, value in new.items():
        curval = current.get(key, None)
        if curval == None:
            current[key] = value
        else:
            if not isinstance(curval, list):
                current[key] = [curval]
            current[key].append(value)

# parse_configfile
#   name - result table name
# Returns
#   dictionary representing file contents
#
# Parse a .ora file whose contents are contained in the named
# result table (one line per row).
#
def parse_configfile(name):
    data = sat.get_data(name, 1)

    if data == None or len(data) == 0:
        return None

    if sys.version_info < (3, 0):
        # shlex does not fully support Unicode prior to Python 3
        lines = [x[0].encode('ascii', 'replace') for x in data]
    else:
        lines = [x[0] for x in data]
    mylex = tokenizer('\n'.join(lines))

    try:
        dict = parse_stmtlist(mylex, None, None, None)
        return dict
    except Exception as e:
        sat.diag('Failed to parse ' + name + ': ' + str(e))
        return None

# read_date
#   date_str - text string representing date and time
#   format - format for parsing date_str (default matches RDBMS datetime)
# Returns
#   Python datetime object
#
# Convert a string to datetime object.
#
def read_date(date_str, format='%d-%m-%Y %H:%M'):
    try:
        return datetime.datetime.strptime(date_str, format)
    except Exception as e:
        return None

# format_date
#   input_date - Python datetime object representing date and time
#   format_str - Python datetime format code string
# Returns
#   string representation of date and time
# 
# Convert a datetime object to human-readable string.
#
def format_date(input_date, format_str='%a %b %d %Y %X'):
    # Format is 'Mon Feb 22 2016 17:04:00'
    if input_date is None:
        return ''
    else:
        return input_date.strftime(format_str)

# days_since
#   input_date - Python datetime object representing date and time
#
# Returns
#   number of days from input_date to date of collection
#
def days_since(input_date):
    if input_date and collection_date:
        return (collection_date - input_date).days
    else:
        return None

# max_date
#   date1, date2 - Python datetime objects
#
# Returns
#   maximum of the two input dates, disregarding None
#
def max_date(date1, date2):
    if date1 is None:
        return date2
    elif date2 is None:
        return date1
    else:
        return max(date1, date2)

# join_list
#   str_list - list of strings
#   sep - separator between elements (default ', ')
# Returns
#   concatenated string
#
# Convert a list of strings to a single concatenated string.
# If the input list is empty, return '(none)'.
#
def join_list(str_list, sep=', '):
    if str_list:
        if type(str_list) == list or type(str_list) == tuple:
            return sep.join(str_list)
        else:
            return str_list
    else:
        return '(none)'

# sing_plural
#   num  - number 
#   sing - text for singluar case
#   plur - text for plural case
# Returns
#   num string concatenated with sing if num is 1; 
#   otherwise, num string concatenated with plur.
#
def sing_plural(num, sing, plur):
    if num == 1:
        return '%d %s' % (num, sing)
    else:
        return '%d %s' % (num, plur)

# display_string
#   s - input string
# Returns
#   string suitable for display
#
# In most cases, return the input string. If the input is an empty
# string, return '' for more readable display.
#
def display_string(s):
    if len(s) == 0:
        return "''"
    else:
        return s

# set_union
#   set_list - list of sets (elements may include None)
# Returns
#   union of sets in list
#
# Return the union of a list of sets. A list element of None is treated 
# as the empty set.
#
def set_union(set_list):
    new_set = set([])
    for s in set_list:
        if s is not None:
            new_set = new_set.union(s)

    return new_set

# print_usage
#   No parameters
# Returns
#   None
#
# Print program command-line syntax.
#
def print_usage():
    print('\nUsage: python ' + sys.argv[0] + ' [-a] [-x <sect>] <input_file>')
    print('\nOption:')
    print('   -a  Report about all user accounts, including locked, ' + \
          'Oracle-supplied users\n')
    print('   -x  Specify sections to exclude from report ' + \
          '(may be repeated for multiple sections)')

# Report sections and list of functions to execute
sections = (
    {'id': None, 'name': 'Basic Information',
        'funcs': (sec_feature_usage, patch_checks)
    },
    {'id': 'USER', 'name': 'User Accounts',
        'funcs': (user_section,)
    },
    {'id': 'PRIV', 'name': 'Privileges and Roles',
        'funcs': (privs_and_roles, java_permission, user_password_file)
    },
    {'id': 'AUTH', 'name': 'Authorization Control',
        'funcs': (database_vault, privilege_capture)
    },
    {'id': 'CRYPT', 'name': 'Data Encryption',
        'funcs': (data_encryption, encryption_wallet)
    },
    {'id': 'ACCESS', 'name': 'Fine-Grained Access Control',
        'funcs': (redaction, vpd_policy, ras_policy, label_security,
            tsdp_policy)
    },
    {'id': 'AUDIT', 'name': 'Auditing',
        'funcs': (audit_trail, statement_audit, object_audit, privilege_audit,
            check_admin_audit, check_audited_grant_stmt,
            check_audited_account_stmt, check_audited_system_stmt,
            check_audited_privs_usage, check_audited_connect_stmt,
            fine_grained_audit, unified_audit_policy)
    },
    {'id': 'CONF', 'name': 'Database Configuration',
        'funcs': (security_parameters, sec_parameter_checks, trace_files,
            triggers, disabled_constraint, external_procedure, directories_info,
            dblink_info, network_acl, xml_acl)
    },
    {'id': 'NET', 'name': 'Network Configuration',
        'funcs': (sqlnet_ora, listener_ora)
    },
    {'id': 'OS', 'name': 'Operating System',
        'funcs': (os_authentication_user, pmon_agent_tnslsnr,
            db_file_permission)
    },
)
all_sections = [s['id'] for s in sections if s['id'] is not None]

###
### Main program
###

if __name__ == '__main__':
    excluded_sections = set()

    try:
        opts, argv = getopt.getopt(sys.argv[1:], 'ax:',
            ['all-accounts', 'exclude='])
    except Exception as e:
        print(e)
        print_usage()
        sys.exit(1)

    for opt, arg in opts:
        if opt in ('-a', '--all-accounts'):
            check_oracle_accts = True
        elif opt in ('-x', '--exclude'):
            for sect in arg.upper().split(','):
                if sect in all_sections:
                    excluded_sections.add(sect)
                else:
                    print('Unrecognized section: ' + sect)
                    print('Valid sections are: ' + join_list(all_sections))
                    sys.exit(1)
    if len(argv) < 1:
        print_usage()
        sys.exit(1)

    node = argv[0]

    try:
        sat.read_json(node)
    except Exception as e:
        print('Unable to process input file: ' + node+'.json')
        print(e)
        sys.exit(1)

    sat.start_report(node)

    enumerate_users()
    populate_globals()

    # Initial section - prints before section summary
    db_identification(sys.argv[0])

    for sect in sections:
        if sect['id'] not in excluded_sections:
            sat.start_section(sect['name'])
            for fn in sect['funcs']:
                try:
                    fn()
                except Exception as e:
                    sat.diag('Unexpected error in ' + fn.__name__)
                    print(traceback.format_exc())
            sat.end_section()

    sat.end_report()
